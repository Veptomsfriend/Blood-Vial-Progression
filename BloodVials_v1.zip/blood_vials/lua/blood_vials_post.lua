-- blood_vials_post.lua  (Blood Vials v1.50, menu side; README.txt has the version notes)
-- Seasonal weapons stay locked until you pull them from a Seasonal Crate, paid for with Blood Vials
-- earned in Zombies (scripts\zm_blood_vials.gsc). Saved as an entry in Kronos's dvar kronos_bo6_var (see below).
-- Options -> Debug Options shows two extra rows at the top: your balance and the crate.
-- Kronos files are not modified: this wraps the same ownership checks Kronos wraps, and adds rows to the
-- Debug Options list the same way Kronos does.

local BV = rawget(_G, "BloodVials")
if type(BV) == "table" and BV.version == 3 and BV.reinstall then pcall(BV.reinstall); return end
if type(BV) == "table" then BV.enabled = false end
BV = { version = 3, enabled = true, probing = false, hit = false, seen = setmetatable({}, { __mode = "k" }), last = nil, msg = nil, log = {} }
rawset(_G, "BloodVials", BV)

do
  -- ---------------------------------------------------------------------------------------------------
  -- Settings
  local CRATE_COST = 10
  local STATE_DVAR, STATUS_DVAR = "bloodvials_state", "bloodvials_status"
  -- The pool: BO7 seasonal weapons (loot ID -> internal name). Exotics (Endgame only), the Daisy Juggernaut
  -- minigun and the zombie fists are left out on purpose. Remove a line to keep that weapon always unlocked.
  local POOL = {
    [97897] = "sat_ar_macaw", [97917] = "sat_lm_typhon", [113930] = "sat_me_ballisticknife",
    [126192] = "sat_pi_handcannon", [98043] = "sat_sm_hyena",
    [116617] = "sat_sm_bengal", [97997] = "sat_sn_aden",
    [119844] = "sat_ar_egret", [122673] = "sat_me_saiph", [102705] = "sat_sh_shepherd", [119843] = "sat_sm_gecko",
    [116618] = "sat_ar_heron", [119845] = "sat_dm_solomon",
    [126468] = "sat_ar_finch", [125186] = "sat_pi_alcor", [125262] = "sat_sm_bear", [126466] = "sat_sn_coral",
    [126469] = "sat_me_nashira", [132831] = "sat_sm_mammoth",
    [131330] = "sat_ar_kiwi", [133345] = "sat_dm_samar", [133344] = "sat_sm_marmot",
    [130905] = "sat_ar_albatross", [136509] = "sat_me_elnath", [132997] = "sat_me_maru", [136627] = "sat_sm_stoat",
    [142181] = "sat_ar_wren", [142433] = "sat_lm_hildr", [136390] = "sat_sm_serval",
    -- v1.5: the special weapons (class "sl") and the Season 5.5 / 6 guns
    [121205] = "sat_sl_crossbow", [122685] = "sat_sl_nembus", [126467] = "sat_sl_sargas", [133368] = "sat_sl_atria",
    [142463] = "sat_sl_carina",
    [142462] = "sat_ar_emu", [138772] = "sat_dm_tasman", [138728] = "sat_sh_terrier", [142465] = "sat_sm_civet",
    [136389] = "sat_me_castor", [142464] = "sat_me_wasat",
  }
  -- ---------------------------------------------------------------------------------------------------

  local unpack = unpack or table.unpack
  local function uleb(n) local t = {} repeat local b = n % 128; n = math.floor(n / 128); if n > 0 then b = b + 128 end; t[#t + 1] = string.char(b) until n == 0; return table.concat(t) end
  local HC = {}
  -- Same hashed-key constant builder Kronos uses (kind 0 = function/field, 1 = dvar, 3 = option bundle).
  local function H(hex, kind)
    kind = kind or 0
    local ck = hex .. ":" .. kind
    if HC[ck] ~= nil then return HC[ck] end
    local h = hex:gsub("^0*", ""); h = string.rep("0", 16 - #h) .. h
    local b8 = {}
    for i = 8, 1, -1 do b8[#b8 + 1] = string.char(tonumber(h:sub(i * 2 - 1, i * 2), 16)) end
    local kgc = string.char(4, kind) .. table.concat(b8)
    local bc = string.char(0x28, 0, 0, 0) .. string.char(0x4d, 0, 2, 0)
    local body = string.char(0, 0, 2, 0) .. uleb(1) .. uleb(0) .. uleb(2) .. bc .. kgc
    local chunk = string.char(27) .. "LJ" .. string.char(0x84) .. uleb(0x1a) .. uleb(#body) .. body .. string.char(0)
    HC[ck] = assert(load(chunk))()
    return HC[ck]
  end
  local function g(name) return rawget(_G, name) end
  local function note(s)
    BV.log[#BV.log + 1] = tostring(s)
    if #BV.log > 30 then table.remove(BV.log, 1) end
    pcall(function() local p = g("DebugPrint"); if p then p("[BloodVials] " .. tostring(s)) end end)
  end
  -- A line in the game log (C:\COD\cod25\poi_reg.log, as "lua: BloodVials ..."). DebugPrint doesn't reach it; the
  -- DLL logs the queue Kronos's own Lua writes into dvar 67730584afc6ee3d ("<seq>\t<text>" lines, newest first, up
  -- to 10, a line is logged once per new seq), so ours go into that queue with the next seq.
  -- v1.45: BV.DEBUG = true brings back the developer tools: the game log lines below, the readout at the end of the
  -- Blood Vials row's description and the Crate Sound Test row. Off for release.
  BV.DEBUG = false
  function BV.klog(s)
    if not BV.DEBUG then return end
    pcall(function()
      local D = g("Dvar")
      local h = H("67730584afc6ee3d", 1)
      local cur = tostring(D[H("254084d7ca2317bb")](h) or "")
      local top, lines = 0, {}
      for line in cur:gmatch("[^\n]+") do
        local q = tonumber(line:match("^(%d+)\t"))
        if q and q > top then top = q end
        lines[#lines + 1] = line
      end
      local text = ("BloodVials " .. tostring(s)):gsub("[\t\n\r]", " ")
      table.insert(lines, 1, (top + 1) .. "\t" .. text:sub(1, 180))
      while #lines > 10 do lines[#lines] = nil end
      D[H("1e3cb005036e0c0f")](h, table.concat(lines, "\n"))
    end)
  end
  local CTRL = 0
  local K_OWNED, K_COUNT, K_ISOWNED = "33568d3533d63f69", "50a99e04e868c330", "0b7d304f1f31158e"
  local K_INFRONT, K_GETDV, K_SETDV = "112586a3f4fb490e", "254084d7ca2317bb", "1e3cb005036e0c0f"
  local K_WEAPON_INFO, K_LOCALIZE, K_NOTIFY = "a7b8bf03498e83ef", "aed84c33ec5f01ea", "af31e99a26ececa1"
  local K_LOOT_WEAPON_NAME = "f3b8f7f480f0a1ae"
  -- Option data fields (as Kronos's Debug Options use them)
  local OK = { id = "08b72e07b55c3ac0", sb = "7228576e3216368b", type = "a79439ef7bfa9c2d", name = "c4bcadba8e631b86",
    desc = "0cc44970c8397929", labels = "4bc513f856980a8a", value = "7ce4fd9430e80cea", action = "6568640b035a56df",
    def = "1230e315819fab00", list = "de7843f98867b161" }
  local OPT_DATA_A, OPT_DATA_B, OPT_SECTIONS = "e7686f7a9907efd8", "9f6c4b08602983fb", "7bf7f57679e8d050"
  local ROW_BALANCE, ROW_CRATE, ROW_PROBE = "b10dda1500000001", "b10dda1500000002", "b10dda15000000ff"
  local ROW_BPCRATE = "b10dda1500000003"
  -- earning settings (v1.32): a slider (zombie kills per vial, 1..25) and a toggle (7% chance per zombie instead),
  -- kept as "bvcfg=<kills>.<0|1>" in kronos_bo6_var, which zm_blood_vials.gsc reads in the match
  BV.CFG = { entry = "bvcfg", rowKills = "b10dda1500000004", rowChance = "b10dda1500000005", pct = 7,
    rowSound = "b10dda1500000006" }   -- v1.41: the Crate Sound Test row

  local HD = g("xhashdvar") or g("PushXHashDvar") or (type(g("CLUA")) == "table" and g("CLUA").PushXHashDvar)
  local function dvarGet(name)
    if type(HD) ~= "function" then return nil end
    local ok, v = pcall(function() return g("Dvar")[H(K_GETDV)](HD(name)) end)
    if ok and v ~= nil then return tostring(v) end
    return nil
  end
  local function dvarSet(name, value)
    if type(HD) ~= "function" then return false end
    pcall(function() g("Dvar")[H(K_SETDV)](HD(name), value) end)
    return dvarGet(name) == value
  end
  local function inFrontend()
    local ok, v = pcall(function() return g("Engine")[H(K_INFRONT)]() end)
    return ok and v == true
  end
  local function autoXHash(t)
    local X = g("XHash")
    if type(X) == "table" and X.SetAutoXHashMetatable then return X.SetAutoXHashMetatable(t, 0) or t end
    return t
  end

  -- ---------------------------------------------------------------------------------------------------
  -- The save is one entry, "bloodvials=bv1|rev|vials|progress|id,id,..." ("-" = none), inside Kronos's dvar
  -- kronos_bo6_var. Kronos's own mp_bo6_store.gsc (the ONLY script Kronos runs in the menus) writes that dvar
  -- to kronos\bo6\picks.json and restores it at launch, keeping keys it doesn't know. The Zombies script
  -- updates the same entry during a match. Kronos's Lua drops the oldest entry when the dvar is full, so ours
  -- is always rewritten at the end, and put back if it disappears.
  local K_BO6VAR, ENTRY, FRESH = "9501b5803b01ae76", "bloodvials", "bv1|0|0|0|-"
  local function bo6Handles()
    local hs = {}
    if type(HD) == "function" then local ok, h = pcall(HD, "kronos_bo6_var"); if ok and h ~= nil then hs[#hs + 1] = h end end
    local ok, h = pcall(H, K_BO6VAR, 1); if ok and h ~= nil then hs[#hs + 1] = h end
    return hs
  end
  local function bo6Get()
    for _, h in ipairs(bo6Handles()) do
      local ok, v = pcall(function() return g("Dvar")[H(K_GETDV)](h) end)
      if ok then return tostring(v or "") end
    end
    return nil
  end
  local function bo6Set(text)
    for _, h in ipairs(bo6Handles()) do pcall(function() g("Dvar")[H(K_SETDV)](h, text) end) end
    return bo6Get() == text
  end
  local function entryOf(cur, key) key = key or ENTRY; return (";" .. cur):match(";" .. key .. "=([^;]*)") end
  local function withEntry(cur, value, key)
    key = key or ENTRY
    local out = {}
    for e in cur:gmatch("[^;]+") do if e:sub(1, #key + 1) ~= key .. "=" then out[#out + 1] = e end end
    out[#out + 1] = key .. "=" .. value
    return table.concat(out, ";") .. ";"
  end
  BV.source = "none"

  -- ---------------------------------------------------------------------------------------------------
  -- Blueprints (v1.3). The list (loot ID, base gun, name, variant, image) is lua\blood_vials_data_post.lua,
  -- generated from the game files by tools\make_blueprints.py; it may load after this file, so it's read lazily.
  -- Owned blueprints are a bitset (bit i = the i-th blueprint of that list) in a second kronos_bo6_var entry,
  -- "bvbp=<6 bits per character>". The Zombies script never touches it.
  local BP = { cost = 5, entry = "bvbp",
    alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+." }
  BV.BP = BP
  function BP.data()
    if BP.index then return BP end
    local L = g("BloodVialsBlueprints")
    if type(L) ~= "table" or not L[1] then return nil end
    BP.list, BP.bases, BP.index, BP.attOwner = L, L.bases or {}, {}, {}
    for i, b in ipairs(L) do
      BP.index[b[1]] = i
      for _, a in ipairs(b.att or {}) do BP.attOwner[a] = i end   -- the blueprint's own attachments (v1.10)
    end
    BP.size = #L
    return BP
  end
  -- is this loot ID a BO7 attachment (v1.12)? nil when the data file has no list
  function BP.isAtt(n)
    if not BP.attSet then
      local L = g("BloodVialsBlueprints")
      local s = type(L) == "table" and L.attachments
      if type(s) ~= "string" then return nil end
      local set = {}
      for sa, sb in s:gmatch("(%d+)%-?(%d*)") do
        local lo = tonumber(sa)
        local hi = tonumber(sb) or lo
        for i = lo, hi do set[i] = true end
      end
      BP.attSet = set
    end
    return BP.attSet[n] == true
  end
  function BP.decode(s)
    local set, count = {}, 0
    for c = 1, #(s or "") do
      local v = (BP.alpha:find(s:sub(c, c), 1, true) or 1) - 1
      for b = 0, 5 do
        if math.floor(v / 2 ^ b) % 2 == 1 then set[(c - 1) * 6 + b + 1] = true; count = count + 1 end
      end
    end
    return set, count
  end
  function BP.encode(set)
    local top = 0
    for i in pairs(set) do if i > top then top = i end end
    local out = {}
    for c = 1, math.ceil(top / 6) do
      local v = 0
      for b = 0, 5 do if set[(c - 1) * 6 + b + 1] then v = v + 2 ^ b end end
      out[c] = BP.alpha:sub(v + 1, v + 1)
    end
    return table.concat(out)
  end

  -- Augments: every augment of every perk, ammo mod and field upgrade starts locked. v1.9: a Perk / Ammo Mod /
  -- Field Upgrade Crate unlocks the NEXT TWO augments of a random group of that kind that still has locked ones, in
  -- the group's natural order (steps in the data file: one major + one minor per step by release, the bonus last).
  -- Unlocked augments are the entry "bvag=<bits>" (bit i = the i-th loot ID of the data file's augs list). The
  -- v1.6 entry "bvpk=<bits>" (a whole group unlocked at once) still counts: those groups stay fully unlocked.
  local PK = { entry = "bvpk", agEntry = "bvag",
    cost = { perk = 10, ammo = 10, fu = 10 },
    kinds = { "perk", "ammo", "fu" },
    label = { perk = "Perk", ammo = "Ammo Mod", fu = "Field Upgrade" },
    plural = { perk = "perks", ammo = "ammo mods", fu = "field upgrades" } }
  BV.PK = PK
  function PK.data()
    if PK.index then return PK end
    local L = g("BloodVialsBlueprints")
    if type(L) ~= "table" or type(L.perks) ~= "table" then return nil end
    PK.list, PK.index, PK.total, PK.augTotal, PK.bit, PK.names = L.perks, {}, {}, {}, {}, L.augNames or {}
    for i, p in ipairs(L.perks) do
      for _, id in ipairs(p[3]) do PK.index[id] = i end
      local k = p[4] or "perk"
      PK.total[k] = (PK.total[k] or 0) + 1
      PK.augTotal[k] = (PK.augTotal[k] or 0) + #p[3]
      if not p.steps then p.steps = {}; for _, id in ipairs(p[3]) do p.steps[#p.steps + 1] = { id } end end
    end
    for b, id in ipairs(L.augs or {}) do PK.bit[id] = b end
    PK.size = #L.perks
    return PK
  end
  -- is this augment unlocked (its own bit, or its whole group from a v1.6 save)?
  function PK.owned(st, id)
    local gi = PK.index[id]
    return (gi and st.pk[gi]) or (PK.bit[id] and st.ag[PK.bit[id]]) or false
  end
  -- the first step of group i with a locked augment, or nil when the group is complete
  function PK.nextStep(st, i)
    for s, step in ipairs(PK.list[i].steps) do
      for _, id in ipairs(step) do if not PK.owned(st, id) then return s, step end end
    end
    return nil
  end
  -- augments of this kind unlocked
  function PK.count(st, kind)
    local n = 0
    if st and PK.data() then
      for _, p in ipairs(PK.list) do
        if (p[4] or "perk") == kind then for _, id in ipairs(p[3]) do if PK.owned(st, id) then n = n + 1 end end end
      end
    end
    return n
  end
  -- an augment's display name: the game's localized name when it can be read, else the generated one
  function PK.augName(id)
    local n = PK.names[id]
    if not n then return tostring(id) end
    local loc
    pcall(function() local f = g("Engine")[H(K_LOCALIZE)]; if type(f) == "function" and n[1] ~= "" then loc = f(n[1]) end end)
    if type(loc) == "string" and loc ~= "" and loc ~= n[1] and not loc:find("/", 1, true) then return loc end
    return n[2]
  end

  -- Wonder weapon skins (v1.9): locked behind the Apothicon Crate, which costs one Apothicon Blood Vial. Those come
  -- only from completing a map's main quest (zm_blood_vials.gsc writes "bvap=<rev>.<count>"). Owned skins are the
  -- entry "bvww=<bits>" (bit i = the i-th skin of the data file's ww list; a PaP twin unlocks with its skin).
  local WW = { entry = "bvww", apEntry = "bvap", cost = 1 }
  BV.WW = WW
  function WW.data()
    if WW.index then return WW end
    local L = g("BloodVialsBlueprints")
    if type(L) ~= "table" or type(L.ww) ~= "table" then return nil end
    WW.list, WW.index, WW.attOwner = L.ww, {}, {}
    for i, w in ipairs(L.ww) do
      WW.index[w.id] = i; if w.pap then WW.index[w.pap] = i end
      for _, a in ipairs(w.att or {}) do WW.attOwner[a] = i end
    end
    WW.size = #L.ww
    return WW
  end

  -- Cursed relics (v1.27): all 30 relics (Ashes, Ruby, Mantis, Locust, Hornet; lua\blood_vials_chal_post.lua
  -- "relics") start locked and come from the Relic Crate (RL.cost Blood Vials, a random one you don't own). Peeks'
  -- Mayhem (the Cursed Survival mode, which the csm_mayhem_relic mod makes available) is a prize of the Apothicon
  -- Crate, next to the wonder weapon skins, and is hidden while locked (RL.hookSlot). Owned: entry "bvrl=<bits>",
  -- bit 1 = Peeks' Mayhem, then the relics in the data file's order.
  local RL = { entry = "bvrl", cost = 10, SURVIVAL = "sat_zm_category_r_mod_survival",
    SURVIVAL_HEX = "0x0ec021cc68429ef4", SLOT = "60e2e1c5dc3d4efa",
    MAPS = { firefly = "Ashes of the Damned", ruby = "Ruby", mantis = "Mantis", locust = "Locust", hornet = "Hornet" } }
  BV.RL = RL
  function RL.data()
    if RL.index then return RL end
    local D = g("BloodVialsChallenges")
    if type(D) ~= "table" or type(D.relics) ~= "table" then return nil end
    -- Peeks' Mayhem's picture: the golden Peeks relic the game shows for the Cursed Survival unlock
    -- (scriptbundle\featureitem\sat_zm_rh_mod_playlist_unlock.json)
    RL.list, RL.index = { { 0, "peeks_mayhem", "sat_ui_icon_zm_relic_golden_peeks", mayhem = true } }, {}
    for _, r in ipairs(D.relics) do RL.list[#RL.list + 1] = r; RL.index[r[1]] = #RL.list end
    RL.size = #RL.list - 1
    return RL
  end
  -- "Delta Relic", "Ashes of the Damned" (from the ref: sat_zm_firefly_delta_relic, zm_sat_mantis_heta_relic, ...)
  function RL.name(i)
    local r = RL.list[i]
    if r.mayhem then return "Peeks' Mayhem", "Cursed Survival" end
    local s = r[2]:gsub("^sat_zm_", ""):gsub("^zm_sat_", "")
    local map, name = s:match("^(%a+)_(%a+)_")
    name = (name or s):gsub("^%l", string.upper)
    return name .. " Relic", RL.MAPS[map or ""] or ((map or "?"):gsub("^%l", string.upper))
  end
  -- the relic's picture for the reveal (v1.34): its icon name, or for an icon the game data only has as
  -- "hash_<hex>", that hash as an image reference (BV.assetRef), or nil
  function RL.icon(i)
    local r = RL.list[i]
    local img = r and r[3]
    if type(img) ~= "string" or img == "" then return nil end
    local hex = img:match("^hash_(%x+)$")
    if hex then return BV.assetRef(hex) end
    return img
  end
  -- An image reference from an asset hash (the game's "hash_<hex>" names). CLUA.PushXHashAsset(name) gives the
  -- game's own reference for a name; its hash type is found once by comparing it with our constants for a name
  -- whose hash is known (sat_ui_icon_zm_relic_lawyer_pen = 02211cdebd6e071a, IW asset FNV), then reused.
  -- Nil if no type matches (the reveal then shows no picture, as before).
  function BV.assetRef(hex)
    if BV.assetKind == nil then
      BV.assetKind = false
      pcall(function()
        local ref = g("CLUA").PushXHashAsset("sat_ui_icon_zm_relic_lawyer_pen")
        for k = 0, 15 do
          local okH, v = pcall(H, "02211cdebd6e071a", k)
          if okH and v == ref then BV.assetKind = k; break end
        end
      end)
      note("asset hash kind: " .. tostring(BV.assetKind))
    end
    if BV.assetKind == false then return nil end
    local ok, v = pcall(H, hex, BV.assetKind)
    return ok and v or nil
  end

  -- the bitset entries next to the main one: key, field in the state, its count, last good value
  local EXTRA = { { BP.entry, "bp", "bpCount", "lastGoodBP" }, { PK.entry, "pk", "pkCount", "lastGoodPK" },
    { PK.agEntry, "ag", "agCount", "lastGoodAG" }, { WW.entry, "ww", "wwCount", "lastGoodWW" },
    { RL.entry, "rl", "rlCount", "lastGoodRL" } }

  local cacheText, cacheState, cacheCur
  local function readState()
    local cur = bo6Get()
    if cur == nil then BV.source = "no dvar access"; return nil end
    -- fast path (v1.43): the ownership hooks call this hundreds of times while a menu draws; while the save dvar is
    -- the same string as last time, the parsed state is too (Lua compares interned strings by reference)
    if cur == cacheCur and cacheState then return cacheState end
    local text = entryOf(cur)
    if text then
      BV.source = "saved"
    elseif BV.lastGood and inFrontend() then
      -- our entry was dropped (dvar full) after we had seen it this session: put it back
      bo6Set(withEntry(cur, BV.lastGood)); text = BV.lastGood; BV.source = "restored"; note("entry restored")
      cur = bo6Get() or cur
    else
      text = FRESH; BV.source = "new"
    end
    local key = text
    local extra = {}
    for i, x in ipairs(EXTRA) do
      local v = entryOf(cur, x[1])
      if not v and BV[x[4]] and BV[x[4]] ~= "" and inFrontend() then
        bo6Set(withEntry(cur, BV[x[4]], x[1])); v = BV[x[4]]; note(x[1] .. " entry restored")
        cur = bo6Get() or cur
      end
      extra[i] = v or ""
      key = key .. "#" .. extra[i]
    end
    -- Apothicon Blood Vials: "bvap=<rev>.<count>" (a counter, written by the match script and by the crate)
    local ap = entryOf(cur, WW.apEntry)
    if not ap and BV.lastGoodAP and inFrontend() then
      bo6Set(withEntry(cur, BV.lastGoodAP, WW.apEntry)); ap = BV.lastGoodAP; note("bvap entry restored")
    end
    ap = ap or ""
    key = key .. "#" .. ap
    if key == cacheText then cacheCur = cur; return cacheState end
    cacheText, cacheState = key, nil
    local tag, rev, vials, prog, ids = text:match("^(bv1)|(%-?%d+)|(%-?%d+)|(%-?%d+)|([%d,%-]*)$")
    if not tag then return nil end
    local st = { rev = tonumber(rev), vials = tonumber(vials), progress = tonumber(prog), earned = {}, count = 0 }
    for id in ids:gmatch("%d+") do
      local n = tonumber(id)
      if n and not st.earned[n] then st.earned[n] = true; st.count = st.count + 1 end
    end
    for i, x in ipairs(EXTRA) do
      st[x[2]], st[x[3]] = BP.decode(extra[i])
      if extra[i] ~= "" then BV[x[4]] = extra[i] end
    end
    local apRev, apN = ap:match("^(%d+)%.(%d+)$")
    st.apRev, st.ap = tonumber(apRev) or 0, tonumber(apN) or 0
    if apRev then BV.lastGoodAP = ap end
    cacheState, cacheCur = st, cur
    if BV.source ~= "new" then BV.lastGood = text end
    return st
  end
  -- writes the main entry, plus each bitset entry the state carries (st.bp, st.pk); others stay as they are
  local function writeState(st)
    local ids = {}
    for id in pairs(st.earned) do ids[#ids + 1] = id end
    table.sort(ids)
    local text = "bv1|" .. st.rev .. "|" .. st.vials .. "|" .. st.progress .. "|" .. (#ids > 0 and table.concat(ids, ",") or "-")
    local cur = bo6Get()
    if cur == nil then return false end
    local out = withEntry(cur, text)
    local written = {}
    for i, x in ipairs(EXTRA) do
      local v = st[x[2]] and BP.encode(st[x[2]]) or nil
      if v and v ~= "" then out = withEntry(out, v, x[1]); written[i] = v end
    end
    -- the Apothicon count only when this write changes it (st.apSet): its revision goes up by one
    local apText = st.apSet and ((st.apRev or 0) + 1 .. "." .. st.ap) or nil
    if apText then out = withEntry(out, apText, WW.apEntry) end
    local ok = bo6Set(out)
    cacheText, cacheCur = nil, nil
    if ok then
      if apText then BV.lastGoodAP = apText end
      BV.lastGood = text
      for i, x in ipairs(EXTRA) do if written[i] then BV[x[4]] = written[i] end end
    end
    return ok
  end
  local POOL_SIZE = 0
  for _ in pairs(POOL) do POOL_SIZE = POOL_SIZE + 1 end

  -- Prestige attachments (v1.11): the attachments flagged #isprestige (data file "prestige": attachment -> gun) stay
  -- locked until that gun has been prestiged. A gun's prestige comes from the challenge records Kronos's DLL writes
  -- into dvars (version dvar + up to 100 parts; a weapon's level record is "c<id> <kind> <xp> <status> <target>
  -- <rank> <prestige> <prestiging> <weapon loot ID>", the same lines and fields Kronos's own Lua reads).
  local PR = { need = 1, ver = "e621c4c8cb4b6a1d", parts = {
    "1a2f59e42a21e7f3", "1a2f58e42a21e5c0", "1a2f5be42a21ec59", "1a2f5ae42a21ea26", "1a2f5de42a21f0bf", "1a2f5ce42a21ee8c",
    "1a2f5fe42a21f525", "1a2f5ee42a21f2f2", "1a2f61e42a21f98b", "1a2f60e42a21f758", "b8066dc8a88caed0", "b8066ec8a88cb103",
    "b8066fc8a88cb336", "b80670c8a88cb569", "b80671c8a88cb79c", "b80672c8a88cb9cf", "b80673c8a88cbc02", "b80674c8a88cbe35",
    "b80675c8a88cc068", "b80676c8a88cc29b", "b8137fc8a89aeaeb", "b8137ec8a89ae8b8", "b81381c8a89aef51", "b81380c8a89aed1e",
    "b81383c8a89af3b7", "b81382c8a89af184", "b81385c8a89af81d", "b81384c8a89af5ea", "b81377c8a89ad953", "b81376c8a89ad720",
    "b80ef9c8a895ce62", "b80efac8a895d095", "b80ef7c8a895c9fc", "b80ef8c8a895cc2f", "b80ef5c8a895c596", "b80ef6c8a895c7c9",
    "b80ef3c8a895c130", "b80ef4c8a895c363", "b80f01c8a895dffa", "b80f02c8a895e22d", "b81c0bc8a8a40a7d", "b81c0ac8a8a4084a",
    "b81c09c8a8a40617", "b81c08c8a8a403e4", "b81c07c8a8a401b1", "b81c06c8a8a3ff7e", "b81c05c8a8a3fd4b", "b81c04c8a8a3fb18",
    "b81c03c8a8a3f8e5", "b81c02c8a8a3f6b2", "b81805c8a8a00774", "b81806c8a8a009a7", "b81807c8a8a00bda", "b81808c8a8a00e0d",
    "b81801c8a89ffea8", "b81802c8a8a000db", "b81803c8a8a0030e", "b81804c8a8a00541", "b817fdc8a89ff5dc", "b817fec8a89ff80f",
    "b824f7c8a8adfd2f", "b824f6c8a8adfafc", "b824f9c8a8ae0195", "b824f8c8a8adff62", "b824f3c8a8adf463", "b824f2c8a8adf230",
    "b824f5c8a8adf8c9", "b824f4c8a8adf696", "b824ffc8a8ae0ec7", "b824fec8a8ae0c94", "b82071c8a8a8e0a6", "b82072c8a8a8e2d9",
    "b8206fc8a8a8dc40", "b82070c8a8a8de73", "b82075c8a8a8e972", "b82076c8a8a8eba5", "b82073c8a8a8e50c", "b82074c8a8a8e73f",
    "b82079c8a8a8f23e", "b8207ac8a8a8f471", "b82e03c8a8b83641", "b82e02c8a8b8340e", "b82e01c8a8b831db", "b82e00c8a8b82fa8",
    "b82e07c8a8b83f0d", "b82e06c8a8b83cda", "b82e05c8a8b83aa7", "b82e04c8a8b83874", "b82dfbc8a8b824a9", "b82dfac8a8b82276",
    "b8297dc8a8b319b8", "b8297ec8a8b31beb", "b8297fc8a8b31e1e", "b82980c8a8b32051", "b82981c8a8b32284", "b82982c8a8b324b7" } }
  BV.PR = PR
  function PR.data()
    if PR.att then return PR end
    local L = g("BloodVialsBlueprints")
    if type(L) ~= "table" or type(L.prestige) ~= "table" then return nil end
    PR.att = L.prestige
    return PR
  end
  -- weapon loot ID -> prestige, or nil when the records can't be read (then nothing is locked by prestige)
  function PR.levels()
    local get = g("Dvar") and g("Dvar")[H(K_GETDV)]
    if type(get) ~= "function" then return nil end
    local okV, ver = pcall(function() return tostring(get(H(PR.ver, 1))) end)
    if not okV or not ver then return nil end
    if ver == PR.cacheVer then return PR.map end
    local n = tonumber(ver:match("^%d+:(%d+)$"))
    if not n or n > #PR.parts then return nil end
    local s = {}
    for i = 1, n do
      local ok, part = pcall(function() return tostring(get(H(PR.parts[i], 1))) end)
      if not ok then return nil end
      s[i] = part
    end
    -- v1.12: also Kronos's own lock list ("l<id>": a challenge reward not earned yet) and each challenge row's
    -- progress, the same lines Kronos's Lua builds CH.locked / CH.rec from
    local map, locked, rows, ranks = {}, {}, {}, {}
    for line in table.concat(s):gmatch("[^\n]+") do
      local t = line:sub(1, 1)
      if t == "c" then
        local id, p, st, tg, rk, pr, w = line:match("^c(%d+) %d+ (%d+) (%d+) (%d+) ?(%d*) ?(%d*) ?%d* ?(%d*)")
        if id then rows[tonumber(id)] = { p = tonumber(p), st = tonumber(st), tg = tonumber(tg) } end
        if w and w ~= "" then map[tonumber(w)] = tonumber(pr) or 0; ranks[tonumber(w)] = tonumber(rk) or 0 end
      elseif t == "l" then
        local n = tonumber(line:sub(2))
        if n then locked[n] = true end
      end
    end
    PR.cacheVer, PR.map, PR.klocked, PR.rows, PR.ranks = ver, map, locked, rows, ranks
    local nl, nr = 0, 0
    for _ in pairs(locked) do nl = nl + 1 end
    for _ in pairs(rows) do nr = nr + 1 end
    PR.nLocked = nl
    note("challenge state " .. ver .. ": " .. nr .. " rows, " .. nl .. " locked (Kronos's lock list)")
    BV.klog("challenge state " .. ver .. ": " .. nr .. " rows, " .. nl .. " locked")
    return map
  end
  -- Kronos locks this (a challenge reward not earned yet); false when the records can't be read
  function PR.kLocked(n)
    if not PR.levels() then return false end
    return PR.klocked[n] == true
  end
  -- a challenge row complete (progress reached its target), nil when the row isn't in the records
  function PR.rowDone(id)
    if not PR.levels() then return nil end
    local r = PR.rows[id]
    if not r then return nil end
    return r.tg ~= nil and r.tg > 0 and r.p ~= nil and r.p >= r.tg
  end

  -- Attachments and camos by progression (v1.16). Kronos's lock list doesn't hold weapon-level attachments or camo
  -- rewards (logged in game: an M15 optic, fire mod and camo were not on it, and every check said unlocked). So
  -- Blood Vials locks them itself from the same records: lua\blood_vials_chal_post.lua (tools\make_challenges.py,
  -- from Kronos's challenges.tsv) lists every challenge row that rewards an attachment or camo, its thresholds,
  -- its prerequisite rows and its child rows. A reward is earned when its row's progress (the record's "p": weapon
  -- XP for a weapon's level row, kills etc. for a camo row) reached that tier's threshold and every prerequisite
  -- row is complete; a gun prestiged at least once keeps all its level unlocks. Rows without a record and
  -- unreadable records lock nothing.
  local CHL = {}
  BV.CHL = CHL
  function CHL.data()
    if CHL.by then return CHL end
    local D = g("BloodVialsChallenges")
    if type(D) ~= "table" or type(D.rows) ~= "string" then return nil end
    local rows, by = {}, {}
    for line in D.rows:gmatch("[^\n]+") do
      local id, kind, w, thr, rew, pre, kids = line:match("^(%d+);(%d*);(%d*);([^;]*);([^;]*);([^;]*);?([^;]*)")
      if id then
        local r = { id = tonumber(id), kind = tonumber(kind), w = tonumber(w), thr = {}, pre = {}, kids = {} }
        for v in thr:gmatch("%d+") do r.thr[#r.thr + 1] = tonumber(v) end
        for v in pre:gmatch("%d+") do r.pre[#r.pre + 1] = tonumber(v) end
        for v in kids:gmatch("%d+") do r.kids[#r.kids + 1] = tonumber(v) end
        local i = 0
        for v in rew:gmatch("[^|]+") do
          i = i + 1
          local n = tonumber(v)
          if n and n > 0 then
            local l = by[n] or {}
            l[#l + 1] = { r, i }
            by[n] = l
          end
        end
        rows[r.id] = r
      end
    end
    CHL.rows, CHL.by = rows, by
    return CHL
  end
  -- a challenge row complete (with its prerequisites); memoised per records version
  function CHL.done(id)
    if CHL.ver ~= PR.cacheVer then CHL.ver, CHL.memo = PR.cacheVer, {} end
    local m = CHL.memo[id]
    if m ~= nil then return m end
    CHL.memo[id] = false                         -- guards against a cycle
    local r, rec = CHL.rows[id], PR.rows and PR.rows[id]
    local last = (r and r.thr[#r.thr]) or (rec and rec.tg)
    local res = rec ~= nil and rec.p ~= nil and last ~= nil and last > 0 and rec.p >= last
    if not res and r and #r.kids > 0 and last then
      local n = 0
      for _, k in ipairs(r.kids) do if CHL.done(k) then n = n + 1 end end
      res = n >= last
    end
    if res and r then
      for _, p in ipairs(r.pre) do if not CHL.done(p) then res = false; break end end
    end
    CHL.memo[id] = res
    return res
  end
  -- true when n is an attachment / camo reward not earned yet; false otherwise (or when unknown)
  function CHL.isLocked(n)
    if not CHL.data() or not CHL.by[n] then return false end
    if not PR.levels() or not PR.rows then return false end
    for _, e in ipairs(CHL.by[n]) do
      local r, i = e[1], e[2]
      if r.kind == 398 and r.w and (PR.map[r.w] or 0) >= 1 then return false end
      local rec = PR.rows[r.id]
      if not rec then return false end
      local ok = true
      for _, p in ipairs(r.pre) do if not CHL.done(p) then ok = false; break end end
      local thr = r.thr[i] or r.thr[#r.thr]
      if ok and thr and rec.p and rec.p >= thr then return false end
    end
    return true
  end

  -- Player-level unlocks (v1.25 field upgrades, v1.26 everything): weapons, equipment, field upgrades, ammo mods,
  -- perks, scorestreaks, wildcards from Kronos's challenges.tsv "@lv_<N>" lists (= shown level N+1), GobbleGums from
  -- the in-game list (lua\blood_vials_chal_post.lua "levels": Frenzied Guard 8, Healing Aura 17, AK-27 4, Aftertaste
  -- 6, ...). One stays locked while the player level (rank + 1, the game's own progression data, as Kronos reads it)
  -- is below its level. A prestiged player keeps them all. Unreadable level -> nothing locked.
  local LV = {}
  BV.LV = LV
  function LV.need(n)
    local D = g("BloodVialsChallenges")
    local t = type(D) == "table" and (D.levels or D.fieldLevels)
    return type(t) == "table" and t[n] or nil
  end
  -- the loot ID of a level item from whatever the game passes (v1.36): a loot ID (number or numeric string), the
  -- item's ref ("sat_ar_kite", "equip_combataxe_sat", "..._mp"), or its hash (the VM's xhash; tostring gives
  -- "xhash: #x<hex>"). nil when it isn't one of ours.
  function LV.idOf(v)
    local tv = type(v)
    if tv == "number" then return LV.need(v) and v or nil end
    local D = g("BloodVialsChallenges")
    if type(D) ~= "table" then return nil end
    if tv == "string" then
      local n = tonumber(v)
      if n then return LV.need(n) and n or nil end
      return type(D.levelNames) == "table" and D.levelNames[v:lower()] or nil
    end
    if v ~= nil and tostring(tv):sub(1, 5) == "xhash" and type(D.levelRefs) == "table" then
      local ok, s = pcall(tostring, v)
      local hex = ok and type(s) == "string" and s:match("#x(%x+)")
      if hex then return D.levelRefs[(hex:lower():gsub("^0+", ""))] end
    end
    return nil
  end
  -- v1.40: the loot ID of ANY item the game passes as a number, a level item's or a gun's ref, or their hash
  -- (weaponNames / weaponRefs cover every base gun, so the seasonal ones too). nil when unknown.
  function LV.anyId(v)
    local tv = type(v)
    if tv == "number" then return v end
    if tv == "string" and tonumber(v) then return tonumber(v) end
    local id = LV.idOf(v)
    if id then return id end
    local D = g("BloodVialsChallenges")
    if type(D) ~= "table" then return nil end
    if tv == "string" then return type(D.weaponNames) == "table" and D.weaponNames[v:lower()] or nil end
    if v ~= nil and tostring(tv):sub(1, 5) == "xhash" and type(D.weaponRefs) == "table" then
      local ok, s = pcall(tostring, v)
      local hex = ok and type(s) == "string" and s:match("#x(%x+)")
      if hex then return D.weaponRefs[(hex:lower():gsub("^0+", ""))] end
    end
    return nil
  end
  -- player level and prestige, or nil when unreadable
  function LV.level()
    local okR, rank = pcall(function()
      local ds = g("_DataSources")[H("dffc2cf2d66f1248")][H("c7091fb2a7344c70")][H("6db3201fd1eb3847")]
      return ds:GetValue(CTRL)
    end)
    rank = okR and tonumber(rank) or nil
    if not rank then return nil end
    local okP, p = pcall(function() return g("Dvar")[H(K_GETDV)](H("703f4ce774962899", 1)) end)
    return rank + 1, (okP and tonumber(p)) or 0
  end
  function LV.isLocked(n)
    local need = LV.need(n)
    if not need then return false end
    local lvl, prestige = LV.level()
    if not lvl or prestige >= 1 then return false end
    return lvl < need
  end

  -- Weapon prestige camos (v1.29): every gun's Prestige 1 and 2 camos and its Prestige Master / Max camos (prestige
  -- 2 at master levels 99 / 149 / 199 / 249), from the guns' weapondata bundles (lua\blood_vials_chal_post.lua
  -- "prestigeCamos": camo -> gun, prestige, level). One opens when its gun's prestige (Kronos's weapon record) is
  -- past that prestige, or at it with the record's rank at or past the level. Unreadable records lock nothing.
  local PCL = {}
  BV.PCL = PCL
  function PCL.isLocked(n)
    local D = g("BloodVialsChallenges")
    local t = type(D) == "table" and D.prestigeCamos
    local e = type(t) == "table" and t[n]
    if not e then return false end
    if not PR.levels() or not PR.ranks then return false end
    for i = 1, #e, 3 do
      local w, need, lvl = e[i], e[i + 1], e[i + 2]
      local pr, rk = PR.map[w] or 0, PR.ranks[w] or 0
      if pr > need or (pr == need and (lvl == 0 or rk >= lvl)) then return false end
    end
    return true
  end

  -- Armory guns (v1.12, from ripsawuk's "E3a Armory Lock Door" mod): these three Seasonal Crate guns also unlock
  -- when their own Armory challenge row (250 kills) is complete. The rows exist only with that mod's
  -- challenges.tsv; without them only the crate unlocks the gun.
  local ARMORY = { [126468] = 69316, [125262] = 69318, [125186] = 69320 }
  BV.ARMORY = ARMORY
  -- true / false for a prestige attachment (prestiged or not), nil for anything else or when unknown
  function PR.unlocked(n)
    if not PR.data() or not PR.att[n] then return nil end
    local m = PR.levels()
    if not m then return nil end
    return (m[PR.att[n]] or 0) >= PR.need
  end

  -- Locked = a pool weapon not earned, a blueprint not owned, an augment not unlocked, a wonder weapon skin not
  -- owned, or a prestige attachment of a gun not prestiged. While the save can't be read nothing is locked.
  local function isLocked(id)
    local n = tonumber(id)
    if not n or not BV.enabled then return false end
    local pu = PR.unlocked(n)
    if pu ~= nil then return not pu end
    local bi = not POOL[n] and BP.data() and BP.index[n]
    local pi = not POOL[n] and not bi and PK.data() and PK.index[n]
    local wi = not POOL[n] and not bi and not pi and WW.data() and WW.index[n]
    local ri = not POOL[n] and not bi and not pi and not wi and n > 0 and RL.data() and RL.index[n]
    if not POOL[n] and not bi and not pi and not wi and not ri then return CHL.isLocked(n) or LV.isLocked(n) or PCL.isLocked(n) end
    local st = readState()
    if not st then return false end
    if bi then return not st.bp[bi] end
    if pi then return not PK.owned(st, n) end
    if wi then return not st.ww[wi] end
    if ri then return not st.rl[ri] end
    if ARMORY[n] and PR.rowDone(ARMORY[n]) then return false end
    return not st.earned[n]
  end
  -- Owned through the save (v1.10): a crate gave it, or it is an attachment of a blueprint / skin a crate gave.
  -- The ownership hooks answer true for these instead of asking the game: the game doesn't know about crates, so a
  -- blueprint's own attachments counted as not owned and were stripped from the gun.
  local function isOwned(id)
    local n = tonumber(id)
    if not n or not BV.enabled then return false end
    if PR.unlocked(n) then return true end   -- a prestiged gun's prestige attachment
    local st
    if POOL[n] then
      if ARMORY[n] and PR.rowDone(ARMORY[n]) then return true end
      st = readState(); return st and st.earned[n] or false
    end
    if BP.data() then
      local i = BP.index[n] or BP.attOwner[n]
      if i then st = readState(); return st and st.bp[i] or false end
    end
    if WW.data() then
      local i = WW.index[n] or WW.attOwner[n]
      if i then st = readState(); return st and st.ww[i] or false end
    end
    if PK.data() and PK.index[n] then st = readState(); return st and PK.owned(st, n) or false end
    if n > 0 and RL.data() and RL.index[n] then st = readState(); return st and st.rl[RL.index[n]] or false end
    -- an ordinary attachment in the build of a blueprint a crate gave you (v1.13, BPB below)
    local gi = BV.BPB and BV.BPB.granted[n]
    if gi then st = readState(); return st and st.bp[gi] or false end
    return false
  end
  BV.isOwned = isOwned

  -- Probe (v1.11): which ownership checks the game makes for blueprint / prestige attachments, with the last id and
  -- what was answered. Shown on the Blood Vials row ("att checks"), to see which check Gunsmith really uses.
  BV.attDbg = {}
  BV.calls = {}
  local function attProbe(name, id, res)
    local c = BV.calls[name] or { n = 0, f = 0 }
    c.n = c.n + 1
    if res == false or res == 0 then c.f = c.f + 1 end
    BV.calls[name] = c
    local n = tonumber(id)
    if not n then return end
    if n > 0 and RL.data() and RL.index[n] then             -- v1.27: which checks the relic menu makes
      BV.relicChecks = BV.relicChecks or {}
      BV.relicChecks[name] = (BV.relicChecks[name] or 0) + 1
    end
    -- v1.23: every check made on a granted blueprint attachment (first 12), to see whether the popup asks us at all
    -- (kept as the last 12; written out when the restricted popup opens)
    if BV.BPB and BV.BPB.watch and BV.BPB.watch[n] then
      BV.watchRing = BV.watchRing or {}
      table.insert(BV.watchRing, name .. " " .. n .. "=" .. tostring(res))
      if #BV.watchRing > 12 then table.remove(BV.watchRing, 1) end
      BV.watchTotal = (BV.watchTotal or 0) + 1
    end
    local interesting = (BP.data() and BP.attOwner[n]) or (PR.data() and PR.att[n])
    if not interesting then return end
    local d = BV.attDbg[name] or { n = 0 }
    d.n, d.id, d.res = d.n + 1, n, tostring(res)
    BV.attDbg[name] = d
  end
  BV.attProbe = attProbe
  function BV.attStatus()
    local out = {}
    for _, k in ipairs({ "owned", "count", "unlocked", "exception" }) do
      local d = BV.attDbg[k]
      out[#out + 1] = k .. " " .. (d and (d.n .. " (" .. d.id .. "=" .. d.res .. ")") or "0")
    end
    return "att checks: " .. table.concat(out, ", ")
  end

  -- ---------------------------------------------------------------------------------------------------
  -- Blueprint builds (v1.13). A blueprint's build also uses ORDINARY attachments of its gun (Red Mist: Intervention
  -- Stock, Redwell 5.56 Compensator, 16.5" Fusion Barrel, Mayday Extended Mag), which unlock with weapon level; Kronos's
  -- layer (outside ours) answers "locked" for those before ours is asked. The dumped game files don't have the builds
  -- and the game's Lua has no debug library, so the builds are read from the game the way its own gunsmith code does:
  -- Engine.GetWeaponBlueprint (c879c2878db98f92) with the gun and a variant number returns that blueprint, with its
  -- loot ID ("lootid") and its attachments. The variant comes from the loot info (LOOT 87cdd0659739d333) when that
  -- gives one, else the gun's variants 0..BPB.maxVariant are read once and matched by loot ID. The attachments of an
  -- owned crate blueprint's build then count as owned (BPB.granted: attachment -> blueprint bit). While any are
  -- granted, our ownership hooks answer before Kronos's layer (hookSlot) and pass everything else on to it.
  -- Everything it finds goes to the game log (poi_reg.log, needs "luiDebugPrint": true in kronos\settings.json).
  local BPB = { granted = {}, bases = {}, maxVariant = 63, missStop = 16, key = nil, log = {}, why = "not run",
    K_GETBP = "c879c2878db98f92", K_ITEMREF = "3d5d69ba555e016d", K_LOOTINFO = "87cdd0659739d333",
    K_LOOTID = "8028887f70bf5eba" }
  BV.BPB = BPB
  function BPB.say(s)
    BPB.log[#BPB.log + 1] = s
    if #BPB.log > 60 then table.remove(BPB.log, 1) end
    note("builds: " .. s)
    BV.klog("builds: " .. s)
  end
  function BPB.field(t, k)
    if type(t) ~= "table" then return nil end
    local v = rawget(t, k)
    if v ~= nil then return v end
    local ok, r = pcall(function() return t[k] end)
    if ok then return r end
    return nil
  end
  -- a short description of a value, for the log
  function BPB.desc(v, depth)
    local tv = type(v)
    if tv ~= "table" then
      local s = tostring(v)
      return tv == "string" and ('"' .. s:sub(1, 48) .. '"') or s:sub(1, 48)
    end
    if (depth or 0) >= 2 then return "{...}" end
    local out, n = {}, 0
    for k, x in pairs(v) do
      n = n + 1
      if n > 14 then out[#out + 1] = "..."; break end
      out[#out + 1] = tostring(k):sub(1, 24) .. "=" .. BPB.desc(x, (depth or 0) + 1)
    end
    return "{" .. table.concat(out, ", ") .. "}"
  end
  -- attachment ref (as text) -> loot ID, built once from LOOT.getitemref over every BO7 attachment
  function BPB.refMap()
    if BPB.rmap then return BPB.rmap end
    local LT, m, n = g("LOOT"), {}, 0
    local f = LT and LT[H(BPB.K_ITEMREF)]
    BP.isAtt(0)
    if type(f) ~= "function" or not BP.attSet then return m end
    for id in pairs(BP.attSet) do
      local ok, r = pcall(f, id)
      if ok and r ~= nil then m[tostring(r)] = id; n = n + 1 end
    end
    BPB.rmap = m
    BPB.say("ref map: " .. n .. " attachment refs")
    return m
  end
  -- v1.19: the game's records use hashed field names (FNV-1a 64 of the lower-cased name), seen in game
  BPB.KEY = { attachments = "f901aa0340249a41", assetname = "514c91ffb3ba4240", lootid = "8028887f70bf5eba",
    ref = "89e9c01960f4c582", name = "c4bcadba8e631b86", id = "08b72e07b55c3ac0", attachment = "2073f89ac8d3f248",
    attachmentref = "0bd6fbaeeb4ab275" }
  -- a field by its plain name, then by its hashed name
  function BPB.get(t, name)
    local v = BPB.field(t, name)
    if v ~= nil then return v end
    local hx = BPB.KEY[name:lower()]
    if hx then return BPB.field(t, H(hx)) end
    return nil
  end
  -- FNV-1a 64 of a lower-cased name as 16 hex digits, in plain Lua (four 16-bit limbs)
  local function xor8(x, y)
    local r, p = 0, 1
    for _ = 1, 8 do
      if (x % 2) ~= (y % 2) then r = r + p end
      x, y, p = math.floor(x / 2), math.floor(y / 2), p * 2
    end
    return r
  end
  function BPB.fnv(s)
    local a, b, c, d = 0x2325, 0x8422, 0x9ce4, 0xcbf2
    for i = 1, #s do
      local lo = a % 256
      a = a - lo + xor8(lo, s:byte(i))
      local r0 = a * 0x1b3
      local r1 = b * 0x1b3
      local r2 = c * 0x1b3 + a * 0x100
      local r3 = d * 0x1b3 + b * 0x100
      a = r0 % 65536; r1 = r1 + math.floor(r0 / 65536)
      b = r1 % 65536; r2 = r2 + math.floor(r1 / 65536)
      c = r2 % 65536; r3 = r3 + math.floor(r2 / 65536)
      d = r3 % 65536
    end
    return string.format("%04x%04x%04x%04x", d, c, b, a)
  end
  -- the 16 hex digits of a hashed value's text ("#x..."), or nil
  function BPB.hexOf(v)
    local hx = tostring(v):match("#x(%x+)")
    if not hx then return nil end
    hx = hx:lower()
    if #hx < 16 then hx = string.rep("0", 16 - #hx) .. hx end
    return hx:sub(-16)
  end
  -- hash of an attachment's name -> loot ID, built once
  function BPB.hashMap()
    if BPB.hmap then return BPB.hmap end
    local m, n = {}, 0
    for txt, id in pairs(BPB.refMap()) do
      if not txt:find("#x", 1, true) then m[BPB.fnv(txt:lower())] = id; n = n + 1 end
    end
    BPB.hmap = m
    BPB.say("hash map: " .. n .. " attachment names")
    return m
  end
  -- a value naming an attachment (loot ID, name, hashed name) -> loot ID
  function BPB.valueId(v)
    if v == nil or type(v) == "boolean" or type(v) == "table" then return nil end
    local n = tonumber(v)
    if n then return BP.isAtt(n) and n or nil end
    local id = BPB.refMap()[tostring(v)]
    if id then return id end
    local hx = BPB.hexOf(v)
    if hx then return BPB.hashMap()[hx] end
    if type(v) == "string" then return BPB.hashMap()[BPB.fnv(v:lower())] end
    return nil
  end
  function BPB.entryId(e)
    if type(e) ~= "table" then return BPB.valueId(e) end
    for _, k in ipairs({ "lootID", "lootid", "id" }) do
      local v = tonumber(BPB.get(e, k))
      if v and BP.isAtt(v) then return v end
    end
    for _, k in ipairs({ "assetName", "ref", "attachmentRef", "attachment", "name" }) do
      local id = BPB.valueId(BPB.get(e, k))
      if id then return id end
    end
    return nil
  end
  -- the attachment loot IDs of a blueprint record
  function BPB.attsOf(bp)
    local atts, out = BPB.get(bp, "attachments"), {}
    if type(atts) ~= "table" then return out end
    for _, e in pairs(atts) do
      local id = BPB.entryId(e)
      if id then out[#out + 1] = id end
    end
    return out
  end
  function BPB.lootIdOf(bp)
    return tonumber(BPB.field(bp, "lootid") or BPB.field(bp, "lootID") or BPB.field(bp, H(BPB.K_LOOTID)))
  end
  -- the variant number of a blueprint from the game's loot info, or nil
  function BPB.variantOf(id)
    local LT = g("LOOT")
    local f = LT and LT[H(BPB.K_LOOTINFO)]
    if type(f) ~= "function" then return nil end
    local types = BPB.field(LT, "itemTypes")
    local wt = BPB.field(types, "weapon") or BPB.field(types, "WEAPON")
    for _, args in ipairs({ { id }, { wt, id }, { CTRL, id } }) do
      local ok, r = pcall(f, unpack(args))
      if ok and type(r) == "table" then
        for _, k in ipairs({ "variantID", "variantId", "weaponVariantID", "variant" }) do
          local v = tonumber(BPB.field(r, k))
          if v then return v end
        end
      end
    end
    return nil
  end
  -- one owned blueprint -> its attachment IDs, or nil (how is in BPB.why / the log)
  function BPB.read(o)
    if BPB.cache and BPB.cache[o.id] then return BPB.cache[o.id], "seen in game" end
    local E = g("Engine")
    local f = E and E[H(BPB.K_GETBP)]
    if type(f) ~= "function" then BPB.why = "no GetWeaponBlueprint yet"; return nil end
    local ref = BP.bases[o.base] .. "_mp"         -- the game's own calls: ("sat_ar_hawk_mp", 7) (v1.19)
    local v = BPB.variantOf(o.id)
    if v then
      local ok, bp = pcall(f, ref, v)
      if ok and type(bp) == "table" and (BPB.lootIdOf(bp) == nil or BPB.lootIdOf(bp) == o.id) then return BPB.attsOf(bp), "variant " .. v end
    end
    -- the gun's variants, read once and matched by loot ID; stops after missStop misses in a row
    local gun = BPB.bases[o.base]
    if not gun then
      gun = {}
      local got, miss, first = 0, 0, nil
      BPB.say(ref .. ": reading variants")
      for vv = 0, BPB.maxVariant do
        local ok, bp = pcall(f, ref, vv)
        if ok and type(bp) == "table" then
          got, miss = got + 1, 0
          first = first or bp
          local lid = BPB.lootIdOf(bp)
          if lid then gun[lid] = BPB.attsOf(bp) end
        else
          miss = miss + 1
          if miss >= BPB.missStop and got > 0 then break end
        end
      end
      BPB.say(ref .. ": " .. got .. " variants" .. (first and (", e.g. " .. BPB.desc(first)) or ""))
      BPB.bases[o.base] = gun
    end
    if gun[o.id] then return gun[o.id], "matched" end
    return nil
  end
  -- what the game returns for one blueprint, tried several ways (only logged, once)
  function BPB.explore(o)
    local E, LT = g("Engine"), g("LOOT")
    local f = E and E[H(BPB.K_GETBP)]
    local ref = BP.bases[o.base]
    BPB.say("blueprint " .. o.id .. " " .. o.name .. " (gun " .. ref .. ") not matched; trying:")
    if type(f) == "function" then
      for _, args in ipairs({ { ref }, { o.name }, { o.id }, { ref, o.name }, { o.name, 0 } }) do
        local ok, r = pcall(f, unpack(args))
        local a = {}
        for i, x in ipairs(args) do a[i] = BPB.desc(x) end
        BPB.say("GetWeaponBlueprint(" .. table.concat(a, ", ") .. ") -> " .. (ok and BPB.desc(r) or ("error " .. tostring(r))))
      end
    end
    local li = LT and LT[H(BPB.K_LOOTINFO)]
    if type(li) == "function" then
      for _, args in ipairs({ { o.id }, { CTRL, o.id } }) do
        local ok, r = pcall(li, unpack(args))
        BPB.say("LOOT.87cd(" .. table.concat(args, ", ") .. ") -> " .. (ok and BPB.desc(r) or ("error " .. tostring(r))))
      end
    else
      BPB.say("LOOT.87cd missing")
    end
    local okR, r = pcall(function() return LT[H(BPB.K_ITEMREF)](o.id) end)
    BPB.say("getitemref(" .. o.id .. ") = " .. (okR and BPB.desc(r) or "error"))
  end
  -- re-read when the owned blueprints change (or until the game's functions are ready)
  function BPB.refresh()
    if not BV.enabled or not BP.data() then return end
    local st = readState()
    if not st then return end
    local key = tostring(entryOf(bo6Get() or "", BP.entry) or "")
    if key == BPB.key then return end
    local granted, nb, na, owned = {}, 0, 0, 0
    for i, b in ipairs(BP.list) do
      if st.bp[i] then
        owned = owned + 1
        local atts, how = BPB.read({ i = i, id = b[1], base = b[2], name = b[3] })
        if atts == nil and BPB.why == "no GetWeaponBlueprint yet" then return end
        if atts then
          nb = nb + 1
          for _, a in ipairs(atts) do if not granted[a] then granted[a] = i; na = na + 1 end end
          if nb <= 3 then BPB.say(b[3] .. ": " .. #atts .. " attachments (" .. how .. ")") end
        elseif not BPB.explored then
          BPB.explored = true
          pcall(BPB.explore, { i = i, id = b[1], base = b[2], name = b[3] })
        end
      end
    end
    BPB.granted, BPB.key = granted, key
    BPB.why = nb .. "/" .. owned .. " builds read, " .. na .. " attachments"
    BPB.say(BPB.why)
  end
  -- v1.18: learn builds from the game's own calls. Engine.GetWeaponBlueprint is wrapped; every record it returns
  -- (loot ID + attachments) is kept for the session, so whenever the menus show a blueprint (build lists, the store,
  -- Gunsmith) its build is known, and an owned crate blueprint's attachments are granted right away. The first calls
  -- are logged with their arguments, which shows the call format the game uses.
  BPB.cache, BPB.calls = BPB.cache or {}, BPB.calls or 0
  function BPB.capture(r, ...)
    BPB.calls = BPB.calls + 1
    if type(r) ~= "table" then
      if BPB.calls <= 3 then
        local a = {}
        for i = 1, math.min(select("#", ...), 4) do a[i] = BPB.desc((select(i, ...))) end
        BV.klog("builds: game call GetWeaponBlueprint(" .. table.concat(a, ", ") .. ") -> " .. type(r))
      end
      return
    end
    local lid = BPB.lootIdOf(r)
    if lid and select("#", ...) >= 2 then BPB.byWV[BPB.wvKey((select(1, ...)), (select(2, ...)))] = lid end
    if not lid or BPB.cache[lid] then return end
    local atts = BPB.attsOf(r)
    BPB.cache[lid] = atts
    BPB.learned = (BPB.learned or 0) + 1
    if BPB.learned <= 4 then
      local a = {}
      for i = 1, math.min(select("#", ...), 4) do a[i] = BPB.desc((select(i, ...))) end
      BV.klog("builds: game call GetWeaponBlueprint(" .. table.concat(a, ", ") .. ") -> loot " .. lid .. ", " .. #atts ..
        " attachments")
      if BPB.learned == 1 then BV.klog("builds: record " .. BPB.desc(r)) end
    end
    -- an owned crate blueprint: its attachments are granted now
    local bi = BP.data() and BP.index[lid]
    if bi and (BPB.detailN or 0) < 2 then
      BPB.detailN = (BPB.detailN or 0) + 1
      local list = BPB.get(r, "attachments")
      local first
      if type(list) == "table" then for _, e in pairs(list) do first = e; break end end
      BV.klog("builds: " .. BP.list[bi][3] .. ": " .. #atts .. " attachments matched; list " .. type(list) ..
        ", first entry " .. BPB.desc(first))
    end
    if bi then
      local st = readState()
      if st and st.bp[bi] then
        local added = 0
        for _, a in ipairs(atts) do if not BPB.granted[a] then BPB.granted[a] = bi; added = added + 1 end end
        if added > 0 then BV.klog("builds: " .. BP.list[bi][3] .. " owned: " .. added .. " attachments unlocked") end
      end
    end
  end
  -- v1.20: the blueprint record has no attachments (seen in game: "list nil"). The gunsmith gets a build's
  -- attachments from GUNSMITH f82505c42ee3a76f (with includeAttachments; the result has plain "weapon", "variantID",
  -- "attachments" and entries with "assetName"). It is wrapped too: every result (or argument table) holding a gun,
  -- a variant and an attachment list is matched to the blueprint through the (gun, variant) -> loot ID pairs
  -- GetWeaponBlueprint gave (BPB.byWV), and an owned crate blueprint's attachments are granted at once, before the
  -- caller counts locked ones.
  BPB.byWV = BPB.byWV or {}
  BPB.K_GSBUILD = "f82505c42ee3a76f"
  function BPB.wvKey(w, v)
    local s = tostring(w):gsub("_mp$", "")
    return s .. ":" .. tostring(v)
  end
  function BPB.capture2(r, ...)
    BPB.gsCalls = (BPB.gsCalls or 0) + 1
    if BPB.gsCalls <= 3 then
      local a = {}
      for i = 1, math.min(select("#", ...), 5) do a[i] = BPB.desc((select(i, ...))) end
      BV.klog("builds: game call GUNSMITH.f825(" .. table.concat(a, ", "):sub(1, 110) .. ")")
      BV.klog("builds: -> " .. BPB.desc(r):sub(1, 160))
    end
    local cands = { r, ... }
    for i = 1, select("#", ...) + 1 do
      local c = cands[i]
      if type(c) == "table" then
        local list = BPB.get(c, "attachments")
        local w = BPB.get(c, "weapon")
        local v = tonumber(BPB.get(c, "variantID"))
        if type(list) == "table" and w ~= nil and v then
          local lid = BPB.byWV[BPB.wvKey(w, v)]
          if not lid and type(BPB.raw) == "function" then
            for _, wr in ipairs({ tostring(w), tostring(w) .. "_mp" }) do
              local ok, bp = pcall(BPB.raw, wr, v)
              if ok and type(bp) == "table" then lid = BPB.lootIdOf(bp); if lid then break end end
            end
          end
          if lid then
            local atts = {}
            for _, e in pairs(list) do local id = BPB.entryId(e); if id then atts[#atts + 1] = id end end
            if #atts > 0 and not (BPB.cache[lid] and #BPB.cache[lid] >= #atts) then
              BPB.cache[lid] = atts
              local bi = BP.data() and BP.index[lid]
              if bi then
                local st = readState()
                local added = 0
                if st and st.bp[bi] then
                  for _, a in ipairs(atts) do if not BPB.granted[a] then BPB.granted[a] = bi; added = added + 1 end end
                end
                BV.klog("builds: " .. BP.list[bi][3] .. " build from the gunsmith: " .. #atts .. " attachments" ..
                  (added > 0 and (", " .. added .. " unlocked") or (st and st.bp[bi] and "" or " (not owned)")))
                if added > 0 then
                  -- v1.23: which items, by ID and name, and the raw list the game passed
                  local names = {}
                  for _, a in ipairs(atts) do
                    local okR, r = pcall(function() return g("LOOT")[H(BPB.K_ITEMREF)](a) end)
                    names[#names + 1] = a .. "=" .. tostring(okR and r or "?"):gsub("^sat_", "")
                    BPB.watch = BPB.watch or {}
                    BPB.watch[a] = true
                  end
                  local txt = table.concat(names, " ")
                  for i = 1, math.min(3, math.ceil(#txt / 165)) do BV.klog("builds: ids " .. txt:sub((i - 1) * 165 + 1, i * 165)) end
                  local raw = {}
                  for _, e in pairs(list) do raw[#raw + 1] = BPB.desc(e) end
                  local rt = table.concat(raw, " ")
                  for i = 1, math.min(3, math.ceil(#rt / 165)) do BV.klog("builds: list " .. rt:sub((i - 1) * 165 + 1, i * 165)) end
                end
              end
            end
          elseif (BPB.gsMiss or 0) < 2 then
            BPB.gsMiss = (BPB.gsMiss or 0) + 1
            BV.klog("builds: gunsmith build for " .. tostring(w) .. " variant " .. v .. ": no blueprint known for it")
          end
        end
      end
    end
  end
  -- v1.21: the "Remove restricted attachment?" popup (RemoveAttachmentRestrictedPopup, b1f0954b3e9943f9). Its data is
  -- searched (4 levels): an owned crate blueprint (its loot ID, or a gun + variant matched through BPB.byWV) and the
  -- attachments it lists; those are granted to that blueprint. The popup still shows this once; equipping again
  -- shouldn't. Its data's shape is logged so the build can be read earlier next time.
  function BPB.onPopup(data, label)
    label = label or "restricted popup"
    if label == "restricted popup" then
      BPB.popups = (BPB.popups or 0) + 1
      if BPB.popups <= 2 then
        BV.klog("builds: popup opened; checks on the granted attachments so far " .. tostring(BV.watchTotal or 0) ..
          ", latest: " .. table.concat(BV.watchRing or {}, ", "):sub(1, 120))
        BV.watchRing = {}
      end
    end
    BPB.logN = BPB.logN or {}
    local bps, atts, seen, nodes = {}, {}, {}, 0
    local function visit(v, depth)
      local tv = type(v)
      if tv == "number" then
        local bi = BP.data() and BP.index[v]
        if bi then bps[v] = bi elseif BP.isAtt(v) then atts[v] = true end
        return
      end
      if tv ~= "table" then
        local id = BPB.valueId(v)
        if id then atts[id] = true end
        return
      end
      if seen[v] or depth > 4 or nodes > 400 then return end
      seen[v] = true
      local w, vv = BPB.get(v, "weapon"), tonumber(BPB.get(v, "variantID"))
      if w ~= nil and vv then
        local lid = BPB.byWV[BPB.wvKey(w, vv)]
        if not lid and type(BPB.raw) == "function" then
          for _, wr in ipairs({ tostring(w), tostring(w) .. "_mp" }) do
            local ok, bp = pcall(BPB.raw, wr, vv)
            if ok and type(bp) == "table" then lid = BPB.lootIdOf(bp); if lid then break end end
          end
        end
        if lid and BP.index[lid] then bps[lid] = BP.index[lid] end
      end
      for k, x in pairs(v) do
        nodes = nodes + 1
        if nodes > 400 then break end
        visit(x, depth + 1)
      end
    end
    pcall(visit, data, 0)
    local st = readState()
    local nb, na, granted = 0, 0, 0
    for _ in pairs(atts) do na = na + 1 end
    for lid, bi in pairs(bps) do
      nb = nb + 1
      if st and st.bp[bi] then
        for a in pairs(atts) do if not BPB.granted[a] then BPB.granted[a] = bi; granted = granted + 1 end end
        local list = {}
        for a in pairs(atts) do list[#list + 1] = a end
        BPB.cache[lid] = list
      end
    end
    local ln = (BPB.logN[label] or 0)
    if ln < 2 or (nb > 0 and ln < 6) then
      BPB.logN[label] = ln + 1
      BV.klog("builds: " .. label .. ": " .. nb .. " blueprint(s), " .. na .. " attachments in its data, " .. granted ..
        " unlocked")
      if ln < 2 then
        local d = BPB.desc(data)
        for i = 1, math.min(3, math.ceil(#d / 170)) do BV.klog("builds: data " .. d:sub((i - 1) * 170 + 1, i * 170)) end
      end
    end
  end
  -- v1.22: the popup isn't built through MenuBuilder.BuildRegisteredType and GUNSMITH has no f825 (logged). The
  -- loadout code decides "includes locked attachments" in plain-named functions (ui\utils\loadoututils.lua:
  -- WeaponHasRestrictedAttachment, LoadoutHasRestrictedItem, ...). Every global table is searched (rawget only) for
  -- those names and for f825; the restricted checks get a wrapper that grants an owned crate blueprint's build (found
  -- in the arguments, the way onPopup searches) BEFORE the check runs, so the check sees it unlocked.
  BPB.RESTRICT_FNS = { "WeaponHasRestrictedAttachment", "LoadoutHasRestrictedItem", "IsThereARestrictedLoadout",
    "ShouldShowLoadoutRestrictedPopup", "DefaultLoadoutHasRestrictedItem" }
  BPB.found = BPB.found or {}
  function BPB.wrapPre(T, k, label)
    local f = rawget(T, k)
    if type(f) ~= "function" or BV.seen[f] then return end
    local w = function(...)
      if BV.enabled then
        BPB.preCalls = (BPB.preCalls or 0) + 1
        pcall(BPB.onPopup, { ... }, label)
      end
      return f(...)
    end
    BV.seen[w] = true
    rawset(T, k, w)
    BPB.found[#BPB.found + 1] = label
    BV.klog("builds: wrapped " .. label)
  end
  function BPB.hookAll()
    BPB.scanN = (BPB.scanN or 0) + 1
    if BPB.scanN > 3 and BPB.scanN % 10 ~= 0 then return end
    local kGS = H(BPB.K_GSBUILD)
    local n = 0
    for name, T in pairs(_G) do
      n = n + 1
      if n > 4000 then break end
      if type(T) == "table" and type(name) == "string" then
        for _, fn in ipairs(BPB.RESTRICT_FNS) do
          if type(rawget(T, fn)) == "function" then BPB.wrapPre(T, fn, name .. "." .. fn) end
        end
        local f = rawget(T, kGS)
        if type(f) == "function" and not BV.seen[f] then
          local w = function(...)
            local res = { n = 0 }
            local function keep(...) res.n = select("#", ...); for i = 1, res.n do res[i] = select(i, ...) end end
            keep(f(...))
            if BV.enabled then pcall(BPB.capture2, res[1], ...) end
            return unpack(res, 1, res.n)
          end
          BV.seen[w] = true
          rawset(T, kGS, w)
          BPB.found[#BPB.found + 1] = name .. ".f825"
          BV.klog("builds: wrapped " .. name .. ".f825")
        end
      end
    end
  end
  function BPB.hookGunsmith()
    local GS = g("GUNSMITH")
    local k = H(BPB.K_GSBUILD)
    local f = type(GS) == "table" and GS[k]
    if type(f) ~= "function" or BV.seen[f] then return end
    local w = function(...)
      local res = { n = 0 }
      local function keep(...) res.n = select("#", ...); for i = 1, res.n do res[i] = select(i, ...) end end
      keep(f(...))
      if BV.enabled then pcall(BPB.capture2, res[1], ...) end
      return unpack(res, 1, res.n)
    end
    BV.seen[w] = true
    GS[k] = w
    note("hooked GUNSMITH build")
  end
  function BPB.hookEngine()
    local E = g("Engine")
    local k = H(BPB.K_GETBP)
    local f = type(E) == "table" and E[k]
    if type(f) ~= "function" or BV.seen[f] then return end
    local w = function(...)
      local res = { n = 0 }
      local function keep(...) res.n = select("#", ...); for i = 1, res.n do res[i] = select(i, ...) end end
      keep(f(...))
      if BV.enabled then pcall(BPB.capture, res[1], ...) end
      return unpack(res, 1, res.n)
    end
    BV.seen[w] = true
    BPB.raw = f
    E[k] = w
    note("hooked GetWeaponBlueprint")
  end
  function BPB.any() return next(BPB.granted) ~= nil end
  function BPB.status()
    return "builds: " .. BPB.why .. ", answering first " .. (BV.liftCount or 0) .. "x] [level/camo locks: " ..
      tostring(PR.nLocked or "unread") .. " in Kronos's list, " .. (BV.kDenied or 0) .. " checks locked"
  end

  -- ---------------------------------------------------------------------------------------------------
  -- Hooks. Kronos re-wraps these whenever something else changes them, so each hook is installed again only
  -- when a probe call shows ours is no longer anywhere in the chain (avoids stacking a layer per refresh).
  -- v1.17: the probe call only counts OUR hook of the same name (tag). Before, any of our hooks reached during the
  -- probe counted: the game's isUnlocked calls the ownership check inside, so our isUnlocked hook was never put in
  -- ("already in the chain") and isUnlocked kept answering "unlocked".
  local function inChain(fn, tag, ...)
    BV.probing, BV.hit, BV.probeTag = true, false, tag
    pcall(fn, ...)
    BV.probing = false
    return BV.hit
  end
  local function hookFn(T, hex, label, make, ...)
    if type(T) ~= "table" then return end
    local k = H(hex)
    local cur = T[k]
    BV.hookState = BV.hookState or {}
    -- v1.36: each hook's state, for the log ("missing" = no function there yet, "ours" = already wrapped)
    if type(cur) ~= "function" then
      if BV.hookState[label] == nil then BV.hookState[label] = "missing (" .. type(cur) .. ")" end
      return
    end
    if BV.seen[cur] then BV.hookState[label] = BV.hookState[label] or "ours"; return end
    if inChain(cur, label, ...) then BV.seen[cur] = true; BV.hookState[label] = "in chain"; return end
    local w = make(cur, label)
    BV.seen[w] = true
    T[k] = w
    BV.hookState[label] = "hooked"
    note("hooked " .. label)
  end
  -- Ownership hooks (v1.13). Normally Kronos's layer is outside ours (Kronos re-wraps these after every module
  -- load). Only while blueprint builds grant attachments (BPB.any()) does ours go back on top, and then it answers
  -- just what is ours (owned / locked by Blood Vials) and hands everything else to Kronos's layer (slot.outer), which
  -- calls back into ours underneath (slot.depth > 0) and goes on to the game: Kronos's locks stay exactly as they
  -- are. (v1.12 put ours on top for good and applied a copy of Kronos's lock list itself; in game camos and
  -- attachments showed unlocked with it, so that was dropped.)
  local function slotWrap(kind)
    local zero = (kind == "count") and 0 or false
    return function(orig, slot)
      local tag = type(slot) == "table" and slot.label or slot
      if type(slot) ~= "table" then slot = nil end
      return function(c, id, ...)
        if BV.probing then if BV.probeTag == tag then BV.hit = true end; return zero end
        if slot and slot.depth > 0 then return orig(c, id, ...) end
        if isOwned(id) then
          attProbe(kind, id, true)
          if kind ~= "count" then return true end
          local ok, n = pcall(orig, c, id, ...)
          return (ok and type(n) == "number" and n > 0) and n or 1
        end
        if isLocked(id) then attProbe(kind, id, false); return zero end
        local outer = slot and slot.outer
        if outer then
          slot.depth = slot.depth + 1
          local ok, r = pcall(outer, c, id, ...)
          slot.depth = slot.depth - 1
          if ok then attProbe(kind, id, r); return r end
        end
        local r = orig(c, id, ...)
        attProbe(kind, id, r)
        return r
      end
    end
  end
  local ownedWrap, countWrap = slotWrap("owned"), slotWrap("count")
  BV.slots = BV.slots or {}
  BV.liftCount = BV.liftCount or 0
  local function hookSlot(T, hex, label, make)
    if type(T) ~= "table" then return end
    local k = H(hex)
    local cur = T[k]
    if type(cur) ~= "function" then return end
    local slot = BV.slots[label]
    if slot and slot.T == T and (cur == slot.w or inChain(cur, label, CTRL, 0)) then
      -- off since v1.18: Kronos's list doesn't hold attachments, so granted ones pass its layer anyway (BPB.lift)
      if cur ~= slot.w and BPB.lift and BPB.any() then
        slot.outer = cur                -- whatever was put on top of ours (Kronos's layer) answers after ours
        T[k] = slot.w
        BV.liftCount = BV.liftCount + 1
      end
      return
    end
    if BV.seen[cur] then return end
    slot = { T = T, k = k, depth = 0, label = label }
    slot.w = make(cur, slot)
    BV.seen[slot.w] = true
    BV.slots[label] = slot
    T[k] = slot.w
    note("hooked " .. label)
  end
  -- PROGRESSION.isUnlocked (loot ID = 3rd argument) and the "unlock exception" check (loot ID = 1st), the checks
  -- Kronos's Lua also watches for weapon and attachment unlocks (v1.11)
  local function unlockWrap(name, argi)
    return function(orig, tag)
      return function(...)
        if BV.probing then if BV.probeTag == tag then BV.hit = true end; return false end
        local id = select(argi, ...)
        if isOwned(id) then attProbe(name, id, true); return true end
        if isLocked(id) then attProbe(name, id, false); return false end
        -- v1.14: Kronos's lock list (weapon-level attachments, camo challenge rewards, ... not earned yet) applies
        -- here too. Kronos applies it only to the ownership check, so Gunsmith's lists and the camo grid, which ask
        -- these checks, showed everything unlocked.
        local n = tonumber(id)
        if n and PR.kLocked(n) then
          BV.kDenied = (BV.kDenied or 0) + 1
          attProbe(name, id, false)
          return false
        end
        local r = orig(...)
        attProbe(name, id, r)
        return r
      end
    end
  end

  -- Lock check (v1.14 diagnostics): what every check answers right now (from the top of each chain) for a few M15
  -- items that are locked at weapon level 1: an optic (EAM Micro Dot 96145), a fire mod (Bolt Carrier Group 97676)
  -- and the first Zombies military camo (105556). Written to the game log; run when Debug Options opens.
  BV.LOCK_SAMPLES = { 96145, 97676, 105556 }
  function BV.lockDiag()
    local P, LT, LO = g("PROGRESSION"), g("LOOT"), g("Loot")
    local function ask(T, hex, ...)
      local f = type(T) == "table" and T[H(hex)]
      if type(f) ~= "function" then return "-" end
      local ok, r = pcall(f, ...)
      return ok and tostring(r) or "err"
    end
    local cs = {}
    for k, c in pairs(BV.calls) do cs[#cs + 1] = k .. " " .. c.n .. "/" .. c.f .. " locked" end
    BV.klog("lock check: list " .. tostring(PR.nLocked or "unread") .. " | calls " .. table.concat(cs, ", "))
    -- one line for the three sample items (the log queue holds 10 lines; this check writes at most 7)
    local sm = {}
    for _, id in ipairs(BV.LOCK_SAMPLES) do
      sm[#sm + 1] = id .. " lock " .. tostring(CHL.isLocked(id)):sub(1, 1) .. " own " .. ask(P, K_OWNED, CTRL, id):sub(1, 1) ..
        ask(LT, K_OWNED, CTRL, id):sub(1, 1) .. " cnt " .. ask(LT, K_COUNT, CTRL, id) .. " unl " ..
        ask(P, "13d8bd2b211db6cc", CTRL, 0, id):sub(1, 1)
    end
    BV.klog("samples: " .. table.concat(sm, " | "))
    -- the M15's level row, its Zombies military camo row, the first special camo and its unlock row, as recorded
    local rs = {}
    for _, rid in ipairs({ 54494, 54854, 54855, 54859, 54797 }) do
      local r = PR.rows and PR.rows[rid]
      rs[#rs + 1] = rid .. "=" .. (r and (tostring(r.p) .. "/" .. tostring(r.tg) .. " st" .. tostring(r.st)) or "none") ..
        (CHL.data() and (" done " .. tostring(CHL.done(rid))) or "")
    end
    BV.klog("records: " .. table.concat(rs, ", ") .. " | table " .. (CHL.data() and "loaded" or "missing"))
    local lvl, pres = LV.level()
    local fu = {}
    for _, id in ipairs({ 55415, 55412, 97814, 55411 }) do
      fu[#fu + 1] = id .. " lv" .. tostring(LV.need(id)) .. (LV.isLocked(id) and " LOCKED" or " open")
    end
    BV.klog("field upgrades: player level " .. tostring(lvl) .. " prestige " .. tostring(pres) .. " | " .. table.concat(fu, ", "))
    local hs = BV.hookState or {}
    BV.klog("unlock text: rank hook " .. tostring(hs["progression getunlockrank"] or "-") .. ", calls " ..
      tostring(BV.rankCalls or 0) .. ", answered " .. tostring(BV.rankAsks or 0) .. " | perm hook " ..
      tostring(hs["progression isitempermanentlyunlocked"] or "-") .. ", answered " .. tostring(BV.permAsks or 0) ..
      " | gate " .. tostring(hs["progression unlock gate"] or "-") .. " " .. tostring(BV.gateAsks or 0) ..
      "x, text " .. tostring(hs["progression unlock text"] or "-") .. " " .. tostring(BV.textAsks or 0) .. "x")
    BV.klog("unlock text args: " .. tostring(BV.rankLast or "none yet"):sub(1, 150))
    local pc = {}
    for _, id in ipairs({ 107524, 107515, 113292, 107498 }) do pc[#pc + 1] = id .. (PCL.isLocked(id) and " LOCKED" or " open") end
    BV.klog("prestige camos (M15): prestige " .. tostring(PR.map and PR.map[88930]) .. " rank " ..
      tostring(PR.ranks and PR.ranks[88930]) .. " | " .. table.concat(pc, ", "))
    local rc = {}
    for k, v in pairs(BV.relicChecks or {}) do rc[#rc + 1] = k .. " " .. v end
    BV.klog("relics: checks on relic IDs " .. (#rc > 0 and table.concat(rc, ", ") or "none") .. " | mayhem slot " ..
      tostring(RL.slotHow) .. ", locked " .. tostring(RL.mayhemLocked()) .. ", mod " .. tostring(rawget(_G, "CSM_MAYHEM_P1") ~= nil) ..
      " | " .. RL.statText())
    -- why each AR optic in the M15's list is locked or not: the row (gun) that unlocks it, its progress / needed
  end

  -- Unlock text (v1.31). The menus build "Unlocked at Level N" from PROGRESSION.getunlockrank (e674987666a8f72d)
  -- and show "Unlocked in Armory" for an item it has no rank for (Frost Blast, Tesla Storm, ... before their custom
  -- levels). Every item with a Blood Vials level now gets rank = level - 1, so the game writes its own "Unlocked at
  -- Level N". The "Permanently Unlocked" label comes from isitempermanentlyunlocked (46fc982e0fbfc242): it now always
  -- says no (the user's call: that label goes everywhere).
  local function rankWrap(orig, tag)
    return function(...)
      if BV.probing then if BV.probeTag == tag then BV.hit = true end; return nil end
      if BV.enabled then
        BV.rankCalls = (BV.rankCalls or 0) + 1
        -- what the game passes, for the log (types, and short values): the first 3 calls and every 50th
        if BV.rankCalls <= 3 or BV.rankCalls % 50 == 0 then
          local d = {}
          for i = 1, math.min(select("#", ...), 4) do
            local v = select(i, ...)
            local okS, s = pcall(tostring, v)
            d[#d + 1] = type(v) .. " " .. (okS and tostring(s):sub(1, 28) or "?")
          end
          BV.rankLast = table.concat(d, ", ")
        end
        -- v1.36: the item may come as a loot ID, a ref string or a hashed ref (LV.idOf)
        for i = 1, select("#", ...) do
          local id = LV.idOf((select(i, ...)))
          local need = id and LV.need(id)
          if need then BV.rankAsks = (BV.rankAsks or 0) + 1; return need - 1 end
        end
      end
      return orig(...)
    end
  end
  local function permWrap(orig, tag)
    return function(...)
      if BV.probing then if BV.probeTag == tag then BV.hit = true end; return false end
      if BV.enabled then BV.permAsks = (BV.permAsks or 0) + 1; return false end
      return orig(...)
    end
  end
  BV.rankWrap, BV.permWrap = rankWrap, permWrap

  -- Lock state and level text on the weapon screens (v1.39), from the in-game trace (2026-11-08):
  -- * PROGRESSION bd17a9fde01bef42 (name unknown; exported next to isunlockedwithid and the unlock exception) answered
  --   TRUE for Echo 12, XM325 and M34 Novaline while we lock them. The gun list then drew them without a lock
  --   ("LEVEL 1/43") and the screen never built the unlock text. For the A.R.C. M1, which showed its text, the screen
  --   went on to the PROGRESSION checks that build it. gateWrap answers false for anything Blood Vials locks.
  -- * PROGRESSION 2f511c84503e24fd returned the text itself ("Unlocked at Lev..."). textWrap returns
  --   "Unlocked at Level N" with OUR level for items in our level list (so custom levels, e.g. Frost Blast 36, show),
  --   and the game's own text for everything else.
  local function idsIn(...)
    local out = {}
    for i = 1, math.min(select("#", ...), 4) do
      local v = select(i, ...)
      if v ~= nil and type(v) ~= "table" and type(v) ~= "function" then
        local id = LV.anyId(v)   -- v1.40: guns by ref / hash too (the seasonal ones had no lock)
        if id then out[#out + 1] = id end
      end
    end
    return out
  end
  local function gateWrap(orig, tag)
    return function(...)
      if BV.probing then if BV.probeTag == tag then BV.hit = true end; return false end
      if BV.enabled then
        for _, id in ipairs(idsIn(...)) do
          if id > 0 and isLocked(id) then BV.gateAsks = (BV.gateAsks or 0) + 1; return false end
        end
      end
      return orig(...)
    end
  end
  local function textWrap(orig, tag)
    return function(...)
      if BV.probing then if BV.probeTag == tag then BV.hit = true end; return "" end
      if BV.enabled then
        for _, id in ipairs(idsIn(...)) do
          local need = id > 0 and LV.need(id)
          if need then BV.textAsks = (BV.textAsks or 0) + 1; return "Unlocked at Level " .. need end
        end
      end
      return orig(...)
    end
  end
  BV.gateWrap, BV.textWrap = gateWrap, textWrap

  -- Item names for the crate (the game's localized weapon name when it can be read)
  local function itemName(id, ref, fallback)
    ref = ref or POOL[id] or (BP.data() and BP.bases[id])
    local name
    pcall(function()
      local W = g("WEAPON")
      local f = W and (W.getlootweaponname or W[H(K_LOOT_WEAPON_NAME)])
      if type(f) == "function" then name = f(ref, id) end
    end)
    if name == nil then pcall(function()
      local info = g("WEAPON")[H(K_WEAPON_INFO)](CTRL, id)
      if type(info) == "table" then name = info.lootName or info[H("97d1d8b7b45027b4")] end
    end) end
    if name ~= nil then
      local loc = name
      pcall(function() local f = g("Engine")[H(K_LOCALIZE)]; if type(f) == "function" then loc = f(name) end end)
      if type(loc) == "string" and loc ~= "" then return loc end
      if type(name) == "string" and name ~= "" then return name end
    end
    if fallback then return fallback end
    local raw = ref or tostring(id)
    local base = raw:gsub("^sat_%a+_", "")
    return base:sub(1, 1):upper() .. base:sub(2)
  end
  local function toast(title, body)
    pcall(function() g("NOTIFICATIONS")[H(K_NOTIFY)](CTRL, title, { body = body }) end)
  end

  -- ---------------------------------------------------------------------------------------------------
  -- Crate reveal: a full-screen mystery-box opening that plays after a crate gives you a weapon.
  -- Art (mods\blood_vials\images, 1024x1024 plates rendered from one camera so they stack exactly):
  --   mbox_body (box without lid), mbox_lid, mbox_glow, mbox_beam, mbox_shadow, mbox_dot (soft dot),
  --   mbox_qface + mbox_qbloom (the two carved "?" faces and their bloom, white, tinted here)
  --   optional: mbox_lid_00 .. mbox_lid_11 (lid-open frames), used when REVEAL.lidMode = "frames"
  -- Test it without spending vials: set preview = true below; the CRATES page and the Seasonal Crate row in Debug
  -- Options then offer "Preview reveal" (or from the console: lua BloodVials.preview()).
  local REVEAL = {
    preview = false,           -- debug: show the "Preview reveal" button (off by default)
    plate = 1100,              -- drawn size of the 1024 plates (screen is 1920x1080)
    plateY = 110,              -- vertical offset of the plate centre from screen centre
    dim = 1.0,                 -- backdrop base: fully covers the menu (its colour is bg.void)
    -- Layered backdrop under the box (v1.7). Every layer can be switched off. Art in images\: mbox_bg_glow (violet
    -- cloud), mbox_bg_smoke (speckled smoke band), mbox_bg_wisp (curling smoke), mbox_bg_ember, mbox_bg_ellipse,
    -- mbox_vig_t/b/l/r (black edge gradients) are copies of the Ashes mod's aotd_inv_glow / aotd_ee_wisp /
    -- aotd_wisp / aotd_ember / aotd_glow_ellipse / aotd_grad_*; mbox_ray is a soft white strip made in code.
    bg = {
      -- v1.42: the user's forest image (images\mbox_bg_forest.png, 1920x1080) behind every crate
      backdrop = "map",        -- "void" or "map" (images\<mapImage>.png, full screen; missing -> void)
      mapImage = "mbox_bg_forest",
      void = { 0.045, 0.025, 0.075 },   -- the Dark Aether base colour (deep purple-black)
      mapDim = 0.35,           -- "map": how dark the image is pushed (void colour over it), so the box stands out
      smoke = true,            -- 3 big soft smoke layers drifting and breathing
      smokeRGB = { 0.52, 0.64, 0.86 },   -- v1.42: cool blue, to sit in the forest's fog (was violet 0.62, 0.52, 0.78)
      floor = true,            -- soft light pool under the box
      floorRGB = { 0.55, 0.62, 0.80 },
      embers = true, emberCount = 20, wispShare = 0.3,   -- rising embers / aether wisps (count capped here)
      rays = true,             -- 3 light shafts angled down onto the box, breathing
      rayRGB = { 0.80, 0.84, 0.95 },
      vignette = true, vignetteAlpha = 0.9,
      tint = 0.45,             -- from the season flash on: how far smoke, floor and rays lean to the season colour
      tintMs = 700,
    },
    bodyTint = { 0.80, 0.84, 0.90 },
    boxColor = { 0.35, 0.75, 1.00 },   -- the box's own blue-cyan light
    shakeStart = 250, shakeEnd = 1450, shakePx = 9,
    flashAt = 1450, flashMs = 520, flashPeak = 0.75,
    lidAt = 1450, lidMs = 520, lidMode = "lift",  -- "lift" (single lid plate) or "frames" (mbox_lid_00..11)
    lidFrames = 12,
    beamAt = 1650, beamMs = 350,
    iconAt = 1950, iconMs = 800, iconW = 520, iconH = 260, iconY = -230,
    relicIcon = 260,                   -- square pictures (relics, perks, ammo mods, field upgrades), as tall as a gun's, px
    nameAt = 2300,
    hold = 6500, fadeMs = 300,
    qFace = { 0.45, 0.85, 1.00 },      -- colour of the glowing "?" faces
    -- the box art per crate (v1.9): a reveal with r.box = "abox" uses its own box (v1.24: Black Ops 3's Shadows of
    -- Evil magic box, rendered by tools\crate_plates_bo3.py; until then BO4's Blood of the Dead box, kept in
    -- tools\bak_abox_bo4). Images abox_body / _lid / _glow / _beam / _shadow, abox_lid_00..12. Missing art -> the
    -- standard box. top = the box's top edge in plate px (where the weapon rises from).
    boxes = {
      mbox = { prefix = "mbox", qfaces = true, lidMode = nil, top = 470 },
      -- the frames are the box's real open animation (zm_zod_magic_box_open, 30 frames = 1 s), the whole box per
      -- frame (fullFrames: the body plate isn't drawn): the hands unclasp, then the lid rises. top: the closed box's
      -- top edge is at 350 px (BO4's was 377 with top 420), same 43 px inside
      abox = { prefix = "abox", qfaces = false, lidMode = "frames", tint = { 1, 1, 1 }, top = 393,
        fullFrames = true, lidFrames = 13, lidMs = 1000 },
      -- the Relic Crate (v1.33): Black Ops 4's Blood of the Dead box (the Apothicon box until v1.24, rendered by
      -- tools\crate_plates_bo4.py; images rbox_*, copied from tools\bak_abox_bo4). Its 13 frames are the whole box
      -- (the locks unlock, then the lid opens); the closed box's top edge is at 377 px, so top 420 as before.
      rbox = { prefix = "rbox", qfaces = false, lidMode = "frames", tint = { 1, 1, 1 }, top = 420,
        fullFrames = true, lidFrames = 13, lidMs = 800 },
    },
    qIdle = 0.30, qFlicker = 0.25,     -- "?" brightness before the box charges, and how much they flicker
    labelY = 335, nameY = 388, nameH = 64, subY = 445, textMaxW = 1500,
    -- sounds: { ms, SOUND_SETS group, sound name [, blueprint = name used for a blueprint instead] }.
    -- All are the game's own menu sounds (ui\soundsets.lua); edit freely, a missing one is skipped.
    -- v1.41: fuller, with the event menus' own mystery box (seasonalEvent mysteryBoxMagicBoxOpen / ItemUnlock), a
    -- battle pass token spin during the charge and a celebration after the name. Times: charge 250, lid 1450, item
    -- 1950, name 2300.
    sfx = {
      { 0, "storefront", "windowAppear" },
      { 250, "battlePass", "bpIntroBootup" },
      { 700, "battlePass", "bpTokenSpinMain" },
      { 1300, "battlePass", "bpTokenSpinEnd" },
      { 1450, "seasonalEvent", "mysteryBoxMagicBoxOpen" },
      { 1450, "wpnUnlock", "wpnUnlockSlam" },
      { 1450, "storefront", "smokePoof" },
      { 1650, "wpnUnlock", "wpnUnlockSizzle" },
      { 1950, "discoverNewitemCP", "wpnLegendary", blueprint = "wpnEpic" },
      { 1950, "seasonalEvent", "mysteryBoxItemUnlock" },
      { 2300, "wpnUnlock", "wpnUnlockSlamFinal" },
      { 2650, "battlePass", "bpItemCelebrateTier" },
    },
    -- extra sounds per crate (r.crate), mixed into the list above by time
    sfxCrate = {
      seasonal = { { 2300, "storefront", "smokeCardSlam" } },
      blueprint = { { 1950, "inventory", "lootRevealCompleteSpecial" } },
      augment = { { 250, "zmEquipMenu", "ggPackNew" }, { 1950, "zmEquipMenu", "augmentSelect" },
        { 2300, "zmEquipMenu", "ggSelectEpic" } },
      relic = { { 250, "zmRelics", "activate_tier_1" }, { 1450, "zmRelics", "activate_tier_2" },
        { 1950, "zmRelics", "activate_tier_3" } },
      apothicon = { { 250, "prestige", "prestigeFillStart" }, { 1450, "prestige", "prestigeOpenPermanentUnlock" },
        { 2300, "zmEquipMenu", "ggSelectUltra" } },
    },
    -- the Debug Options "Crate Sound Test" row: candidates you can audition one at a time ({ group, name })
    sfxTest = {
      { "seasonalEvent", "mysteryBoxMagicBoxOpen" }, { "seasonalEvent", "mysteryBoxItemUnlock" },
      { "seasonalEvent", "eventMasterySecretUnlocked" }, { "seasonalEvent", "trophyHuntMasteryRewardUnlock" },
      { "battlePass", "bpIntroBootup" }, { "battlePass", "bpTokenSpinMain" }, { "battlePass", "bpTokenSpinEnd" },
      { "battlePass", "bpItemCelebrateTier" }, { "battlePass", "bpPurchaseCelebration" },
      { "battlePass", "bpUnlockBlackCellSingle" }, { "battlePass", "bpHVTVFX" }, { "battlePass", "bpCheckmarkSlam" },
      { "storefront", "windowAppear" }, { "storefront", "smokePoof" }, { "storefront", "smokeCardSlam" },
      { "storefront", "cardFlipFirst" }, { "storefront", "purchaseBundleComplete" },
      { "wpnUnlock", "wpnUnlockSlam" }, { "wpnUnlock", "wpnUnlockSizzle" }, { "wpnUnlock", "wpnUnlockSlamFinal" },
      { "discoverNewitemCP", "wpnLegendary" }, { "discoverNewitemCP", "wpnEpic" }, { "discoverNewitemCP", "wpnRare" },
      { "inventory", "lootRevealProgressLoop" }, { "inventory", "lootRevealCompleteSpecial" },
      { "inventory", "lootRevealCompleteGeneric" }, { "endgameSplash", "dmzWeaponCaseCelebration" },
      { "aarChallenge", "lootCardLegendary" }, { "aarChallenge", "lootCardEpic" },
      { "zmRelics", "activate_tier_1" }, { "zmRelics", "activate_tier_2" }, { "zmRelics", "activate_tier_3" },
      { "zmEquipMenu", "ggPackNew" }, { "zmEquipMenu", "augmentSelect" }, { "zmEquipMenu", "ggSelectEpic" },
      { "zmEquipMenu", "ggSelectLegendary" }, { "zmEquipMenu", "ggSelectUltra" }, { "zmIngame", "gg_get" },
      { "prestige", "prestigeFillStart" }, { "prestige", "prestigeOpenPermanentUnlock" },
      { "prestige", "prestigeSuccessSplash" }, { "unlocks", "operatorReveal" }, { "ztronIngame", "bossDefeated" },
    },
    -- The Ashes mystery box's own sounds (v1.8; Assets\Audio\Origins Box replaces them with the Origins box).
    -- Played with Engine.playSound(alias hash), the call the game's own luielement.lua uses; it returns an id that
    -- Engine.stopSound(id) stops. Hashes are FNV-1a 64 of the lowercased alias (in-game Lua has no 64-bit ints).
    -- mode "box": these sounds, each cue falling back to its old menu sound if the box sound gives no id back;
    -- mode "ui": only the menu sounds of `sfx` above. Volume can't be set (playSound takes no volume).
    sounds = {
      -- "ui" (default since the in-game test of v1.8: the box sounds were silent in the menus, most likely not
      -- loaded outside a match, yet gave an id back so the per-cue fallback never kicked in)
      mode = "ui",
      -- ambience: each loop replaces the one before it; all loops stop when the fade-out starts
      loops = {
        { 0, "evt_sat_mysterybox_amb_closed_lp", "b8f65e16b6f184d9" },
        { 250, "evt_sat_mysterybox_amb_low_lp", "993ebab65b1df8c3" },     -- charging starts (shakeStart)
        { 1050, "evt_sat_mysterybox_amb_high_lp", "212727bd76d5413d" },   -- near the end of the charge
      },
      -- one-shots: { ms, alias, hash, ui = fallback { group, name [, blueprint = name] } }
      cues = {
        { 250, "evt_sat_mysterybox_slam_shake", "0b23510ba87c19ed", ui = { "battlePass", "bpIntroBootup" } },
        { 1450, "evt_sat_mysterybox_door_open", "39eaed2e752ec666", ui = { "wpnUnlock", "wpnUnlockSlam" } },
        { 1450, "evt_sat_mysterybox_open_elec", "f205f85f59498947", ui = { "storefront", "smokePoof" } },
        { 1950, "evt_sat_mysterybox_rise", "3703abc4a93228d4", ui = { "discoverNewitemCP", "wpnLegendary", blueprint = "wpnEpic" } },
        { 2300, "evt_sat_mysterybox_jingle", "3b6b4c27bb52b1a4", ui = { "wpnUnlock", "wpnUnlockSlamFinal" } },
      },
      close = { "evt_sat_mysterybox_close", "8a3b201537a444ff" },   -- at the fade-out (hold)
    },
  }
  -- Plays one of the game's UI sounds by group and name: Engine.playSound(SOUND_SETS[group][name]), the call the
  -- game's own tabs use (menutab.lua). The last miss is kept for the Blood Vials row.
  local SFX = {}
  BV.SFX = SFX
  function SFX.play(set, name)
    local played = false
    local ok, e = pcall(function()
      local S = g("SOUND_SETS")
      local alias = type(S) == "table" and type(S[set]) == "table" and S[set][name]
      if alias == nil or alias == false then SFX.miss = set .. "." .. name; return end
      local E = g("Engine")
      local f = type(E) == "table" and (E[H("1c4146ba76d0f982")] or E.PlaySound or E.playSound)
      if type(f) ~= "function" then SFX.miss = "no Engine.playSound"; return end
      f(alias)
      SFX.played = (SFX.played or 0) + 1
      played = true
    end)
    if not ok then SFX.miss = set .. "." .. name .. ": " .. tostring(e) end
    return played
  end
  -- The box sounds (REVEAL.sounds): play an alias by hash and keep the id Engine.playSound gives back, so it can
  -- be stopped. Every id the current reveal started is in SFX.live; SFX.stopAll() stops them all.
  SFX.live = {}
  function SFX.playAlias(hex, name)
    local id
    local ok, e = pcall(function()
      local E = g("Engine")
      local f = type(E) == "table" and (E[H("1c4146ba76d0f982")] or E.PlaySound or E.playSound)
      if type(f) ~= "function" then error("no Engine.playSound") end
      id = f(H(hex))
    end)
    if not ok then SFX.boxErr = name .. ": " .. tostring(e); return nil end
    if id == nil or id == false or id == 0 or id == -1 then SFX.boxNoId = name; return nil end
    SFX.boxPlayed = (SFX.boxPlayed or 0) + 1
    SFX.live[#SFX.live + 1] = id
    return id
  end
  function SFX.stop(id)
    if id == nil then return end
    pcall(function()
      local E = g("Engine")
      local f = type(E) == "table" and (E[H("5c738a7a46edbb34")] or E.StopSound or E.stopSound)
      if type(f) == "function" then f(id) end
    end)
    for i = #SFX.live, 1, -1 do if SFX.live[i] == id then table.remove(SFX.live, i) end end
  end
  function SFX.stopAll()
    local ids = SFX.live
    SFX.live = {}
    for _, id in ipairs(ids) do
      pcall(function()
        local E = g("Engine")
        local f = type(E) == "table" and (E[H("5c738a7a46edbb34")] or E.StopSound or E.stopSound)
        if type(f) == "function" then f(id) end
      end)
    end
  end
  -- Season colours (flash + name tint). Unknown season -> white.
  local SEASON_RGB = {
    [1] = { 1.00, 0.55, 0.15 }, [2] = { 0.20, 0.85, 0.80 }, [3] = { 0.65, 0.35, 1.00 },
    [4] = { 1.00, 0.25, 0.25 }, [5] = { 0.35, 0.95, 0.40 }, [6] = { 1.00, 0.80, 0.25 },
  }
  -- Which season each pool weapon came from (follows the POOL grouping above; edit freely).
  local SEASON_OF = {
    [97897] = 1, [97917] = 1, [113930] = 1, [126192] = 1, [98043] = 1, [116617] = 1, [97997] = 1,
    [119844] = 2, [122673] = 2, [102705] = 2, [119843] = 2, [116618] = 2, [119845] = 2,
    [126468] = 3, [125186] = 3, [125262] = 3, [126466] = 3, [126469] = 3, [132831] = 3,
    [131330] = 3, [133345] = 3, [133344] = 3,
    [130905] = 4, [136509] = 4, [132997] = 4, [136627] = 4,
    [142181] = 5, [142433] = 5, [136390] = 5,
    [121205] = 1, [122685] = 2, [126467] = 3, [133368] = 4, [142463] = 6,
    [142462] = 6, [138772] = 5, [138728] = 5, [142465] = 6, [136389] = 5, [142464] = 6,
  }

  local function C3(t) return math.floor(t[1] * 255 + 0.5) * 65536 + math.floor(t[2] * 255 + 0.5) * 256 + math.floor(t[3] * 255 + 0.5) end
  local MATS = {}
  local function mat(n)
    local m = MATS[n]
    if m == nil then
      local ok, r = pcall(function() return g("RegisterMaterial")(g("CLUA").PushXHashAsset(n)) end)
      m = ok and r or false
      MATS[n] = m
    end
    return m or nil
  end
  local function addBlend()
    local B = g("BLEND_MODE")
    return B and B.addWithAlpha
  end
  -- centre-anchored placement (cx, cy = offset from the parent's centre)
  local function place(e, cx, cy, w, h)
    e:SetAnchorsAndPosition(0.5, 0.5, 0.5, 0.5, cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2)
  end
  local function pivotCentre(e)
    pcall(function() e:SetHorizontalPivot(1); e:SetVerticalPivot(1) end)
  end
  local function image(parent, name, o)
    o = o or {}
    local e = g("LUI").UIImage.new()
    local m = mat(name)
    if m then e:setImage(m, 0) end
    if o.rgb then e:SetRGB(o.rgb, 0) end
    if o.add then local b = addBlend(); if b then e:SetBlendMode(b) end end
    e:SetAlpha(o.a or 1, 0)
    pcall(function() e:SetHandleMouse(false) end)
    parent:addElement(e)
    return e
  end
  local function group(parent)
    local e = g("LUI").UIElement.new()
    e:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)
    pcall(function() e:SetHandleMouse(false) end)
    parent:addElement(e)
    return e
  end

  -- Text drawn with the glyph images Kronos already ships (Assets\Images\soe_rf_33 .. soe_rf_126)
  local ADV_RF = { [32] = 0.1667, [33] = 0.1842, [34] = 0.307, [35] = 0.4298, [36] = 0.3684, [37] = 0.5263, [38] = 0.4912, [39] = 0.1842,
    [40] = 0.1842, [41] = 0.1842, [42] = 0.2895, [43] = 0.386, [44] = 0.1491, [45] = 0.2281, [46] = 0.1579, [47] = 0.2544, [48] = 0.3684,
    [49] = 0.2895, [50] = 0.3684, [51] = 0.3684, [52] = 0.3596, [53] = 0.3684, [54] = 0.3684, [55] = 0.3333, [56] = 0.3684, [57] = 0.3684,
    [58] = 0.1579, [59] = 0.1579, [60] = 0.386, [61] = 0.386, [62] = 0.386, [63] = 0.3246, [64] = 0.4825, [65] = 0.3596, [66] = 0.3684,
    [67] = 0.3684, [68] = 0.3684, [69] = 0.307, [70] = 0.307, [71] = 0.3684, [72] = 0.3684, [73] = 0.1579, [74] = 0.3246, [75] = 0.3684,
    [76] = 0.307, [77] = 0.4649, [78] = 0.3684, [79] = 0.3684, [80] = 0.3421, [81] = 0.3684, [82] = 0.3684, [83] = 0.3684, [84] = 0.3246,
    [85] = 0.3684, [86] = 0.3596, [87] = 0.5351, [88] = 0.3596, [89] = 0.3246, [90] = 0.3333, [91] = 0.2018, [92] = 0.2544, [93] = 0.2368,
    [94] = 0.2456, [95] = 0.3772, [96] = 0.3246, [97] = 0.3246, [98] = 0.3246, [99] = 0.3246, [100] = 0.3246, [101] = 0.3246,
    [102] = 0.2281, [103] = 0.3246, [104] = 0.3246, [105] = 0.1491, [106] = 0.1491, [107] = 0.2895, [108] = 0.1491, [109] = 0.4825,
    [110] = 0.3246, [111] = 0.3246, [112] = 0.3246, [113] = 0.3246, [114] = 0.2193, [115] = 0.3246, [116] = 0.2281, [117] = 0.3246,
    [118] = 0.307, [119] = 0.4386, [120] = 0.307, [121] = 0.307, [122] = 0.2807, [123] = 0.2105, [124] = 0.1053, [125] = 0.2105,
    [126] = 0.2719 }
  -- one line of text centred on (cx, cy); shrinks to fit maxW. track = extra letter spacing (x height).
  local function textLine(parent, str, cx, cy, h, o)
    o = o or {}
    str = tostring(str or "")
    local track = o.track or 0.04
    local total = 0
    for i = 1, #str do local a = ADV_RF[str:byte(i)]; if a then total = total + (a + track) * h end end
    if total <= 0 then total = 1 end
    if o.maxW and total > o.maxW then h = h * o.maxW / total; total = o.maxW end
    if o.left then cx = o.left - 960 + total / 2 end   -- left-aligned at x = o.left (1920-wide parent)
    local row = g("LUI").UIElement.new()
    place(row, cx, cy, total, h)
    pivotCentre(row)
    pcall(function() row:SetHandleMouse(false) end)
    parent:addElement(row)
    local blend = o.add and addBlend() or nil
    local x = 0
    for i = 1, #str do
      local c = str:byte(i)
      local a = ADV_RF[c]
      if a then
        local gw = a * h
        if c ~= 32 then
          local e = g("LUI").UIImage.new()
          local m = mat("soe_rf_" .. c)
          if m then e:setImage(m, 0) end
          if blend then e:SetBlendMode(blend) end
          if o.rgb then e:SetRGB(o.rgb, 0) end
          e:SetAnchorsAndPosition(0, 1, 0, 1, x, x + gw, 0, h)
          row:addElement(e)
        end
        x = x + gw + track * h
      end
    end
    row:SetAlpha(o.a or 1, 0)
    return row
  end

  -- The weapon's loot icon. The field that holds it isn't named anywhere in Kronos's Lua, so this tries the
  -- image fields loot bundles use and logs which one worked (DebugPrint "[BloodVials] reveal icon ...").
  local ICON_FIELDS = { "2ab612888528489a", "e59edf4aa63ee0ff" }
  local ICON_NAMES = { "image", "icon", "lootImage", "previewImage", "weaponImage" }
  -- Each weapon's own icon image, from the "#image" field of its weapondata bundle in the game files
  -- (source\scriptbundle\weapondata\<name>.json). Tried first; the lookups below are only a fallback.
  local ICON_IMAGE = {
    [97897] = "sat_icon_weapon_sat_ar_macaw_material", [97917] = "sat_icon_weapon_sat_lm_typhon_material",
    [113930] = "sat_icon_weapon_sat_me_ballistic_knife_material", [126192] = "ui_icon_weapon_usugar9",
    [98043] = "sat_icon_weapon_sat_sm_hyena_material", [116617] = "sat_icon_weapon_sat_sm_bengal_material",
    [97997] = "sat_icon_weapon_sat_sn_aden_material", [119844] = "sat_icon_weapon_sat_ar_egret_material",
    [122673] = "sat_icon_weapon_sat_me_saiph_material", [102705] = "sat_icon_weapon_sat_sh_shepherd_material",
    [119843] = "sat_icon_weapon_sat_sm_gecko_material", [116618] = "sat_icon_weapon_sat_ar_heron_material",
    [119845] = "sat_icon_weapon_sat_dm_solomon_material", [126468] = "sat_icon_weapon_sat_ar_finch_material",
    [125186] = "sat_icon_weapon_sat_pi_alcor_material", [125262] = "sat_icon_weapon_sat_sm_bear_material",
    [126466] = "sat_icon_weapon_sat_sn_coral_material", [126469] = "sat_icon_weapon_sat_me_nashira_material",
    [132831] = "sat_icon_weapon_t10_sm_mammoth_material", [131330] = "sat_icon_weapon_sat_ar_kiwi_mp",
    [133345] = "sat_icon_weapon_sat_dm_samar_mp", [133344] = "sat_icon_weapon_sat_sm_marmot_mp",
    [130905] = "sat_icon_weapon_sat_ar_albatross", [136509] = "sat_icon_weapon_sat_me_elnath",
    [132997] = "sat_icon_weapon_sat_me_maru", [136627] = "sat_icon_weapon_sat_sm_stoat",
    [142181] = "sat_icon_weapon_sat_ar_wren", [142433] = "sat_icon_weapon_sat_lm_hildr",
    [136390] = "sat_icon_weapon_sat_sm_serval",
    [121205] = "sat_icon_weapon_sat_sl_crossbow_material", [122685] = "sat_icon_weapon_sat_sl_nembus_material",
    [126467] = "sat_icon_weapon_sat_sl_sargas_material", [133368] = "sat_icon_weapon_sat_sl_atria_mp",
    [142463] = "sat_icon_weapon_sat_sl_carina", [142462] = "sat_icon_weapon_sat_ar_emu",
    [138772] = "sat_icon_weapon_sat_dm_tasman", [138728] = "sat_icon_weapon_sat_sh_terrier",
    [142465] = "sat_icon_weapon_sat_sm_civet", [136389] = "sat_icon_weapon_sat_me_castor",
    [142464] = "sat_icon_weapon_sat_me_wasat",
  }
  local function iconCandidates(id, image)
    local tables, out = {}, {}
    if type(image) == "string" and image ~= "" then out[#out + 1] = { "given", image } end
    -- or an image reference built from a hash (RL.icon); only the VM's hash type, as setIcon requires
    if image ~= nil and tostring(type(image)):sub(1, 5) == "xhash" then out[#out + 1] = { "given hash", image } end
    if ICON_IMAGE[id] then out[#out + 1] = { "weapondata", ICON_IMAGE[id] } end
    local W = g("WEAPON")
    pcall(function() local t = W[H(K_WEAPON_INFO)](CTRL, id); if type(t) == "table" then tables[#tables + 1] = { "info", t } end end)
    pcall(function() local t = W[H("9d1e6b704f84cf8b")](id); if type(t) == "table" then tables[#tables + 1] = { "byLoot", t } end end)
    for _, src in ipairs(tables) do
      local t = src[2]
      for _, f in ipairs(ICON_FIELDS) do
        local ok, v = pcall(function() return t[H(f)] end)
        if ok and v ~= nil then out[#out + 1] = { src[1] .. "." .. f, v } end
      end
      for _, f in ipairs(ICON_NAMES) do
        local ok, v = pcall(function() return rawget(t, f) end)
        if ok and v ~= nil then out[#out + 1] = { src[1] .. "." .. f, v } end
      end
    end
    return out
  end
  -- Only non-empty strings and the VM's hash values (type() starts with "xhash") may reach RegisterMaterial,
  -- and only a material RegisterMaterial returned may reach setImage: a wrong type there can crash the game
  -- natively instead of raising an error pcall could catch (same rule as the Ashes scoreboard's portraits).
  local function isRefLike(v)
    if type(v) == "string" then return v ~= "" end
    return tostring(type(v)):sub(1, 5) == "xhash"
  end
  local function setIcon(e, id, image)
    for _, c in ipairs(iconCandidates(id, image)) do
      local v = c[2]
      local m
      if type(v) == "string" then
        if v ~= "" then m = mat(v) end
      elseif isRefLike(v) then
        local ok, r = pcall(function() return g("RegisterMaterial")(v) end)
        if ok then m = r end
      end
      if m ~= nil and pcall(function() e:setImage(m, 0) end) then
        note("reveal icon from " .. c[1] .. " (" .. type(v) .. ")")
        return true
      end
    end
    note("reveal: no icon found for " .. tostring(id))
    return false
  end

  local function clamp01(t) return t < 0 and 0 or t > 1 and 1 or t end
  local function ease(t) t = clamp01(t); return t * t * (3 - 2 * t) end
  local function easeOut(t) t = clamp01(t); return 1 - (1 - t) ^ 3 end
  local function easeBack(t)
    t = clamp01(t) - 1
    return t * t * (2.70158 * t + 1.70158) + 1
  end
  local function span(now, at, ms) return (now - at) / ms end
  local seed = 12345
  local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 end

  -- ---------------------------------------------------------------------------------------------------
  -- Reveal backdrop (v1.7): built under the box, animated from the reveal's frame() through the returned update.
  -- Positions are offsets from the screen centre (1920x1080), as place() takes them.
  local BGX = {}
  BV.REVEAL = REVEAL   -- so the settings can be changed at runtime (and by the offline tests)
  function BGX.mix(a, b, k) return { a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k, a[3] + (b[3] - a[3]) * k } end
  function BGX.build(ov, r, P, plateXY)
    local B = P.bg
    local L = { smoke = {}, rays = {}, parts = {} }
    local add = { add = true, a = 0 }
    -- 5. optional map screenshot under everything ("map" mode; a missing image falls back to "void")
    local mapImg = B.mapImage or "mbox_bg_ashes"
    if B.backdrop == "map" and mat(mapImg) then
      L.map = image(ov, mapImg, { a = 0 })
      L.map:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)
    end
    L.mode = L.map and "map" or "void"
    -- 1. base: the void colour (over the map it darkens it instead)
    L.dim = image(ov, "soe_white", { rgb = C3(B.void), a = 0 })
    L.dim:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)
    L.dimA = L.map and B.mapDim or P.dim
    -- 1. big soft smoke: { image, w, h, x, y, drift x/y px per s, alpha, breathing period ms, phase }
    if B.smoke then
      for _, s in ipairs({
        { "mbox_bg_glow", 1900, 1150, -260, -40, 14, -4, 0.75, 5200, 0.0 },
        { "mbox_bg_smoke", 2400, 680, 200, 250, -22, 0, 0.85, 4100, 1.7 },
        { "mbox_bg_smoke", 2200, 560, -150, -300, 18, 3, 0.65, 6100, 3.1 },
      }) do
        local e = image(ov, s[1], add)
        L.smoke[#L.smoke + 1] = { e = e, s = s }
      end
    end
    -- 3. vignette: the four black edge gradients (under the rays and embers, so it doesn't swallow them)
    if B.vignette then
      L.vig = {}
      for _, v in ipairs({ { "mbox_vig_t", 0, -540 + 170, 1920, 340 }, { "mbox_vig_b", 0, 540 - 170, 1920, 340 },
        { "mbox_vig_l", -960 + 240, 0, 480, 1080 }, { "mbox_vig_r", 960 - 240, 0, 480, 1080 } }) do
        local e = image(ov, v[1], { a = 0 })
        place(e, v[2], v[3], v[4], v[5])
        L.vig[#L.vig + 1] = e
      end
    end
    -- 3. light shafts angled down onto the box: { x offset from the box, rotation (deg), width, alpha, period }
    L.boxX, L.boxY = plateXY(512, 470)
    if B.rays then
      for _, s in ipairs({ { -300, 12, 420, 0.55, 3300 }, { 0, 0, 520, 0.42, 4200 }, { 300, -12, 420, 0.55, 2900 } }) do
        local e = image(ov, "mbox_ray", add)
        pivotCentre(e)
        L.rays[#L.rays + 1] = { e = e, s = s }
      end
    end
    -- 1. floor: a soft light pool under the box
    if B.floor then
      L.floor = image(ov, "mbox_bg_ellipse", add)
      local fx, fy = plateXY(512, 690)
      place(L.floor, fx, fy, 1500, 260)
    end
    -- 2. rising embers and aether wisps, recycled at the bottom when they leave the top
    if B.embers then
      local n = math.min(B.emberCount or 20, 40)
      for i = 1, n do
        local wisp = rnd() < (B.wispShare or 0.3)
        local p = { wisp = wisp, e = image(ov, wisp and "mbox_bg_wisp" or "mbox_bg_ember", wisp and add or { a = 0 }) }
        BGX.spawn(p, true)
        L.parts[i] = p
      end
    end
    local season = SEASON_RGB[r.season]
    function L.update(now, inA)
      local t = now / 1000
      local k = season and B.tint * ease(span(now, P.flashAt, B.tintMs)) or 0   -- 4. season wash from the flash on
      L.dim:SetAlpha(L.dimA * inA, 0)
      if L.map then L.map:SetAlpha(inA, 0) end
      local smokeC = C3(season and BGX.mix(B.smokeRGB, season, k) or B.smokeRGB)
      for _, x in ipairs(L.smoke) do
        local s = x.s
        place(x.e, s[4] + s[6] * t, s[5] + s[7] * t, s[2], s[3])
        x.e:SetRGB(smokeC, 0)
        x.e:SetAlpha(s[8] * (0.65 + 0.35 * math.sin(now / s[9] * 6.2832 + s[10])) * inA, 0)
      end
      local rayC = C3(season and BGX.mix(B.rayRGB, season, k) or B.rayRGB)
      for _, x in ipairs(L.rays) do
        local s = x.s
        -- bright end at the top edge of the screen, fading out just past the box top
        place(x.e, L.boxX + s[1], -540 + 500, s[3], 1000)
        pcall(function() x.e:SetZRotation(s[2], 0) end)
        x.e:SetRGB(rayC, 0)
        x.e:SetAlpha(s[4] * (0.7 + 0.3 * math.sin(now / s[5] * 6.2832)) * inA, 0)
      end
      if L.floor then
        L.floor:SetRGB(C3(season and BGX.mix(B.floorRGB, season, k) or B.floorRGB), 0)
        L.floor:SetAlpha(0.55 * (0.85 + 0.15 * math.sin(now / 2600 * 6.2832)) * inA, 0)
      end
      for _, p in ipairs(L.parts) do
        p.y = p.y - p.speed * 0.016
        if p.y < -600 then BGX.spawn(p, false) end
        local x = p.x + math.sin(t * p.swayF * 6.2832 + p.phase) * p.sway
        place(p.e, x, p.y, p.w, p.h)
        if p.wisp then p.e:SetRGB(smokeC, 0) end
        p.e:SetAlpha(p.a * inA, 0)
      end
      for _, e in ipairs(L.vig or {}) do e:SetAlpha(B.vignetteAlpha * inA, 0) end
    end
    return L
  end
  -- a particle's random size, speed, sway and alpha; first = spread over the screen, else start below it
  function BGX.spawn(p, first)
    p.x = (rnd() * 2 - 1) * 900
    p.y = first and (rnd() * 2 - 1) * 560 or (600 + rnd() * 80)
    p.sway, p.swayF, p.phase = 6 + rnd() * 16, 0.15 + rnd() * 0.35, rnd() * 6.2832
    if p.wisp then
      p.w = 50 + rnd() * 50; p.h = p.w * 2.6; p.speed = 15 + rnd() * 20; p.a = 0.25 + rnd() * 0.3
    else
      p.w = 60 + rnd() * 70; p.h = p.w; p.speed = 25 + rnd() * 45; p.a = 0.45 + rnd() * 0.5
    end
  end

  BV.revealQueue = BV.revealQueue or {}
  local playNext
  local function buildReveal(r)
    local LUI = g("LUI")
    local P = REVEAL
    local S = P.plate / 1024
    local function plateXY(px, py) return (px - 512) * S, (py - 512) * S + P.plateY end
    local SEASON = C3(SEASON_RGB[r.season] or { 1, 1, 1 })
    local BOXC, WHITE = C3(P.boxColor), 16777215

    local ov = LUI.UIElement.new()
    ov:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)
    pcall(function() ov:SetHandleMouse(false) end)
    pcall(function() ov:setFocusable(false) end)
    LUI.GetRoot():addElement(ov)

    -- the layered backdrop (base colour or map, smoke, rays, floor, embers, vignette), all under the box
    local BG = BGX.build(ov, r, P, plateXY)

    -- which box: r.box picks one of REVEAL.boxes; without its art the standard box is used
    local BX = P.boxes and P.boxes[r.box or "mbox"] or nil
    -- v1.43: a box drawn from full-box frames is checked by its first frame (its _body / _lid images are never shown)
    if not BX or not mat(BX.prefix .. (BX.fullFrames and "_lid_00" or "_body")) then
      BX = (P.boxes and P.boxes.mbox) or { prefix = "mbox", qfaces = true, top = 470 }
    end
    local PFX, lidMode = BX.prefix, BX.lidMode or P.lidMode
    local TINT = C3(BX.tint or P.bodyTint)
    -- the box, shaken as one
    local stack = group(ov)
    local function plate(name, o)
      local e = image(stack, name, o)
      place(e, 0, P.plateY, P.plate, P.plate)
      return e
    end
    local shadow = plate(PFX .. "_shadow", { a = 0 })
    local glow = plate(PFX .. "_glow", { add = true, a = 0 })
    local body = plate(PFX .. "_body", { rgb = TINT, a = 0 })
    local qBloom = BX.qfaces and plate("mbox_qbloom", { add = true, rgb = BOXC, a = 0 }) or nil
    local qFace = BX.qfaces and plate("mbox_qface", { add = true, rgb = C3(P.qFace), a = 0 }) or nil
    local lid = plate(lidMode == "frames" and (PFX .. "_lid_00") or (PFX .. "_lid"), { rgb = TINT, a = 0 })
    pivotCentre(lid)
    local beam = plate(PFX .. "_beam", { add = true, a = 0 })

    -- weapon icon rising out of the box
    local iconGlow = image(ov, "mbox_dot", { add = true, rgb = BOXC, a = 0 })
    local icon = image(ov, "soe_white", { a = 0 })
    local hasIcon = setIcon(icon, r.id, r.image)
    pivotCentre(icon)

    -- text
    local nameStr = string.upper(tostring(r.name or "?"))
    local label = textLine(ov, r.label or "SEASONAL CRATE  -  UNLOCKED", 0, P.labelY, 24, { rgb = BOXC, a = 0, track = 0.12 })
    local nameShadow = textLine(ov, nameStr, 4, P.nameY + 4, P.nameH, { rgb = 0, a = 0, maxW = P.textMaxW, track = 0.06 })
    local name = textLine(ov, nameStr, 0, P.nameY, P.nameH, { rgb = WHITE, a = 0, maxW = P.textMaxW, track = 0.06 })
    local nameTint = textLine(ov, nameStr, 0, P.nameY, P.nameH, { rgb = SEASON, add = true, a = 0, maxW = P.textMaxW, track = 0.06 })
    local sub = textLine(ov, (r.sub and (string.upper(r.sub) .. "  -  ") or r.season and ("SEASON " .. r.season .. "  -  ") or "") ..
      (r.apothicon and (tostring(r.apothicon) .. " APOTHICON VIALS LEFT") or (tostring(r.vials) .. " BLOOD VIALS LEFT")),
      0, P.subY, 26, { rgb = 13158600, a = 0, track = 0.1 })

    -- full-screen season flash on top of everything
    local flash = image(ov, "soe_white", { rgb = SEASON, a = 0 })
    flash:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)

    local boxTopX, boxTopY = plateXY(512, BX.top or 470)
    local now, done, lastFrame = 0, false, -1
    -- sounds: every loop and box sound this reveal starts is stopped when it ends. A normal end lets the "close"
    -- one-shot ring out over the fade; a skip or an error stops that too.
    local snd = { cue = 1, loop = 0 }
    local function finish(why)
      if done then return end
      done = true
      SFX.stopAll()
      if why ~= "end" and snd.closeId then SFX.stop(snd.closeId) end   -- skip / error / watchdog
      pcall(function() ov:closeTree() end)
      BV.revealActive = nil
      pcall(playNext)
    end
    BV.revealActive = { finish = finish }
    local cue = 1
    local SD = P.sounds
    -- this reveal's menu sounds: REVEAL.sfx plus its crate's extras (REVEAL.sfxCrate[r.crate]), in time order
    local SFXL = {}
    for _, c in ipairs(P.sfx or {}) do SFXL[#SFXL + 1] = c end
    for _, c in ipairs((P.sfxCrate and r.crate and P.sfxCrate[r.crate]) or {}) do SFXL[#SFXL + 1] = c end
    for i, c in ipairs(SFXL) do c.order = i end
    table.sort(SFXL, function(a, b) if a[1] ~= b[1] then return a[1] < b[1] end return a.order < b.order end)
    local function sounds()
      if not SD or SD.mode ~= "box" then
        -- menu sounds only (in time order)
        while SFXL[cue] and now >= SFXL[cue][1] do
          local c = SFXL[cue]
          SFX.play(c[2], r.kind == "blueprint" and c.blueprint or c[3])
          cue = cue + 1
        end
        return
      end
      if now < P.hold then
        while SD.loops and SD.loops[snd.loop + 1] and now >= SD.loops[snd.loop + 1][1] do
          snd.loop = snd.loop + 1
          SFX.stop(snd.loopId)            -- each loop replaces the one before it
          local l = SD.loops[snd.loop]
          snd.loopId = SFX.playAlias(l[3], l[2])
        end
      end
      while SD.cues and SD.cues[snd.cue] and now >= SD.cues[snd.cue][1] do
        local c = SD.cues[snd.cue]
        if not SFX.playAlias(c[3], c[2]) and c.ui then
          SFX.play(c.ui[1], r.kind == "blueprint" and c.ui.blueprint or c.ui[2])   -- box sound not available
        end
        snd.cue = snd.cue + 1
      end
      if now >= P.hold and not snd.closed then
        snd.closed = true
        SFX.stop(snd.loopId); snd.loopId = nil
        if SD.close then
          snd.closeId = SFX.playAlias(SD.close[2], SD.close[1])
          -- keep it out of the stop-all list so a normal end doesn't cut it (skip/error stop it by id)
          for i = #SFX.live, 1, -1 do if SFX.live[i] == snd.closeId then table.remove(SFX.live, i) end end
        end
      end
    end

    local function frame()
      local fadeOut = now > P.hold and (1 - span(now, P.hold, P.fadeMs)) or 1
      if fadeOut <= 0 then finish("end"); return end
      sounds()
      local inA = ease(now / 250) * fadeOut
      BG.update(now, inA)
      shadow:SetAlpha(inA, 0)
      body:SetAlpha(BX.fullFrames and 0 or inA, 0)   -- full-box frames already contain the body

      -- shake while the box charges
      local charge = ease(span(now, P.shakeStart, P.shakeEnd - P.shakeStart))
      local dx, dy = 0, 0
      if now >= P.shakeStart and now < P.shakeEnd then
        local amp = P.shakePx * charge ^ 1.5
        dx = (rnd() * 2 - 1) * amp
        dy = (rnd() * 2 - 1) * amp * 0.6
      end
      stack:SetAnchorsAndPosition(0, 0, 0, 0, dx, dx, dy, dy)
      local pulse = 0.5 + 0.5 * math.sin(now / 90)
      local open = BX.lidMs and span(now, P.lidAt, BX.lidMs) or ease(span(now, P.lidAt, P.lidMs))
      if BX.lidMs then open = open < 0 and 0 or open > 1 and 1 or open end   -- real animation frames: linear
      glow:SetAlpha(math.min(1, 0.25 + 0.45 * charge + 0.12 * pulse * charge + 0.25 * open) * fadeOut, 0)
      -- "?" faces: dim at rest, flicker up while charging, blaze when the lid comes off
      local flick = 1
      if charge > 0 and open < 1 then flick = 1 - P.qFlicker * charge * rnd() end
      local q = (P.qIdle + (1 - P.qIdle) * charge) * flick
      if qFace then
        qFace:SetAlpha(math.min(1, q + 0.15 * open) * inA, 0)
        qBloom:SetAlpha(math.min(1, 0.25 * q + 0.55 * charge * (0.8 + 0.2 * pulse) + 0.3 * open) * inA, 0)
      end

      -- lid
      if lidMode == "frames" then
        local f = math.floor(open * ((BX.lidFrames or P.lidFrames) - 1) + 0.5)
        if f ~= lastFrame then
          lastFrame = f
          local m = mat(string.format(PFX .. "_lid_%02d", f))
          if m then lid:setImage(m, 0) end
        end
        lid:SetAlpha(inA, 0)
      else
        local lift = easeOut(span(now, P.lidAt, P.lidMs))
        place(lid, 0, P.plateY - 120 * lift, P.plate, P.plate)
        pcall(function() lid:SetZRotation(-4 * lift, 0) end)
        lid:SetAlpha(inA * (1 - ease(span(now, P.lidAt + 120, P.lidMs))), 0)
      end
      beam:SetAlpha(ease(span(now, P.beamAt, P.beamMs)) * (0.85 + 0.15 * pulse) * fadeOut, 0)

      -- season flash
      local fl = span(now, P.flashAt, P.flashMs)
      local fa = 0
      if fl >= 0 and fl <= 1 then fa = P.flashPeak * (fl < 0.15 and fl / 0.15 or (1 - (fl - 0.15) / 0.85)) end
      flash:SetAlpha(fa, 0)

      -- weapon icon
      local it = span(now, P.iconAt, P.iconMs)
      if it >= 0 then
        local rise = easeOut(it)
        local bob = now > P.iconAt + P.iconMs and math.sin((now - P.iconAt - P.iconMs) / 420) * 7 or 0
        local y = boxTopY + (P.iconY - boxTopY) * rise + bob
        local s = 0.6 + 0.4 * easeBack(it)
        -- r.iconW / r.iconH: a reveal's own picture size (relic icons are square; guns are 2:1)
        local iw, ih = r.iconW or P.iconW, r.iconH or P.iconH
        place(icon, boxTopX, y, iw * s, ih * s)
        place(iconGlow, boxTopX, y, iw * 1.5, ih * 1.8)
        icon:SetAlpha((hasIcon and 1 or 0) * ease(it / 0.3) * fadeOut, 0)
        iconGlow:SetAlpha(0.35 * ease(it / 0.3) * fadeOut, 0)
      end

      -- weapon name snaps in, tinted the season colour, then settles to white
      local nt = span(now, P.nameAt, 180)
      if nt >= 0 then
        local s = 1.25 - 0.25 * ease(nt)
        for _, e in ipairs({ name, nameShadow, nameTint }) do pcall(function() e:SetScale(s - 1, 0) end) end
        name:SetAlpha(ease(nt * 2) * fadeOut, 0)
        nameShadow:SetAlpha(0.6 * ease(nt * 2) * fadeOut, 0)
        nameTint:SetAlpha((1 - ease(span(now, P.nameAt + 150, 700))) * fadeOut, 0)
        label:SetAlpha(ease(span(now, P.nameAt - 150, 250)) * fadeOut, 0)
        sub:SetAlpha(ease(span(now, P.nameAt + 250, 300)) * fadeOut, 0)
      end
    end

    local STEP = 16
    local function tick()
      if done then return end
      local ok, e = pcall(frame)
      if not ok then note("reveal error: " .. tostring(e)); finish(); return end
      if done then return end
      if BV.revealActive then BV.revealActive.frames = (BV.revealActive.frames or 0) + 1 end
      now = now + STEP
      local okW, anim = pcall(function() return ov:Wait(STEP) end)
      if not okW or not anim then finish(); return end
      anim.onComplete = tick
    end
    tick()
  end
  playNext = function()
    if BV.revealActive then return end
    local r = table.remove(BV.revealQueue, 1)
    if not r then return end
    local ok, e = pcall(buildReveal, r)
    if not ok then
      SFX.stopAll()
      BV.revealActive = nil
      note("reveal failed: " .. tostring(e))
      toast("SEASONAL CRATE", r.name)
      pcall(playNext)
    end
  end
  local function reveal(r)
    BV.revealQueue[#BV.revealQueue + 1] = r
    playNext()
  end
  BV.reveal = reveal
  -- plays the screen with a sample result, without spending anything
  BV.preview = function()
    local id = 116617
    reveal({ id = id, name = itemName(id), season = SEASON_OF[id], vials = 2 })
  end
  -- skip the reveal that is playing (e.g. bind from the console: lua BloodVials.skip())
  BV.skip = function() if BV.revealActive then BV.revealActive.finish() end end

  local function openCrate()
    if not inFrontend() then BV.msg = "Open crates from the menus, not during a match."; return end
    local st = readState()
    if not st then BV.msg = "Can't read the save dvar (kronos_bo6_var)."; return end
    if st.vials < CRATE_COST then BV.msg = "Not enough Blood Vials: " .. st.vials .. " of " .. CRATE_COST .. "."; return end
    local left = {}
    for id in pairs(POOL) do if not st.earned[id] then left[#left + 1] = id end end
    if #left == 0 then BV.msg = "Collection complete: every seasonal weapon is unlocked."; return end
    table.sort(left)
    -- the game's Lua isn't seeded per session: mix the save revision and a fresh table address into the roll
    local addr = tonumber((tostring({}):match("(%x+)$")) or "0", 16) or 0
    BV.roll = ((BV.roll or 0) * 1103515245 + addr + st.rev * 7919 + 12345) % 2147483648
    local pick = left[(BV.roll % #left) + 1]
    local new = { rev = st.rev + 1, vials = st.vials - CRATE_COST, progress = st.progress, earned = {} }
    for id in pairs(st.earned) do new.earned[id] = true end
    new.earned[pick] = true
    new.bp = st.bp
    if not writeState(new) then BV.msg = "Couldn't write the save dvar; nothing was spent."; note("write failed"); return end
    local name = itemName(pick)
    BV.last = name
    BV.msg = "Unlocked: " .. name .. "  (" .. new.vials .. " vials left)"
    note("crate " .. pick .. " " .. tostring(name) .. " rev " .. new.rev)
    -- the save is already written; the reveal is only the show, and falls back to the toast if it fails
    local ok, e = pcall(reveal, { id = pick, name = name, season = SEASON_OF[pick], vials = new.vials, crate = "seasonal" })
    if not ok then note("reveal failed: " .. tostring(e)); toast("SEASONAL CRATE", name) end
  end

  -- Blueprint crate: BP.cost vials for a random blueprint you don't own, of a gun you can already use
  -- (base guns, or seasonal weapons you've unlocked). No duplicates.
  function BP.open()
    if not inFrontend() then BV.msg = "Open crates from the menus, not during a match."; return end
    if not BP.data() then BV.msg = "Blueprint list not loaded (lua\\blood_vials_data_post.lua)."; return end
    local st = readState()
    if not st then BV.msg = "Can't read the save dvar (kronos_bo6_var)."; return end
    if st.vials < BP.cost then BV.msg = "Not enough Blood Vials: " .. st.vials .. " of " .. BP.cost .. "."; return end
    local left, gated = {}, 0
    for i, b in ipairs(BP.list) do
      if not st.bp[i] then
        if POOL[b[2]] and not st.earned[b[2]] then gated = gated + 1 else left[#left + 1] = i end
      end
    end
    if #left == 0 then
      BV.msg = gated > 0 and ("Every blueprint of your guns is unlocked. " .. gated .. " more belong to seasonal weapons you haven't unlocked yet.")
        or "Collection complete: every blueprint is unlocked."
      return
    end
    local addr = tonumber((tostring({}):match("(%x+)$")) or "0", 16) or 0
    BV.roll = ((BV.roll or 0) * 1103515245 + addr + st.rev * 7919 + 12345) % 2147483648
    local pick = left[(BV.roll % #left) + 1]
    local b = BP.list[pick]
    local new = { rev = st.rev + 1, vials = st.vials - BP.cost, progress = st.progress, earned = st.earned, bp = {} }
    for i in pairs(st.bp) do new.bp[i] = true end
    new.bp[pick] = true
    if not writeState(new) then BV.msg = "Couldn't write the save dvar; nothing was spent."; note("write failed"); return end
    local variant = b[4]:gsub("_", " "):gsub("^%l", string.upper)
    local name = itemName(b[1], b[3], variant)
    local gun = itemName(b[2])
    if name == gun then name = variant end   -- the lookup gave the base gun's name, not the blueprint's
    BV.last = name
    BV.msg = "Unlocked: " .. gun .. " - " .. name .. "  (" .. new.vials .. " vials left)"
    note("blueprint crate " .. b[1] .. " " .. tostring(name) .. " rev " .. new.rev)
    local ok, e = pcall(reveal, { id = b[1], name = name, image = b[5], vials = new.vials,
      label = "BLUEPRINT CRATE  -  UNLOCKED", sub = gun .. " blueprint", kind = "blueprint", crate = "blueprint" })
    if not ok then note("reveal failed: " .. tostring(e)); toast("BLUEPRINT CRATE", name) end
  end
  BV.openBlueprintCrate = BP.open

  -- Perk / Ammo Mod / Field Upgrade Crate (v1.9): PK.cost[kind] vials for the next step (two augments, in the
  -- natural order) of a random perk (ammo mod, field upgrade) that still has locked augments. No duplicates.
  function PK.open(kind)
    local L = PK.label[kind] or kind
    if not inFrontend() then BV.msg = "Open crates from the menus, not during a match."; return end
    if not PK.data() then BV.msg = "Augment list not loaded (lua\\blood_vials_data_post.lua)."; return end
    local st = readState()
    if not st then BV.msg = "Can't read the save dvar (kronos_bo6_var)."; return end
    local cost = PK.cost[kind] or 10
    if st.vials < cost then BV.msg = "Not enough Blood Vials: " .. st.vials .. " of " .. cost .. "."; return end
    local left = {}
    for i, p in ipairs(PK.list) do if (p[4] or "perk") == kind and PK.nextStep(st, i) then left[#left + 1] = i end end
    if #left == 0 then BV.msg = "Collection complete: every " .. L:lower() .. " augment is unlocked."; return end
    local addr = tonumber((tostring({}):match("(%x+)$")) or "0", 16) or 0
    BV.roll = ((BV.roll or 0) * 1103515245 + addr + st.rev * 7919 + 12345) % 2147483648
    local i = left[(BV.roll % #left) + 1]
    local p = PK.list[i]
    local s, step = PK.nextStep(st, i)
    local new = { rev = st.rev + 1, vials = st.vials - cost, progress = st.progress, earned = st.earned, ag = {} }
    for k in pairs(st.ag) do new.ag[k] = true end
    local got = {}
    for _, id in ipairs(step) do
      if not PK.owned(st, id) and PK.bit[id] then new.ag[PK.bit[id]] = true; got[#got + 1] = PK.augName(id) end
    end
    if not writeState(new) then BV.msg = "Couldn't write the save dvar; nothing was spent."; note("write failed"); return end
    local names = table.concat(got, " + ")
    BV.msg = "Unlocked: " .. p[2] .. " - " .. names .. "  (" .. new.vials .. " vials left)"
    note(kind .. " crate " .. p[1] .. " step " .. s .. " rev " .. new.rev)
    -- the perk / ammo mod / field upgrade's own icon (v1.35; p.icon from tools\make_blueprints.py), square like a relic's
    local ok, e = pcall(reveal, { id = 0, name = p[2], vials = new.vials, label = string.upper(L) .. " CRATE  -  UNLOCKED",
      sub = names, kind = "blueprint", image = (p.icon ~= "" and p.icon) or nil,
      iconW = REVEAL.relicIcon, iconH = REVEAL.relicIcon, crate = "augment" })
    if not ok then note("reveal failed: " .. tostring(e)); toast(string.upper(L) .. " CRATE", p[2] .. ": " .. names) end
  end

  -- Apothicon Crate (v1.9): one Apothicon Blood Vial for a random wonder weapon skin you don't own. No duplicates.
  function WW.open()
    if not inFrontend() then BV.msg = "Open crates from the menus, not during a match."; return end
    if not WW.data() then BV.msg = "Skin list not loaded (lua\\blood_vials_data_post.lua)."; return end
    local st = readState()
    if not st then BV.msg = "Can't read the save dvar (kronos_bo6_var)."; return end
    if st.ap < WW.cost then
      BV.msg = "No Apothicon Blood Vial. Complete a map's main quest to earn one."; return
    end
    local left = {}
    for i in ipairs(WW.list) do if not st.ww[i] then left[#left + 1] = i end end
    -- v1.27: Peeks' Mayhem is an Apothicon-tier prize too (index 0 here)
    local mayhemLeft = RL.data() and not st.rl[1]
    if mayhemLeft then left[#left + 1] = 0 end
    if #left == 0 then BV.msg = "Collection complete: every wonder weapon skin and Peeks' Mayhem are unlocked."; return end
    local addr = tonumber((tostring({}):match("(%x+)$")) or "0", 16) or 0
    BV.roll = ((BV.roll or 0) * 1103515245 + addr + st.rev * 7919 + 12345) % 2147483648
    local i = left[(BV.roll % #left) + 1]
    if i == 0 then
      local new = { rev = st.rev + 1, vials = st.vials, progress = st.progress, earned = st.earned, rl = {},
        ap = st.ap - WW.cost, apRev = st.apRev, apSet = true }
      for k in pairs(st.rl) do new.rl[k] = true end
      new.rl[1] = true
      if not writeState(new) then BV.msg = "Couldn't write the save dvar; nothing was spent."; note("write failed"); return end
      BV.msg = "Unlocked: Peeks' Mayhem (Cursed Survival)  (" .. new.ap .. " Apothicon vials left)"
      note("apothicon crate: peeks mayhem rev " .. new.rev)
      local ok, e = pcall(reveal, { id = 0, name = "Peeks' Mayhem", vials = new.vials, kind = "blueprint",
        label = "APOTHICON CRATE  -  UNLOCKED", sub = "Cursed Survival mode", apothicon = new.ap, box = "abox",
        image = RL.icon(1), iconW = REVEAL.relicIcon, iconH = REVEAL.relicIcon, crate = "apothicon" })
      if not ok then note("reveal failed: " .. tostring(e)); toast("APOTHICON CRATE", "Peeks' Mayhem") end
      return
    end
    local w = WW.list[i]
    local new = { rev = st.rev + 1, vials = st.vials, progress = st.progress, earned = st.earned, ww = {},
      ap = st.ap - WW.cost, apRev = st.apRev, apSet = true }
    for k in pairs(st.ww) do new.ww[k] = true end
    new.ww[i] = true
    if not writeState(new) then BV.msg = "Couldn't write the save dvar; nothing was spent."; note("write failed"); return end
    local variant = w[3]:gsub("_", " "):gsub("^%l", string.upper)
    local name = itemName(w.id, w[2], variant)
    local gun = itemName(w[1], w[2]:sub(1, #w[2] - #w[3] - 1))   -- the wonder weapon itself, e.g. sat_ww_mantis
    if name == gun then name = variant end
    BV.msg = "Unlocked: " .. gun .. " - " .. name .. "  (" .. new.ap .. " Apothicon vials left)"
    note("apothicon crate " .. w.id .. " rev " .. new.rev)
    local ok, e = pcall(reveal, { id = w.id, name = name, image = w[4], vials = new.vials, kind = "blueprint",
      label = "APOTHICON CRATE  -  UNLOCKED", sub = gun .. " skin", apothicon = new.ap, box = "abox", crate = "apothicon" })
    if not ok then note("reveal failed: " .. tostring(e)); toast("APOTHICON CRATE", name) end
  end
  BV.openApothiconCrate = WW.open

  -- Relic Crate (v1.27): RL.cost Blood Vials for a random cursed relic you don't own. No duplicates.
  function RL.open()
    if not inFrontend() then BV.msg = "Open crates from the menus, not during a match."; return end
    if not RL.data() then BV.msg = "Relic list not loaded (lua\\blood_vials_chal_post.lua)."; return end
    local st = readState()
    if not st then BV.msg = "Can't read the save dvar (kronos_bo6_var)."; return end
    if st.vials < RL.cost then BV.msg = "Not enough Blood Vials: " .. st.vials .. " of " .. RL.cost .. "."; return end
    local left = {}
    for i = 2, #RL.list do if not st.rl[i] then left[#left + 1] = i end end
    if #left == 0 then BV.msg = "Collection complete: every cursed relic is unlocked."; return end
    local addr = tonumber((tostring({}):match("(%x+)$")) or "0", 16) or 0
    BV.roll = ((BV.roll or 0) * 1103515245 + addr + st.rev * 7919 + 12345) % 2147483648
    local i = left[(BV.roll % #left) + 1]
    local new = { rev = st.rev + 1, vials = st.vials - RL.cost, progress = st.progress, earned = st.earned, rl = {} }
    for k in pairs(st.rl) do new.rl[k] = true end
    new.rl[i] = true
    if not writeState(new) then BV.msg = "Couldn't write the save dvar; nothing was spent."; note("write failed"); return end
    local name, map = RL.name(i)
    BV.msg = "Unlocked: " .. name .. " (" .. map .. ")  (" .. new.vials .. " vials left)"
    note("relic crate " .. RL.list[i][1] .. " " .. name .. " rev " .. new.rev)
    local ok, e = pcall(reveal, { id = 0, name = name, vials = new.vials, kind = "blueprint",
      label = "RELIC CRATE  -  UNLOCKED", sub = map, box = "rbox", image = RL.icon(i),
      iconW = REVEAL.relicIcon, iconH = REVEAL.relicIcon, crate = "relic" })
    if not ok then note("reveal failed: " .. tostring(e)); toast("RELIC CRATE", name) end
  end
  BV.openRelicCrate = RL.open

  -- Peeks' Mayhem hidden while locked: the game asks ZMRELIC 60e2e1c5dc3d4efa(category ref) whether a relic
  -- category is available, and csm_mayhem_relic wraps that slot to say yes for Cursed Survival. That mod re-wraps
  -- whenever the slot holds something else, and checks it with rawget. So the raw slot is emptied and our function
  -- is served through the table's own (copied) metatable: the mod sees an empty slot and stops wrapping, the game
  -- still finds our function, which says no for Cursed Survival while it's locked and passes everything else to the
  -- function that was there (the mod's wrapper or the game's). Fallback when the metatable can't be set: a plain wrap.
  function RL.isSurvival(ref)
    if ref == RL.SURVIVAL then return true end
    if RL.survivalRef == nil then
      local C = g("CLUA")
      local f = type(C) == "table" and C.PushXHashAsset
      local ok, v = pcall(function() return f(RL.SURVIVAL_HEX) end)
      RL.survivalRef = ok and v or false
    end
    return RL.survivalRef ~= false and ref == RL.survivalRef
  end
  function RL.mayhemLocked()
    if not BV.enabled or not RL.data() then return false end
    local st = readState()
    return st ~= nil and not st.rl[1]
  end
  -- v1.28: the ZMRELIC slots taken over, by hex. In game the Mayhem super relic still showed after the category slot
  -- alone: Mister Peeks Mayhem is the Cursed modes' super relic ("Mister Peeks Mayhem Available", "Collect the
  -- Bears"), and its availability is ZMRELIC 2f122afcc2782c19(controller) (the Mayhem mod wraps that one too, with
  -- the same re-wrap habit). Calls and last answers per slot go to the log (RL.stats).
  RL.SLOT_HEX = { "60e2e1c5dc3d4efa", "2f122afcc2782c19" }
  RL.inners, RL.stats, RL.fns = RL.inners or {}, RL.stats or {}, RL.fns or {}
  local function slotStat(hex, res)
    local s = RL.stats[hex] or { n = 0, last = "-" }
    s.n, s.last = s.n + 1, tostring(res)
    RL.stats[hex] = s
  end
  local function callInner(hex, ...)
    local f = RL.inners[hex]
    if type(f) ~= "function" then return nil end
    return f(...)
  end
  -- is this relic category available as a relic category: no for Cursed Survival while Mayhem is locked
  RL.fns["60e2e1c5dc3d4efa"] = RL.fns["60e2e1c5dc3d4efa"] or function(ref, ...)
    if RL.isSurvival(ref) then
      if RL.mayhemLocked() then slotStat("60e2e1c5dc3d4efa", false); return false end
      -- unlocked: with the Mayhem mod installed, give its own answer (it may never have wrapped this slot if it
      -- loaded after us and found it empty)
      if rawget(_G, "CSM_MAYHEM_P1") ~= nil then slotStat("60e2e1c5dc3d4efa", true); return true end
    end
    return callInner("60e2e1c5dc3d4efa", ref, ...)
  end
  -- the Mister Peeks Mayhem super relic available (controller): no while it's locked
  RL.fns["2f122afcc2782c19"] = RL.fns["2f122afcc2782c19"] or function(...)
    if RL.mayhemLocked() then slotStat("2f122afcc2782c19", false); return false end
    local r = { n = 0 }
    local function keep(...) r.n = select("#", ...); for i = 1, r.n do r[i] = select(i, ...) end end
    keep(callInner("2f122afcc2782c19", ...))
    slotStat("2f122afcc2782c19", r[1])
    return unpack(r, 1, r.n)
  end
  RL.slotFn = RL.fns["60e2e1c5dc3d4efa"]
  function RL.hookSlot()
    local Z = g("ZMRELIC")
    if type(Z) ~= "table" then RL.slotHow = "no ZMRELIC"; return end
    local keys, todo = {}, {}
    for _, hx in ipairs(RL.SLOT_HEX) do
      local k = H(hx)
      keys[#keys + 1] = { k, hx }
      local raw = rawget(Z, k)
      if type(raw) == "function" and raw ~= RL.fns[hx] then
        RL.inners[hx] = raw                                  -- the game's function or the mod's wrapper
        todo[#todo + 1] = { k, hx }
      end
    end
    if #todo == 0 then return end                            -- all served through the metatable already (or absent)
    local ok = pcall(function()
      local mt = getmetatable(Z)
      if mt ~= nil and type(mt) ~= "table" then error("protected metatable") end
      if not (mt and mt.__bvRelic) then
        local copy = {}
        if mt then for kk, vv in pairs(mt) do copy[kk] = vv end end
        local old = copy.__index
        copy.__bvRelic = true
        copy.__index = function(t, key)
          for _, e in ipairs(keys) do if key == e[1] then return RL.fns[e[2]] end end
          if type(old) == "function" then return old(t, key) end
          if type(old) == "table" then return old[key] end
          return nil
        end
        setmetatable(Z, copy)
      end
      for _, e in ipairs(todo) do rawset(Z, e[1], nil) end
      for _, e in ipairs(todo) do if Z[e[1]] ~= RL.fns[e[2]] then error("lookup didn't reach ours") end end
    end)
    if ok then
      RL.slotHow = "metatable"
    else
      for _, e in ipairs(todo) do rawset(Z, e[1], RL.fns[e[2]]) end
      RL.slotHow = "wrap"
    end
    note("peeks mayhem slots: " .. RL.slotHow .. " (" .. #todo .. ")")
  end
  function RL.statText()
    local out = {}
    for _, hx in ipairs(RL.SLOT_HEX) do
      local s = RL.stats[hx]
      out[#out + 1] = hx:sub(1, 4) .. " " .. (s and (s.n .. "x last " .. s.last) or "0x")
    end
    return table.concat(out, ", ")
  end

  -- ---------------------------------------------------------------------------------------------------
  -- the earning settings: kills per vial (1..25, default 25) and chance mode (default off)
  function BV.CFG.read()
    local cur = bo6Get()
    local k, c = (cur and entryOf(cur, BV.CFG.entry) or ""):match("^(%d+)%.([01])$")
    k = tonumber(k) or 25
    return math.max(1, math.min(25, k)), c == "1"
  end
  function BV.CFG.write(kills, chance)
    local cur = bo6Get()
    if cur == nil then BV.msg = "Can't save the setting (no dvar access)"; return end
    kills = math.max(1, math.min(25, math.floor(tonumber(kills) or 25)))
    bo6Set(withEntry(cur, kills .. "." .. (chance and "1" or "0"), BV.CFG.entry))
  end
  -- the earning rules in words, for the descriptions
  function BV.CFG.rules()
    local k, c = BV.CFG.read()
    return (c and ("Every zombie you kill has a " .. BV.CFG.pct .. "% chance to drop a Blood Vial (a special zombie gets 10 tries)")
      or ("1 Blood Vial per " .. k .. " zombie kill" .. (k == 1 and "" or "s") .. " (a special zombie counts as 10)")) ..
      ", 1 per elite kill, 3 for a successful exfil and 3 for every 5 rounds survived (host only)."
  end

  -- Rows at the top of Options -> Debug Options
  local function rowData(rowHex)
    local st = readState()
    local t = {}
    local id = H(rowHex, 3)
    t[H(OK.id)] = id; t[H(OK.sb)] = id; t[H(OK.def)] = 1; t[H(OK.type)] = "Dropdown"
    local CFG = BV.CFG
    if rowHex == CFG.rowKills then
      -- the game's slider row, set up the way Kronos sets up its level slider (min, max, step fields)
      local k, c = CFG.read()
      t[H(OK.name)] = "Blood Vial Kills"
      t[H(OK.type)] = "SliderBarWithEditBox"
      t[H("ea4f419cc129e9e6")] = 1; t[H("914593b1fcd3cc98")] = 25
      t[H("088a01d1c318c8ac")] = 1; t[H("a4b76d37c317bf49")] = 1; t[H("92bde76887ce454b")] = 0
      t[H(OK.def)] = 25
      t[H(OK.desc)] = "Zombie kills needed for one Blood Vial (1 to 25). A special zombie counts as 10 kills." ..
        (c and " Not used while Blood Vial Drop Chance is on." or "")
      t[H(OK.value)] = function() local kk = CFG.read(); return kk end
      t[H(OK.action)] = function(cc, v)
        local _, ch = CFG.read()
        CFG.write(v, ch)
      end
      return autoXHash(t)
    elseif rowHex == CFG.rowSound then
      -- audition the menu sounds the crate reveals can use (REVEAL.sfxTest); picking one plays it
      local list = REVEAL.sfxTest or {}
      local labels = { "Pick a sound to play" }
      for i, s in ipairs(list) do labels[#labels + 1] = i .. ". " .. s[1] .. " / " .. s[2] end
      t[H(OK.name)] = "Crate Sound Test"
      t[H(OK.labels)] = labels
      t[H(OK.desc)] = "Plays one of the game's menu sounds the crate openings can use, so you can hear it. " ..
        (CFG.soundMsg or "Pick one; pick it again to replay.")
      t[H(OK.value)] = function() return CFG.soundPick or 1 end
      t[H(OK.action)] = function(cc, v)
        v = tonumber(v) or 1
        CFG.soundPick = v
        local s = list[v - 1]
        if s then
          local ok = SFX.play(s[1], s[2])
          CFG.soundMsg = (ok and "Played " or "Not available here: ") .. s[1] .. " / " .. s[2] .. "."
          BV.klog("sound test: " .. s[1] .. "." .. s[2] .. (ok and " played" or " missing"))
        end
      end
      return autoXHash(t)
    elseif rowHex == CFG.rowChance then
      t[H(OK.name)] = "Blood Vial Drop Chance"
      t[H(OK.type)] = "ToggleButton"
      t[H(OK.labels)] = { "Off", "On" }
      t[H(OK.desc)] = "On: every zombie you kill has a " .. CFG.pct .. "% chance to drop a Blood Vial, instead of counting kills " ..
        "(a special zombie gets 10 tries). Elite kills, exfils and rounds still give their vials."
      t[H(OK.value)] = function() local _, ch = CFG.read(); return ch and 2 or 1 end
      t[H(OK.action)] = function(cc, v)
        local kk = CFG.read()
        CFG.write(kk, v == 2)
      end
      return autoXHash(t)
    end
    if rowHex == ROW_BALANCE then
      t[H(OK.name)] = "Blood Vials"
      BV.diagN = (BV.diagN or 0) + 1
      if BV.DEBUG and BV.diagN % 40 == 1 then pcall(BV.lockDiag) end
      if st then
        t[H(OK.labels)] = { st.vials .. " vials  |  " .. st.count .. " / " .. POOL_SIZE .. " weapons  |  " ..
          st.bpCount .. " / " .. (BP.data() and BP.size or "?") .. " blueprints  |  augments: " ..
          PK.count(st, "perk") .. "/" .. (PK.data() and PK.augTotal.perk or "?") .. " perk, " ..
          PK.count(st, "ammo") .. "/" .. (PK.data() and PK.augTotal.ammo or "?") .. " ammo mod, " ..
          PK.count(st, "fu") .. "/" .. (PK.data() and PK.augTotal.fu or "?") .. " field upgrade  |  " ..
          st.ap .. " Apothicon vials, " .. st.wwCount .. "/" .. (WW.data() and WW.size or "?") .. " wonder weapon skins" }
      else
        t[H(OK.labels)] = { "can't read the save dvar" }
      end
      local cfgK, cfgC = BV.CFG.read()
      t[H(OK.desc)] = "Earn " .. BV.CFG.rules() .. " " ..
        "Finishing a main easter egg gives an Apothicon Blood Vial. Spend them in the CRATES tab of the Zombies lobby " ..
        "on seasonal weapons, blueprints, augments, relics and wonder weapon skins." ..
        ((st and not cfgC) and (" Next vial: " .. math.min(st.progress, cfgK) .. " / " .. cfgK .. " kills.") or "") ..
        (BV.DEBUG and (" [save: " .. tostring(BV.source) .. ", zm: " .. tostring(dvarGet(STATUS_DVAR)) .. "] [" ..
          (BV.TAB and BV.TAB.status() or "tab: -") .. "] [sounds played " .. (SFX.played or 0) ..
          (SFX.miss and (", missing " .. SFX.miss) or "") .. "] [" .. BV.attStatus() .. "] [" .. BPB.status() ..
          "] [box sounds played " .. (SFX.boxPlayed or 0) .. (SFX.boxNoId and (", no id: " .. SFX.boxNoId) or "") ..
          (SFX.boxErr and (", error " .. SFX.boxErr) or "") .. "] [" .. (BV.SPL and BV.SPL.status() or "splash: -") .. "]") or "")
      t[H(OK.value)] = function() return 1 end
      t[H(OK.action)] = function() end
    elseif rowHex == ROW_BPCRATE then
      t[H(OK.name)] = "Blueprint Crate"
      t[H(OK.labels)] = { "Costs " .. BP.cost .. " vials", "Open blueprint crate" }
      t[H(OK.desc)] = BV.msg or ("Spend " .. BP.cost .. " Blood Vials for a random blueprint you don't own yet, for a gun " ..
        "you can already use. No duplicates.")
      t[H(OK.value)] = function() return 1 end
      t[H(OK.action)] = function(c, v)
        if v == 2 then local ok, e = pcall(BP.open); if not ok then BV.msg = "Crate error: " .. tostring(e); note(BV.msg) end end
      end
    else
      t[H(OK.name)] = "Seasonal Crate"
      -- "Preview reveal" only when REVEAL.preview is on (a debug option, off by default)
      t[H(OK.labels)] = REVEAL.preview and { "Costs " .. CRATE_COST .. " vials", "Open crate", "Preview reveal" }
        or { "Costs " .. CRATE_COST .. " vials", "Open crate" }
      t[H(OK.desc)] = BV.msg or ("Spend " .. CRATE_COST .. " Blood Vials for a random seasonal weapon you don't own yet. No duplicates." ..
        (REVEAL.preview and " \"Preview reveal\" plays the opening screen without spending anything." or ""))
      t[H(OK.value)] = function() return 1 end
      t[H(OK.action)] = function(c, v)
        if v == 2 then
          local ok, e = pcall(openCrate); if not ok then BV.msg = "Crate error: " .. tostring(e); note(BV.msg) end
        elseif v == 3 and REVEAL.preview then
          local ok, e = pcall(BV.preview); if not ok then BV.msg = "Preview error: " .. tostring(e); note(BV.msg) end
        end
      end
    end
    return autoXHash(t)
  end
  local ours = { [tostring(H(ROW_BALANCE, 3))] = ROW_BALANCE, [tostring(H(ROW_CRATE, 3))] = ROW_CRATE,
    [tostring(H(ROW_BPCRATE, 3))] = ROW_BPCRATE, [tostring(H(BV.CFG.rowKills, 3))] = BV.CFG.rowKills,
    [tostring(H(BV.CFG.rowChance, 3))] = BV.CFG.rowChance, [tostring(H(BV.CFG.rowSound, 3))] = BV.CFG.rowSound }
  local probeSb = H(ROW_PROBE, 3)
  local function dataWrap(orig, tag)
    return function(sb, ...)
      if BV.probing then if BV.probeTag == tag then BV.hit = true end; return nil end
      local row = sb ~= nil and ours[tostring(sb)]
      if row and BV.enabled then return rowData(row) end
      return orig(sb, ...)
    end
  end
  local function injectRows(items)
    if type(items) ~= "table" then return end
    for _, it in ipairs(items) do
      local ok, sb = pcall(function() return it[H(OK.sb)] end)
      if ok and sb ~= nil and ours[tostring(sb)] then return end
    end
    -- order: balance, kills slider, chance toggle, seasonal crate, blueprint crate (+ crate sound test with BV.DEBUG)
    if BV.DEBUG then table.insert(items, 1, autoXHash({ [H(OK.sb)] = H(BV.CFG.rowSound, 3) })) end
    table.insert(items, 1, autoXHash({ [H(OK.sb)] = H(ROW_BPCRATE, 3) }))
    table.insert(items, 1, autoXHash({ [H(OK.sb)] = H(ROW_CRATE, 3) }))
    table.insert(items, 1, autoXHash({ [H(OK.sb)] = H(BV.CFG.rowChance, 3) }))
    table.insert(items, 1, autoXHash({ [H(OK.sb)] = H(BV.CFG.rowKills, 3) }))
    table.insert(items, 1, autoXHash({ [H(OK.sb)] = H(ROW_BALANCE, 3) }))
  end
  local function sectionsWrap(orig, tag)
    return function(tab, c, idx, ...)
      if BV.probing then if BV.probeTag == tag then BV.hit = true end; return nil end
      local res = orig(tab, c, idx, ...)
      if not BV.enabled then return res end
      pcall(function()
        local O = g("OPTIONS")
        if not (type(tab) == "table" and type(O) == "table" and type(O.TabIds) == "table" and tab[H(OK.id)] == O.TabIds.DEBUG) then return end
        local groups
        if idx == nil then
          local s1 = type(res) == "table" and res[1]
          groups = s1 and s1[H(OK.list)]
        elseif idx == 1 then
          groups = res
        end
        local g1 = type(groups) == "table" and groups[1]
        if g1 then injectRows(g1[H(OK.list)]) end
      end)
      return res
    end
  end

  -- ---------------------------------------------------------------------------------------------------
  -- CRATES tab in the Zombies lobby's top bar, between OPERATORS and CAREER (v1.3).
  -- The bar is the MainMenuTabs widget (ui\generated\widgets\frontend\mainmenutabs.lua): its SetupTabs(opts)
  -- reads opts.tabLayout (an array of tab ids) and looks each id up in MAINMENUTABS.TabData; a tab's body is
  -- the registered widget type named by the entry's menuName. So: register our page type "cratesmenu", add a
  -- TabData entry for it, and hand SetupTabs a copy of the Zombies layout with our id after OPERATORS (copy, not
  -- the shared table, which the game edits with table.remove). Buttons are the game's own lobby button widget,
  -- built and wired the way Kronos builds its ZMModes tiles (LUIFPSCounter.lua).
  -- Field names are tried plain and hashed, since the game uses both.
  local TAB = { id = "ef6ddde2fa3fed9e", tabs = "a4b3acf19c88894f", ops = "6f5877a0229c03a2", career = "3744606a3e0acbbc",
    zmLobbies = { "5581b8d8a3324627", "89e9918304f5ed42" },   -- ZMPublicLobby, ZMMainMenu
    x = 88, w = 424, y = 200, step = 72, btnH = 64, vialSize = 84, d = {},
    infoX = 560, infoY = 200 }   -- the stats panel, right of the button column
  BV.TAB = TAB
  function TAB.fld(t, name, hex)
    if type(t) ~= "table" then return nil end
    local v
    pcall(function() v = t[name] end)
    if v == nil and hex then pcall(function() v = t[H(hex)] end) end
    return v
  end
  function TAB.mmt()
    local M = g("MAINMENUTABS")
    if type(M) ~= "table" then pcall(function() M = _G[H(TAB.tabs)] end) end   -- same hash as "MainMenuTabs"
    return type(M) == "table" and M or nil
  end
  function TAB.entry()
    local TD = TAB.fld(TAB.mmt(), "TabData", "309fdbffe3f6acd4")
    if type(TD) ~= "table" then return false end
    local id = H(TAB.id)
    if rawget(TD, id) ~= nil then return true end
    local base = TD[H(TAB.career)]
    local e = {}
    local function put(k, hex, v) e[k] = v; e[H(hex)] = v end
    put("name", "c4bcadba8e631b86", "CRATES")
    put("menuName", "990326a21401d8e1", id)
    put("menuSound", "fca69512ae7efd51", TAB.fld(base, "menuSound", "fca69512ae7efd51"))
    put("isHidden", "519d3113d1800ca9", function() return false end)
    put("isDisabled", "4c90bd2a41b080f5", function() return false end)
    rawset(TD, id, e)
    note("crates tab entry added")
    return true
  end
  -- the copy of the layout with our tab after OPERATORS, or nil if this isn't the Zombies lobby's layout
  function TAB.layoutWith(layout)
    if type(layout) ~= "table" then return nil end
    local id, ops = H(TAB.id), H(TAB.ops)
    local isZm
    local L = TAB.fld(TAB.mmt(), "Layouts", "691c92d7bd2a93c4")
    if type(L) == "table" then
      for _, hx in ipairs(TAB.zmLobbies) do
        local zl = L[H(hx)]
        if zl == layout then isZm = true end
        -- or a filtered copy of it, while a Zombies lobby is the one being built: every tab in it is a Zombies
        -- tab, OPERATORS among them
        if not isZm and TAB.zmBuild and type(zl) == "table" then
          local inZm, all, hasOps = {}, true, false
          for _, v in ipairs(zl) do inZm[v] = true end
          for _, v in ipairs(layout) do if not inZm[v] then all = false end; if v == ops then hasOps = true end end
          isZm = all and hasOps and #layout > 0
        end
      end
    else
      local hasOps, hasCareer = false, false   -- Layouts unreadable: any layout with OPERATORS and CAREER
      for _, v in ipairs(layout) do if v == ops then hasOps = true elseif v == H(TAB.career) then hasCareer = true end end
      isZm = hasOps and hasCareer
    end
    if not isZm then return nil end
    local l, placed = {}, false
    for _, v in ipairs(layout) do
      if v == id then return nil end
      l[#l + 1] = v
      if v == ops then l[#l + 1] = id; placed = true end
    end
    if not placed then l[#l + 1] = id end
    return l
  end
  function TAB.onTabsBuilt(m)
    TAB.d.bars = (TAB.d.bars or 0) + 1
    local key = "SetupTabs"
    if type(TAB.fld(m, "SetupTabs")) ~= "function" then key = H("48b48da305eccb42") end
    local orig = m[key]
    if type(orig) ~= "function" then TAB.d.last = "bar has no SetupTabs"; return end
    if BV.seen[orig] then return end
    local w = function(self, opts, ...)
      if BV.enabled then
        TAB.d.setup = (TAB.d.setup or 0) + 1
        local okP, eP = pcall(function()
          if not TAB.entry() then TAB.d.last = "no TabData"; return end
          if type(opts) ~= "table" then return end     -- some calls pass a number here (seen in game)
          local lk = TAB.fld(opts, "tabLayout") ~= nil and "tabLayout" or H("d13803605fe04b62")
          local lay = opts[lk]
          if type(lay) ~= "table" then TAB.d.last = "no tabLayout (" .. type(opts) .. ")"; return end
          local present = false
          for _, v in ipairs(lay) do if v == H(TAB.id) then present = true end end
          if present then TAB.d.last = "in layout (" .. #lay .. " tabs)"; return end
          local l = TAB.layoutWith(lay)
          if l then opts[lk] = l; TAB.d.last = "added (" .. #l .. " tabs)"; note("crates tab added to the lobby bar")
          else TAB.d.last = "not zm layout (" .. #lay .. " tabs" .. (TAB.zmBuild and ", in zm build" or "") .. ")" end
        end)
        if not okP then TAB.d.last = "err " .. tostring(eP) end
      end
      return orig(self, opts, ...)
    end
    BV.seen[w] = true
    m[key] = w
    TAB.d.wrapped = (TAB.d.wrapped or 0) + 1
  end

  -- one of the game's lobby buttons with a label; action runs on press (debounced: two targets fire)
  -- box (optional) = { x, w, h } in page px; the result's bvRelabel(text) changes the label later
  function TAB.button(parent, c, label, y, action, box)
    local btn, lib
    local rx = g("requirexhash")
    local okL = pcall(function()
      if rx then pcall(rx, H("160b3fb9e4ab2e09")) end
      local dc = g("_DataSources")[H("f71428806887f67d")][H("1ccae3b6ef72f533")][H("05d757d4f38c9d14b")]
      btn = g("MenuBuilder").BuildRegisteredType(H("160b3fb9e4ab2e09"), { controllerIndex = c, dataContext = dc })
    end)
    if okL and btn then
      lib = btn[H("e005326e765debe5")]
    else
      if rx then pcall(rx, H("3246871af1e086b7")) end
      btn = g("MenuBuilder").BuildRegisteredType(H("3246871af1e086b7"), { controllerIndex = c })
    end
    local bx, bw, bh = box and box.x or TAB.x, box and box.w or TAB.w, box and box.h or TAB.btnH
    btn:SetAnchorsAndPosition(0, 1, 0, 1, bx, bx + bw, y, y + bh)
    -- the label is set once and its setText disabled (the button's own data would overwrite it, as in Kronos);
    -- the originals are kept so bvRelabel can still change it
    local setters = {}
    for _, holder in ipairs({ btn, lib }) do
      for _, key in ipairs({ "69f6cc5b1a5cbb83", "39f7fcec8fcb623d" }) do
        local el = holder and holder[H(key)]
        if el then pcall(function()
          local orig = el.setText
          orig(el, label); el.setText = function() end
          setters[#setters + 1] = function(t) orig(el, t) end
        end) end
      end
    end
    btn.bvRelabel = function(t) for _, s in ipairs(setters) do pcall(s, t) end end
    local last = -1
    local function fire()
      local clk = (type(os) == "table" and os.clock) and os.clock() or nil
      if clk then if clk - last < 0.4 then return end; last = clk end
      local ok, e = pcall(action)
      if not ok then BV.msg = "Crate error: " .. tostring(e); note(BV.msg) end
      pcall(TAB.refresh)
    end
    for _, tgt in ipairs({ btn, lib }) do
      if tgt then pcall(function() tgt:addEventHandler(H("e7eefe998522ec88"), fire) end) end
    end
    parent:addElement(btn)
    return btn
  end
  -- the stats under the buttons; redrawn after every action
  function TAB.refresh()
    local page = TAB.page
    if not page then return end
    if TAB.info then pcall(function() TAB.info:closeTree() end) end
    local info = group(page)
    TAB.info = info
    local st = readState()
    local GOLD, DIMC, BLOOD = 15124630, 11050670, 13382451
    local y = TAB.infoY
    -- y counts from the top of the page; textLine/place take offsets from its centre (1920x1080)
    local function line(str, h, rgb, gap) textLine(info, string.upper(str), 0, y + h / 2 - 540, h, { left = TAB.infoX, rgb = rgb, track = 0.06, maxW = 760 }); y = y + h + (gap or 14) end
    if not st then line("Can't read the save", 28, BLOOD); return end
    -- the vial picture (images\bv_vial.png, 256 px with transparency) beside the balance
    local vs = TAB.vialSize
    local vial = image(info, "bv_vial")
    place(vial, TAB.infoX + vs / 2 - 960, y + 22 - 540, vs, vs)
    textLine(info, string.upper(st.vials .. " Blood Vials"), 0, y + 22 - 540, 44, { left = TAB.infoX + vs + 12, rgb = BLOOD, track = 0.06, maxW = 760 })
    y = y + math.max(44, vs / 2 + 22) + 18
    local cfgK, cfgC = BV.CFG.read()
    line(cfgC and ("Drop chance  " .. BV.CFG.pct .. "% per zombie") or
      ("Next vial  " .. math.min(st.progress, cfgK) .. " / " .. cfgK .. " kills"), 24, DIMC, 26)
    line("Seasonal weapons  " .. st.count .. " / " .. POOL_SIZE, 28, GOLD)
    line("Blueprints  " .. st.bpCount .. " / " .. (BP.data() and BP.size or "?"), 28, GOLD)
    for _, kind in ipairs(PK.kinds) do
      line(PK.label[kind] .. " augments  " .. PK.count(st, kind) .. " / " .. (PK.data() and PK.augTotal[kind] or "?"), 28, GOLD)
    end
    -- the Apothicon vial picture left of its line
    local apIcon = image(info, "bv_vial_apothicon")
    place(apIcon, TAB.infoX - 26 - 960, y + 14 - 540, 44, 44)
    line("Apothicon Blood Vials  " .. st.ap, 28, 8370431)
    line("Wonder weapon skins  " .. st.wwCount .. " / " .. (WW.data() and WW.size or "?") ..
      ((RL.data() and st.rl[1]) and "   +  Peeks' Mayhem" or ""), 28, GOLD, 26)
    if RL.data() then
      local n = 0
      for i = 2, #RL.list do if st.rl[i] then n = n + 1 end end
      line("Cursed relics  " .. n .. " / " .. RL.size, 28, GOLD, 26)
    end
    if BV.msg then line(BV.msg, 22, DIMC) end
  end
  function TAB.build(menu, data)
    local c = (type(data) == "table" and (data.controllerIndex or TAB.fld(data, "controllerIndex", "32d735e646893dd7"))) or 0
    local page = g("LUI").UIElement.new()
    page:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)
    TAB.page, TAB.info = page, nil
    local ok, e = pcall(function()
      local items = {
        { "Seasonal Crate  -  " .. CRATE_COST .. " vials", openCrate },
        { "Blueprint Crate  -  " .. BP.cost .. " vials", BP.open },
      }
      for _, kind in ipairs(PK.kinds) do
        items[#items + 1] = { PK.label[kind] .. " Crate  -  " .. PK.cost[kind] .. " vials", function() PK.open(kind) end }
      end
      items[#items + 1] = { "Relic Crate  -  " .. RL.cost .. " vials", RL.open }
      items[#items + 1] = { "Apothicon Crate  -  1 Apothicon vial", WW.open }
      if REVEAL.preview then items[#items + 1] = { "Preview Reveal", BV.preview } end
      local EBU = g("ElementAndButtonUtils")
      local link, dirs
      pcall(function() link = EBU[H("042b31d442266478c")]; dirs = EBU[H("075992a095c731b0c")] end)
      local prev, first
      for i, it in ipairs(items) do
        local okB, b = pcall(TAB.button, page, c, it[1], TAB.y + (i - 1) * TAB.step, it[2])
        if okB and b then
          if prev and link and dirs then
            pcall(link, prev, b, dirs[H("dc04126761bb7455")])
            pcall(link, b, prev, dirs[H("08c43a07b566d980")])
          end
          prev, first = b, first or b
        else
          note("tab button " .. i .. " failed: " .. tostring(b))
        end
      end
      if first then pcall(function() page:SetDefaultFocusToElement(first) end) end
      TAB.refresh()
    end)
    if not ok then note("crates page error: " .. tostring(e)) end
    return page
  end
  -- Second route: put our id into the game's own Zombies layouts (after OPERATORS), so the tab is there even if
  -- the SetupTabs hook never runs. Skipped where it's already present. Retried on every reinstall.
  function TAB.patchShared()
    local L = TAB.fld(TAB.mmt(), "Layouts", "691c92d7bd2a93c4")
    if type(L) ~= "table" then TAB.d.shared = TAB.mmt() and "no Layouts" or "no MAINMENUTABS"; return end
    if not TAB.entry() then TAB.d.shared = "no TabData"; return end
    local id, ops, n = H(TAB.id), H(TAB.ops), 0
    for _, hx in ipairs(TAB.zmLobbies) do
      local zl = L[H(hx)]
      if type(zl) == "table" then
        local at, has = nil, false
        for i, v in ipairs(zl) do if v == id then has = true elseif v == ops then at = i end end
        if not has and at then table.insert(zl, at + 1, id) end
        if has or at then n = n + 1 end
      end
    end
    TAB.d.shared = n > 0 and ("in " .. n .. " layouts") or "zm layouts not found"
  end
  -- one line for the Blood Vials row: what the tab hooks have seen
  function TAB.status()
    local d = TAB.d
    return "tab: " .. tostring(d.inst or "not installed") .. ", shared " .. tostring(d.shared or "-") ..
      ", zm lobby " .. (d.zm or 0) .. ", bars " .. (d.bars or 0) .. "/" .. (d.wrapped or 0) ..
      ", setup " .. (d.setup or 0) .. " " .. tostring(d.last or "-") .. ", page " .. (d.page or 0)
  end
  function TAB.install()
    pcall(TAB.patchShared)
    local MB = g("MenuBuilder")
    if type(MB) ~= "table" then TAB.d.inst = "no MenuBuilder"; return end
    BV.tabMB = BV.tabMB or setmetatable({}, { __mode = "k" })
    if BV.tabMB[MB] then return end
    local reg = TAB.fld(MB, "registerType", "613f80741f884a88")
    local cur = MB.BuildRegisteredType
    if type(reg) ~= "function" or type(cur) ~= "function" then TAB.d.inst = "no registerType"; return end
    local okR, eR = pcall(reg, H(TAB.id), function(menu, data) TAB.d.page = (TAB.d.page or 0) + 1; return TAB.build(menu, data) end)
    -- widgets are asked for by hash or by plain name (Kronos's own lobby code checks both)
    local tabsKeys = { [tostring(H(TAB.tabs))] = true, mainmenutabs = true }
    local zmKeys = { zmpubliclobby = true, zmmainmenu = true }
    for _, hx in ipairs(TAB.zmLobbies) do zmKeys[tostring(H(hx))] = true end
    local popupKey = tostring(H("b1f0954b3e9943f9"))
    local w = function(t, data, ...)
      local ts = tostring(t)
      local tl = type(t) == "string" and ts:lower() or ts
      if BV.enabled and (ts == popupKey or tl == "removeattachmentrestrictedpopup") then pcall(BPB.onPopup, data) end
      if zmKeys[ts] or zmKeys[tl] then
        TAB.d.zm = (TAB.d.zm or 0) + 1
        pcall(TAB.patchShared)
        -- while a Zombies lobby builds (its tab bar is set up inside), mark it for TAB.layoutWith
        local outer = TAB.zmBuild
        TAB.zmBuild = true
        local ok, a, b, c = pcall(cur, t, data, ...)
        TAB.zmBuild = outer
        if not ok then error(a, 0) end
        return a, b, c
      end
      local a, b, c = cur(t, data, ...)
      if a and BV.enabled and (tabsKeys[ts] or tabsKeys[tl]) then pcall(TAB.onTabsBuilt, a) end
      if a and BV.enabled and BV.RS then pcall(BV.RS.onBuilt, ts, tl, a) end
      return a, b, c
    end
    MB.BuildRegisteredType = w
    BV.tabMB[MB] = true
    TAB.d.inst = "installed" .. (okR and "" or " (register failed: " .. tostring(eR) .. ")")
    note("crates tab hooks installed (page registered: " .. tostring(okR) .. (okR and "" or ", " .. tostring(eR)) .. ")")
  end

  -- ---------------------------------------------------------------------------------------------------
  -- In-match splash when you earn vials (v1.4). zm_blood_vials.gsc writes "bvgain=<seq>.<amount>.<reason>" into
  -- kronos_bo6_var each time (reason "k" = kills, "r<n>" = round n survived); a hidden timer element on the UI
  -- root polls it and slides in a panel: the vial picture, "+N BLOOD VIALS", the reason and the new total.
  -- The timer dies when the UI root is rebuilt (map load); any button press restarts it (inputWrap).
  local SPL = { entry = "bvgain", period = 200,
    x = 1880, y = 300, w = 470, h = 120, vial = 110,     -- right edge, top, size (1920x1080 px)
    inMs = 260, hold = 2800, outMs = 450, slide = 70,
    sound = { { "challengeSplash", "rewardNotification" }, { "zmIngame", "gg_get" } },
    queue = {}, n = 0 }
  BV.SPL = SPL
  function SPL.status()
    return "splash: " .. (SPL.alive and "watching" or "idle") .. ", shown " .. SPL.n .. (SPL.err and (", " .. SPL.err) or "")
  end
  function SPL.poll()
    if inFrontend() then SPL.base = nil; return end
    local cur = bo6Get()
    if cur == nil then return end
    local v = entryOf(cur, SPL.entry) or ""
    if SPL.base == nil then SPL.base = v; return end    -- first look in this match: just remember it
    if v == SPL.base then return end
    SPL.base = v
    local amt, why = v:match("^%d+%.(%d+)%.(%w*)$")
    if amt then SPL.queue[#SPL.queue + 1] = { amount = tonumber(amt), why = why }; SPL.next() end
  end
  function SPL.next()
    if SPL.showing or #SPL.queue == 0 then return end
    local s = table.remove(SPL.queue, 1)
    local ok, e = pcall(SPL.show, s)
    if not ok then SPL.showing = nil; SPL.err = tostring(e); note("splash error: " .. SPL.err) end
  end
  function SPL.show(s)
    local LUI = g("LUI")
    local ov = group(LUI.GetRoot())
    SPL.showing = ov
    SPL.n = SPL.n + 1
    local st = readState()
    local x0, y0, W, Hh = SPL.x - SPL.w, SPL.y, SPL.w, SPL.h
    -- positions are page px (1920x1080) turned into offsets from the centre, which place() takes
    local function at(e, x, y, w, h) place(e, x - 960, y - 540, w, h) end
    -- backing: a dark band, a thin blood-red edge on the right
    -- reason "a" = an Apothicon Blood Vial for a completed main quest: aether blue instead of blood red, with its own
    -- picture images\bv_vial_apothicon.png (else the vial picture tinted)
    local apo = s.why == "a"
    local back = image(ov, "soe_white", { rgb = 0, a = 0.62 })
    at(back, x0 + W / 2, y0 + Hh / 2, W, Hh)
    local edge = image(ov, "soe_white", { rgb = apo and 3837439 or 11141120, a = 0.9 })
    at(edge, SPL.x - 2, y0 + Hh / 2, 4, Hh)
    local glow = image(ov, "mbox_dot", { add = true, rgb = apo and 3107839 or 13369344, a = 0.55 })
    at(glow, x0 + 20 + SPL.vial / 2, y0 + Hh / 2, SPL.vial * 1.6, SPL.vial * 1.6)
    local own = apo and mat("bv_vial_apothicon")
    local vial = image(ov, own and "bv_vial_apothicon" or "bv_vial", { rgb = (apo and not own) and 8370431 or nil })
    at(vial, x0 + 20 + SPL.vial / 2, y0 + Hh / 2, SPL.vial, SPL.vial)
    local tx = x0 + 30 + SPL.vial
    local title = "+" .. s.amount .. (apo and " APOTHICON" or "") .. " BLOOD VIAL" .. (s.amount == 1 and "" or "S")
    textLine(ov, title, 0, y0 + 38 - 540, 40, { left = tx, rgb = apo and 10474751 or 15073298, track = 0.05, maxW = SPL.x - tx - 16 })
    local why = apo and "MAIN QUEST COMPLETE" or s.why == "k" and "KILLS" or s.why == "c" and "LUCKY DROP"
      or s.why == "e" and "ELITE KILL" or s.why == "x" and "EXFIL COMPLETE"
      or (s.why or ""):match("^r(%d+)$") and ("ROUND " .. s.why:sub(2) .. " SURVIVED") or ""
    local total = st and (apo and (st.ap .. " APOTHICON TOTAL") or (st.vials .. " TOTAL"))
    textLine(ov, why .. (total and ((why ~= "" and "   -   " or "") .. total) or ""), 0, y0 + 82 - 540, 22,
      { left = tx, rgb = 12632256, track = 0.08, maxW = SPL.x - tx - 16 })
    for _, snd in ipairs(SPL.sound) do if SFX.play(snd[1], snd[2]) then break end end
    local now, total = 0, SPL.inMs + SPL.hold + SPL.outMs
    local function step()
      if SPL.showing ~= ov then return end
      local a = ease(now / SPL.inMs) * (1 - ease((now - SPL.inMs - SPL.hold) / SPL.outMs))
      local dx = SPL.slide * (1 - easeOut(now / SPL.inMs))
      pcall(function() ov:SetAnchorsAndPosition(0, 0, 0, 0, dx, dx, 0, 0); ov:SetAlpha(a, 0) end)
      if now >= total then
        pcall(function() ov:closeTree() end)
        SPL.showing = nil
        SPL.next()
        return
      end
      now = now + 16
      local okW, anim = pcall(function() return ov:Wait(16) end)
      if not okW or not anim then pcall(function() ov:closeTree() end); SPL.showing = nil; return end
      anim.onComplete = step
    end
    step()
  end
  -- the polling timer: a hidden element on the UI root that re-arms Wait(period)
  function SPL.ensure()
    if not BV.enabled then return end
    local LUI = g("LUI")
    local root
    pcall(function() root = LUI.GetRoot() end)
    if not root then return end
    if SPL.timer and SPL.alive then
      local okP, parent = pcall(function() return SPL.timer:getParent() end)
      if not okP or parent == root then return end     -- still attached (or can't tell): keep it
    end
    local host = LUI.UIElement.new()
    host:SetAnchorsAndPosition(0, 0, 0, 0, 0, 0, 0, 0)
    pcall(function() host:SetHandleMouse(false) end)
    root:addElement(host)
    SPL.timer, SPL.alive = host, true
    local function tick()
      if SPL.timer ~= host or not BV.enabled then return end
      local ok, e = pcall(SPL.poll)
      if not ok then SPL.err = tostring(e) end
      -- watchdog: a reveal whose own timer stopped (e.g. the menu was torn down under it) is closed here, so its
      -- sound loops can't keep playing. 5 checks (~1 s) without a new frame.
      local a = BV.revealActive
      if a then
        if a.frames == a.dogFrames then a.dog = (a.dog or 0) + 1 else a.dogFrames, a.dog = a.frames, 0 end
        if a.dog >= 5 then note("reveal stopped advancing; closed by the watchdog"); pcall(a.finish) end
      end
      local okW, anim = pcall(function() return host:Wait(SPL.period) end)
      if not okW or not anim then if SPL.timer == host then SPL.alive = false end; return end
      anim.onComplete = tick
    end
    tick()
  end

  -- While a reveal plays, button presses don't reach the menu behind it (they used to move the Debug Options
  -- focus). Every press goes through LUI.UIRoot.QueueInput (the Ashes overlay and zm_mod_menu wrap it too);
  -- ours drops the call while a reveal is up. Safety: if the reveal stops advancing (its timer died), the
  -- block lets go after INPUT_STALL presses and closes the reveal, so the menu can never get stuck.
  local K_QUEUEINPUT, INPUT_STALL = "62c1c7577c5a678c", 120
  local function inputWrap(orig)
    return function(...)
      if BV.enabled then pcall(SPL.ensure) end   -- restarts the splash timer after a UI root rebuild
      local a = BV.revealActive
      if a and BV.enabled then
        if a.frames ~= a.seenFrames then a.seenFrames, a.stalled = a.frames, 0 else a.stalled = (a.stalled or 0) + 1 end
        if a.stalled <= INPUT_STALL then BV.swallowed = (BV.swallowed or 0) + 1; return end
        note("reveal stalled; input released")
        pcall(a.finish)
      end
      return orig(...)
    end
  end
  local function installInput()
    local R = g("LUI") and g("LUI").UIRoot
    if type(R) ~= "table" then return end
    -- once per UI root: other mods wrap this on top of ours, so "is ours on top" can't be checked
    BV.inputRoots = BV.inputRoots or setmetatable({}, { __mode = "k" })
    if BV.inputRoots[R] then return end
    local key = H(K_QUEUEINPUT)
    local cur = R.QueueInput
    if type(cur) ~= "function" then cur = R[key] end
    if type(cur) ~= "function" or BV.seen[cur] then return end
    local w = inputWrap(cur)
    BV.seen[w] = true
    R.QueueInput = w; R[key] = w
    BV.inputRoots[R] = true
    note("hooked input")
  end

  -- ---------------------------------------------------------------------------------------------------
  -- Augment research off (v1.44). Augments come from crates only, so research (the XP bar in the Augments menu)
  -- must not unlock anything and isn't shown:
  -- - every function of the game's ZMAUGMENT table (ui\utils\zm\zmaugmentutils.lua) is wrapped; in what it returns,
  --   an entry with "isUnlocked" that names one of our augments answers from the crates, and the landing button
  --   "loadout_augment_research" is taken out of button lists. (The game's isUnlocked is PROGRESSION 13d8..., which
  --   is hooked above anyway; this is the second line.)
  -- - the active-research panel (AugmentActiveResearch) and the "research complete" splash
  --   (AugmentResearchCompleteSplash) are built invisible (alpha held at 0), by FNV-1a 64 of the type name.
  -- First hits of each kind go to the game log ("research: ...").
  BV.RS = { on = true, budget = 600, n = { unl = 0, btn = 0, hid = 0, wrapped = 0 }, said = {},
    hide = { f05ce4ef9ae36b41 = "research splash", ["28cdc1c63615878f"] = "active research" },
    plain = { augmentresearchcompletesplash = "research splash", augmentactiveresearch = "active research" } }
  function BV.RS.say(kind, s)
    if BV.RS.said[kind] then return end
    BV.RS.said[kind] = true
    note("research: " .. s)
    BV.klog("research: " .. s)
  end
  -- one of our augments' loot IDs among an entry's plain values, or nil
  function BV.RS.augOf(t)
    for _, v in pairs(t) do
      local n = tonumber(v)
      if n and PK.index[n] then return n end
    end
    return nil
  end
  function BV.RS.walk(t, depth, seen)
    local RS = BV.RS
    if seen[t] or RS.left <= 0 then return end
    seen[t] = true
    RS.left = RS.left - 1
    for i = #t, 1, -1 do
      local e = rawget(t, i)
      if type(e) == "table" and rawget(e, "button_ref") == "loadout_augment_research" then
        table.remove(t, i)
        RS.n.btn = RS.n.btn + 1
        RS.say("btn", "research button removed from a list of " .. (#t + 1))
      end
    end
    if rawget(t, "isUnlocked") ~= nil then
      local id = RS.augOf(t)
      local st = id and readState()
      if st then
        local own = PK.owned(st, id) and true or false
        if rawget(t, "isUnlocked") ~= own then
          rawset(t, "isUnlocked", own)
          RS.n.unl = RS.n.unl + 1
          RS.say("unl", "augment " .. id .. " isUnlocked set to " .. tostring(own))
        end
      end
    end
    if depth <= 0 then return end
    for _, v in pairs(t) do
      if type(v) == "table" and getmetatable(v) == nil then RS.walk(v, depth - 1, seen) end
    end
  end
  function BV.RS.filter(...)
    local RS = BV.RS
    if not (BV.enabled and RS.on and PK.data()) then return end
    for i = 1, select("#", ...) do
      local v = select(i, ...)
      if type(v) == "table" and getmetatable(v) == nil then
        RS.left = RS.budget
        RS.walk(v, 3, {})
      end
    end
  end
  function BV.RS.hook()
    local Z = g("ZMAUGMENT")
    if type(Z) ~= "table" then return end
    local RS = BV.RS
    for k, f in pairs(Z) do
      if type(f) == "function" and not BV.seen[f] then
        local w = function(...)
          local r = { n = select("#", ...) }
          local function keep(...) r.n = select("#", ...); for i = 1, r.n do r[i] = select(i, ...) end end
          keep(f(...))
          pcall(RS.filter, unpack(r, 1, r.n))
          return unpack(r, 1, r.n)
        end
        BV.seen[w] = true
        if pcall(function() Z[k] = w end) and Z[k] == w then RS.n.wrapped = RS.n.wrapped + 1 end
      end
    end
    if RS.n.wrapped > 0 then RS.say("hook", "wrapped " .. RS.n.wrapped .. " ZMAUGMENT functions") end
  end
  -- MenuBuilder.BuildRegisteredType just built type t (hash or plain name) as element el
  function BV.RS.onBuilt(ts, tl, el)
    local RS = BV.RS
    if not (RS.on and type(el) == "table") then return end
    RS.keys = RS.keys or {}
    if not RS.keys.done then
      for hx, what in pairs(RS.hide) do RS.keys[tostring(H(hx))] = what end
      RS.keys.done = true
    end
    local what = RS.keys[ts] or RS.plain[tl]
    if not what then return end
    for _, m in ipairs({ "setAlpha", "SetAlpha" }) do
      local o = el[m]
      if type(o) == "function" then
        pcall(o, el, 0)
        el[m] = function(self, a, ...) return o(self, 0, ...) end
      end
    end
    RS.n.hid = RS.n.hid + 1
    RS.say("hid " .. what, what .. " hidden")
  end

  local function install()
    if not BV.enabled then return end
    pcall(BV.RS.hook)
    pcall(installInput)
    pcall(TAB.install)
    pcall(SPL.ensure)
    pcall(RL.hookSlot)
    pcall(BPB.hookEngine)
    pcall(BPB.hookGunsmith)
    pcall(BPB.hookAll)
    pcall(BPB.refresh)
    hookSlot(g("PROGRESSION"), K_OWNED, "progression ownership", ownedWrap)
    hookSlot(g("LOOT"), K_OWNED, "loot ownership", ownedWrap)
    hookSlot(g("LOOT"), K_COUNT, "loot count", countWrap)
    hookFn(g("Loot"), K_ISOWNED, "loot item count", countWrap, CTRL, 0)
    hookFn(g("PROGRESSION"), "13d8bd2b211db6cc", "progression isUnlocked", unlockWrap("unlocked", 3), CTRL, 0, 0)
    hookFn(g("PROGRESSION"), "d261f5c903836da1", "progression unlock exception", unlockWrap("exception", 1), 0)
    hookFn(g("PROGRESSION"), "e674987666a8f72d", "progression getunlockrank", rankWrap, CTRL, 0)
    hookFn(g("PROGRESSION"), "46fc982e0fbfc242", "progression isitempermanentlyunlocked", permWrap, CTRL, 0)
    -- v1.39: the weapon screens' lock gate and unlock text (probed with a real gun, Echo 12)
    hookFn(g("PROGRESSION"), "bd17a9fde01bef42", "progression unlock gate", gateWrap, CTRL, 88928)
    hookFn(g("PROGRESSION"), "2f511c84503e24fd", "progression unlock text", textWrap, CTRL, 88928)
    hookFn(g("LOOT"), "46fc982e0fbfc242", "loot isitempermanentlyunlocked", permWrap, CTRL, 0)
    local O = g("OPTIONS")
    if type(O) == "table" and type(O.TabIds) == "table" and O.TabIds.DEBUG ~= nil then
      hookFn(O, OPT_DATA_A, "options data A", dataWrap, probeSb)
      hookFn(O, OPT_DATA_B, "options data B", dataWrap, probeSb, CTRL)
      hookFn(O, OPT_SECTIONS, "debug options rows", sectionsWrap, {}, CTRL)
    end
  end
  BV.reinstall = install
  BV.isLocked = isLocked
  BV.readState = readState
  BV.openCrate = openCrate

  pcall(install)
  -- Re-check after module loads, the same moments Kronos re-applies its own hooks
  for _, rq in ipairs({ "require", "requireUnlessHotload", "requirexhash" }) do
    pcall(function()
      local o = rawget(_G, rq)
      if type(o) ~= "function" or BV.seen[o] then return end
      local w = function(...)
        local r = { n = 0 }
        local function keep(...) r.n = select("#", ...); for i = 1, r.n do r[i] = select(i, ...) end end
        keep(o(...))
        local B = rawget(_G, "BloodVials")
        if B and B.reinstall then pcall(B.reinstall) end
        return unpack(r, 1, r.n)
      end
      BV.seen[w] = true
      rawset(_G, rq, w)
    end)
  end
  note("loaded, pool " .. POOL_SIZE .. ", entry " .. tostring(entryOf(bo6Get() or "")))
end
