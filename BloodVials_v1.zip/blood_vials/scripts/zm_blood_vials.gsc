// Blood Vials v1: earning, in Zombies matches (runs on the host only, like every Kronos script).
// 1 vial per bv_kills_per_vial kills by the host, +BV_ROUND_BONUS each time BV_ROUND_EVERY rounds are completed.
// v1.32: the menu's Debug Options set "bvcfg=<kills 1..25>.<chance 0|1>" in kronos_bo6_var. Chance mode: every
// zombie the host kills has a 7% chance of a vial instead of the kill count. Either way an elite (or HVT / boss)
// kill gives 1 vial, a special zombie counts as 10 kills (10 rolls in chance mode), and a successful exfil gives 3.
// State ("bv1|rev|vials|kill_progress|id,id,..." or "-" for no ids) is the "bloodvials=" entry of Kronos's
// dvar kronos_bo6_var, which the menu Lua reads and Kronos's mp_bo6_store.gsc saves (Kronos runs no other
// script in the menus). Backup copy: the Kronos store kronos\bloodvials\state.json.
// Status for debugging: dvar bloodvials_status (v1.47: "zm kills <banked> of <per vial>, vials <n>" after each kill).

#using script_4c770a9a4ad7659c;
#using script_3f8889c16399185c;
#using script_77dca3b46e01eb1e;

autoexec zm_blood_vials_init()
{
    level.bv_kills_per_vial = 25;
    level.bv_chance = 0;
    level.bv_chance_pct = 7;
    level.bv_special_weight = 10;
    level.bv_exfil_bonus = 3;
    level.bv_exfil_done = 0;
    level.bv_round_every = 5;
    level.bv_round_bonus = 3;
    level.bv_ready = 0;
    level.bv_gain_seq = 0;
    level thread zm_blood_vials_boot();
    level namespace_42ffbe510c7bd5b1::function_3e93ae4f7823fe81(#"on_ai_killed", &zm_blood_vials_on_kill);
    level namespace_42ffbe510c7bd5b1::function_3e93ae4f7823fe81("on_round_start", &zm_blood_vials_on_round);
    // a successful exfil (v1.32): zm_exfil / zm_exfil_sat raise this when the squad gets out (the game's own
    // events.gsc and telemetry listen to it on level the same way)
    level namespace_42ffbe510c7bd5b1::function_3e93ae4f7823fe81("zm_exfil_success", &zm_blood_vials_on_exfil);
    // main quest completed (v1.9): every BO7 map with a main quest raises this when its final boss dies (the game's
    // own achievements, challenges and telemetry listen to it); params.is_main_quest, params.questname
    level namespace_42ffbe510c7bd5b1::function_3e93ae4f7823fe81(#"zm_mq_quest_complete", &zm_blood_vials_on_main_quest);
}

// a map's main quest is done: one Apothicon Blood Vial (latched: once per match)
function zm_blood_vials_on_main_quest(params)
{
    if (isdefined(params) && isdefined(params.is_main_quest) && !params.is_main_quest)
    {
        return;
    }
    zm_blood_vials_award_apothicon("main quest");
}

function zm_blood_vials_boot()
{
    // Two copies: the "bloodvials=" entry in Kronos's dvar kronos_bo6_var (what the menus read and Kronos's
    // mp_bo6_store.gsc saves to bo6\picks.json), and this script's own file (backup if the game closes
    // mid-match). The one with the higher revision wins.
    level.bv_state = "bv1|0|0|0|-";
    from_where = "new";
    if (nengine_store_load("bloodvials", "state"))
    {
        loaded = nengine_store_get("bloodvials", "state");
        if (isdefined(loaded) && zm_blood_vials_valid(loaded))
        {
            level.bv_state = loaded;
            from_where = "file";
        }
    }
    from_var = zm_blood_vials_entry(getdvar("kronos_bo6_var", ""));
    if (isdefined(from_var) && zm_blood_vials_revof(from_var) >= zm_blood_vials_revof(level.bv_state))
    {
        level.bv_state = from_var;
        from_where = "menu";
    }
    zm_blood_vials_unpack(level.bv_state);
    zm_blood_vials_read_cfg();
    setdvar(@"bloodvials_state", level.bv_state);
    zm_blood_vials_put(level.bv_state);
    setdvar(@"bloodvials_status", "zm loaded rev " + level.bv_rev + " vials " + level.bv_vials + " from " + from_where + ", " + zm_blood_vials_cfg_text());
    level.bv_dirty = 0;
    level.bv_last_round = -1;
    level.bv_ready = 1;
    zm_blood_vials_ap_boot();
    level thread zm_blood_vials_saver();
    level thread zm_blood_vials_end_flush();
    level thread zm_blood_vials_test_watch();
}

// testing without finishing a quest: "set bloodvials_test_apothicon 1" in the console during a match runs the same
// award as a completed main quest (still once per match)
function zm_blood_vials_test_watch()
{
    setdvar(@"bloodvials_test_apothicon", "0");
    for (;;)
    {
        wait 1;
        if (getdvarint(@"bloodvials_test_apothicon", 0) == 1)
        {
            setdvar(@"bloodvials_test_apothicon", "0");
            zm_blood_vials_award_apothicon("console test");
        }
    }
}

function zm_blood_vials_valid(text)
{
    parts = strtok(text, "|");
    if (parts.size != 5)
    {
        return 0;
    }
    if (parts[0] != "bv1")
    {
        return 0;
    }
    return 1;
}

function zm_blood_vials_revof(text)
{
    parts = strtok(text, "|");
    if (parts.size < 2)
    {
        return -1;
    }
    return int(parts[1]);
}

// The value of the "bloodvials=" entry in a kronos_bo6_var string, or undefined.
function zm_blood_vials_entry(cur)
{
    parts = strtok(cur, ";");
    for (i = 0; i < parts.size; i++)
    {
        kv = strtok(parts[i], "=");
        if (kv.size == 2 && kv[0] == "bloodvials" && zm_blood_vials_valid(kv[1]))
        {
            return kv[1];
        }
    }
    return undefined;
}

// Rewrite kronos_bo6_var with our entry at the end (Kronos drops the oldest entries when it's full).
function zm_blood_vials_put(state)
{
    zm_blood_vials_put_key("bloodvials", state);
}

// Same for any key of ours ("bloodvials", "bvgain"); every other entry is kept as it was.
function zm_blood_vials_put_key(key, value)
{
    parts = strtok(getdvar("kronos_bo6_var", ""), ";");
    out = "";
    for (i = 0; i < parts.size; i++)
    {
        if (!issubstr(parts[i], key + "="))
        {
            out = out + parts[i] + ";";
        }
    }
    setdvar("kronos_bo6_var", out + key + "=" + value + ";");
}

// Tells the menu Lua's splash that vials were earned: "bvgain=<seq>.<amount>.<reason>" (reason "k" = kills,
// "r<n>" = round n survived). The Lua shows a splash whenever this entry changes.
function zm_blood_vials_gain(amount, why)
{
    level.bv_gain_seq = level.bv_gain_seq + 1;
    zm_blood_vials_put_key("bvgain", "" + level.bv_gain_seq + "." + amount + "." + why);
}

// ---------------------------------------------------------------------------------------------------------
// Apothicon Blood Vials (v1.9): one per completed main quest. Kept as "bvap=<rev>.<count>" in kronos_bo6_var (the
// menu Lua spends them on the Apothicon Crate and raises the revision too) and as key "apothicon" of this script's
// store file. The copy with the higher revision wins.

// the value of any "key=" entry in a kronos_bo6_var string, or undefined
function zm_blood_vials_entry_key(cur, key)
{
    parts = strtok(cur, ";");
    for (i = 0; i < parts.size; i++)
    {
        kv = strtok(parts[i], "=");
        if (kv.size == 2 && kv[0] == key)
        {
            return kv[1];
        }
    }
    return undefined;
}

function zm_blood_vials_ap_part(text, index)
{
    if (!isdefined(text))
    {
        return 0;
    }
    parts = strtok(text, ".");
    if (parts.size != 2)
    {
        return 0;
    }
    return int(parts[index]);
}

function zm_blood_vials_ap_boot()
{
    from_var = zm_blood_vials_entry_key(getdvar("kronos_bo6_var", ""), "bvap");
    from_file = undefined;
    if (nengine_store_load("bloodvials", "state"))
    {
        from_file = nengine_store_get("bloodvials", "apothicon");
    }
    level.bv_ap_rev = zm_blood_vials_ap_part(from_var, 0);
    level.bv_ap = zm_blood_vials_ap_part(from_var, 1);
    if (isdefined(from_file) && zm_blood_vials_ap_part(from_file, 0) > level.bv_ap_rev)
    {
        level.bv_ap_rev = zm_blood_vials_ap_part(from_file, 0);
        level.bv_ap = zm_blood_vials_ap_part(from_file, 1);
        zm_blood_vials_put_key("bvap", "" + level.bv_ap_rev + "." + level.bv_ap);
    }
}

// one Apothicon Blood Vial, once per map per match (why = the map that was completed, for the status line)
function zm_blood_vials_award_apothicon(why)
{
    if (isdefined(level.bv_ap_awarded) && level.bv_ap_awarded)
    {
        return;
    }
    level.bv_ap_awarded = 1;
    if (!isdefined(level.bv_ap))
    {
        zm_blood_vials_ap_boot();
    }
    // the menus may have spent one since the match started (they can't run during a match, but stay safe)
    cur = zm_blood_vials_entry_key(getdvar("kronos_bo6_var", ""), "bvap");
    if (isdefined(cur) && zm_blood_vials_ap_part(cur, 0) > level.bv_ap_rev)
    {
        level.bv_ap_rev = zm_blood_vials_ap_part(cur, 0);
        level.bv_ap = zm_blood_vials_ap_part(cur, 1);
    }
    level.bv_ap_rev = level.bv_ap_rev + 1;
    level.bv_ap = level.bv_ap + 1;
    text = "" + level.bv_ap_rev + "." + level.bv_ap;
    zm_blood_vials_put_key("bvap", text);
    nengine_store_set("bloodvials", "apothicon", text);
    if (isdefined(level.bv_state))
    {
        nengine_store_set("bloodvials", "state", level.bv_state);
    }
    nengine_store_save("bloodvials", "state");
    zm_blood_vials_gain(1, "a");
    setdvar(@"bloodvials_status", "zm apothicon vial for " + why + ": " + level.bv_ap);
}

function zm_blood_vials_unpack(text)
{
    parts = strtok(text, "|");
    level.bv_rev = int(parts[1]);
    level.bv_vials = int(parts[2]);
    level.bv_progress = int(parts[3]);
    level.bv_ids = parts[4];
}

function zm_blood_vials_pack()
{
    return "bv1|" + level.bv_rev + "|" + level.bv_vials + "|" + level.bv_progress + "|" + level.bv_ids;
}

// save_now = 1 (vials changed): publish the new state to the dvar and save to disk now.
// save_now = 0 (only kill progress changed, v1.43): just mark it; the saver publishes and saves within 5 s, and at
// game over (zm_blood_vials_end_flush). Before v1.43 every such kill rewrote the whole kronos_bo6_var string.
function zm_blood_vials_commit(save_now)
{
    if (save_now)
    {
        zm_blood_vials_publish();
        zm_blood_vials_save();
    }
    else
    {
        level.bv_dirty = 1;
    }
}

function zm_blood_vials_publish()
{
    level.bv_rev = level.bv_rev + 1;
    level.bv_state = zm_blood_vials_pack();
    setdvar(@"bloodvials_state", level.bv_state);
    zm_blood_vials_put(level.bv_state);
}

// pending kill progress is published and saved as soon as the match ends
function zm_blood_vials_end_flush()
{
    for (;;)
    {
        wait 0.5;
        if (isdefined(level.b_zm_game_over) && level.b_zm_game_over)
        {
            if (level.bv_dirty)
            {
                zm_blood_vials_publish();
                zm_blood_vials_save();
            }
            return;
        }
    }
}

function zm_blood_vials_save()
{
    nengine_store_set("bloodvials", "state", level.bv_state);
    nengine_store_save("bloodvials", "state");
    level.bv_dirty = 0;
    setdvar(@"bloodvials_status", "zm saved rev " + level.bv_rev + " vials " + level.bv_vials);
}

function zm_blood_vials_saver()
{
    for (;;)
    {
        wait 5;
        zm_blood_vials_read_cfg();
        if (level.bv_dirty)
        {
            zm_blood_vials_publish();
            zm_blood_vials_save();
        }
    }
}

function zm_blood_vials_host()
{
    foreach (p in level.players)
    {
        if (isdefined(p) && p function_b36623eefe0028c8())
        {
            return p;
        }
    }
    return undefined;
}

// the earning settings from the menu's Debug Options: "bvcfg=<kills>.<chance>" (missing = 25 kills, no chance)
function zm_blood_vials_read_cfg()
{
    kills = 25;
    chance = 0;
    cfg = zm_blood_vials_entry_key(getdvar("kronos_bo6_var", ""), "bvcfg");
    if (isdefined(cfg))
    {
        parts = strtok(cfg, ".");
        if (parts.size == 2)
        {
            kills = int(parts[0]);
            chance = int(parts[1]);
        }
    }
    if (kills < 1)
    {
        kills = 1;
    }
    if (kills > 25)
    {
        kills = 25;
    }
    level.bv_kills_per_vial = kills;
    if (chance == 1)
    {
        level.bv_chance = 1;
    }
    else
    {
        level.bv_chance = 0;
    }
}

function zm_blood_vials_cfg_text()
{
    if (level.bv_chance)
    {
        return "chance " + level.bv_chance_pct + "%";
    }
    return "1 per " + level.bv_kills_per_vial + " kills";
}

// 1 = elite, 2 = special, 0 = anything else (HVTs and bosses count as elites, as the game's own scripts group them)
function zm_blood_vials_kind(ai)
{
    if (!isdefined(ai) || !isdefined(ai.aicategory))
    {
        return 0;
    }
    cat = ai.aicategory;
    if (cat == "elite" || cat == "hvt" || cat == "boss")
    {
        return 1;
    }
    if (cat == "special")
    {
        return 2;
    }
    return 0;
}

// the squad got out: +3 vials, once per match
function zm_blood_vials_on_exfil(params)
{
    if (!isdefined(level.bv_ready) || !level.bv_ready)
    {
        return;
    }
    if (level.bv_exfil_done)
    {
        return;
    }
    level.bv_exfil_done = 1;
    level.bv_vials = level.bv_vials + level.bv_exfil_bonus;
    zm_blood_vials_commit(1);
    zm_blood_vials_gain(level.bv_exfil_bonus, "x");
    setdvar(@"bloodvials_status", "zm exfil: +" + level.bv_exfil_bonus + " vials, " + level.bv_vials);
}

// self = the AI that died
function zm_blood_vials_on_kill(params)
{
    if (!isdefined(level.bv_ready) || !level.bv_ready)
    {
        return;
    }
    if (!isdefined(params) || !isdefined(params.eattacker))
    {
        return;
    }
    attacker = params.eattacker;
    if (!isplayer(attacker))
    {
        return;
    }
    if (!attacker function_b36623eefe0028c8())
    {
        return;
    }
    kind = zm_blood_vials_kind(self);
    if (kind == 1)
    {
        // an elite: one vial, whatever the mode
        level.bv_vials = level.bv_vials + 1;
        zm_blood_vials_commit(1);
        zm_blood_vials_gain(1, "e");
        return;
    }
    weight = 1;
    if (kind == 2)
    {
        weight = level.bv_special_weight;
    }
    gained = 0;
    why = "k";
    if (level.bv_chance)
    {
        // chance mode: one roll per kill (a special gets 10)
        why = "c";
        for (i = 0; i < weight; i++)
        {
            if (randomint(100) < level.bv_chance_pct)
            {
                gained = gained + 1;
            }
        }
        level.bv_vials = level.bv_vials + gained;
    }
    else
    {
        // v1.47: the payout as plain arithmetic on checked numbers. v1.32's while loop never paid out in game (the
        // save reached 104 kills banked at 25 per vial), so nothing here relies on the level fields' types.
        per = 25;
        if (isdefined(level.bv_kills_per_vial))
        {
            per = int(level.bv_kills_per_vial);
        }
        if (per < 1)
        {
            per = 25;
        }
        banked = 0;
        if (isdefined(level.bv_progress))
        {
            banked = int(level.bv_progress);
        }
        banked = banked + weight;
        if (banked >= per)
        {
            gained = int(banked / per);
            banked = banked - (gained * per);
            level.bv_vials = int(level.bv_vials) + gained;
        }
        level.bv_progress = banked;
        setdvar(@"bloodvials_status", "zm kills " + banked + " of " + per + ", vials " + level.bv_vials);
    }
    if (gained > 0)
    {
        zm_blood_vials_commit(1);
        zm_blood_vials_gain(gained, why);
    }
    else if (level.bv_chance)
    {
        return;
    }
    else
    {
        zm_blood_vials_commit(0);
    }
}

function zm_blood_vials_on_round(params)
{
    if (!isdefined(level.bv_ready) || !level.bv_ready)
    {
        return;
    }
    round = namespace_7942a9cf653f89::function_c00961f92fc28240();
    if (!isdefined(round))
    {
        return;
    }
    done = round - 1;
    if (done < level.bv_round_every || done == level.bv_last_round)
    {
        return;
    }
    steps = int(done / level.bv_round_every);
    if (steps * level.bv_round_every != done)
    {
        return;
    }
    level.bv_last_round = done;
    level.bv_vials = level.bv_vials + level.bv_round_bonus;
    zm_blood_vials_commit(1);
    zm_blood_vials_gain(level.bv_round_bonus, "r" + done);
}
