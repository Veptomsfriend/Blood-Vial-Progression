Blood Vials - a progression mod for BO7 Zombies (Kronos)
=========================================================

Blood Vials makes you earn your gear again. Instead of having everything open from
the start, you unlock it by playing Zombies.

INSTALL
- Needs Kronos with mod support (made on Kronos v1.41).
- Extract this zip into your Kronos "mods" folder, so you end up with
  kronos\mods\blood_vials\mod.json
- Turn "Blood Vials" on in Kronos's mod list and launch the game.
- Keep Kronos's own unlock options OFF (Unlock All, unlock weapons / attachments /
  camos / augments and the rest, in Options > Debug Options or
  players\progression.cfg). They unlock things before the mod gets a say, so with
  them on the locks may not work.
- Your Blood Vials balance and settings are in Options > Debug Options at the top.

EARNING BLOOD VIALS
- Kills earn vials: by default 1 vial per 25 kills. You can change that with a slider
  (1-25), or switch to a 7% drop chance per kill instead (Options > Debug Options).
- Special zombies count as 10 kills, and elites give a full vial.
- Every 5 rounds survived gives 3 vials.
- A successful exfil gives 3 vials.
- Finishing a main easter egg gives a rare Apothicon Blood Vial.

CRATES
Spend vials in the CRATES tab in the Zombies lobby. Each crate gives you something you
don't own yet, so there are no duplicates.
- Seasonal Weapon Crate (10 vials): DLC and seasonal guns
- Blueprint Crate (5 vials): weapon blueprints
- Perk Augment, Ammo Mod and Field Upgrade Crates (10 vials each)
- Relic Crate (10 vials): cursed relics, opened with the Blood of the Dead box from BO4
- Apothicon Crate (1 Apothicon vial): wonder weapon skins and other rare items,
  opened with the Shadows of Evil box from BO3

LOCKED PROGRESSION
- Guns and equipment unlock at their normal BO7 levels. Locked items show a lock and
  "Unlocked at Level #".
- Attachments and camos have to be earned through weapon levels and camo challenges.
- Augment research is off: augments only come from the Perk, Ammo Mod and Field Upgrade Crates.
GOOD TO KNOW
- Everything lives in this mod folder. Turn it off in Kronos's mod list and the game
  goes back to normal. Your progress is kept for when you turn it back on.
- In co-op, vials are earned in matches the host runs with the mod.
